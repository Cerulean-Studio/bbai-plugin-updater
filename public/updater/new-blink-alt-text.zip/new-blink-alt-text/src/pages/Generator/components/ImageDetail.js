import React, { useEffect, useState } from 'react';
import TextArea from './TextArea';
import Button from '../../../components/Button';
import { useForm } from 'react-hook-form';
import TextInput from './TextInput';
import InfoCircleGenerator from './InfoCircleGenerator';
import axios from 'axios';
import config from '../../../config';
import { Loader, NotificationModal } from '../../../components';
import { circleColorGenerator } from '../../../global';
import BlankModal from '../../../components/BlankModal';
import TableCustom from '../../../components/TableCustom';
import Pagination from '../../../components/Pagination';

export default function ImageDetail({ initialData, keyIndex, submitData, updateImageId, currentImageId, license }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch,
    getValues,
  } = useForm();

  // react-hook-form
  const valuesWatch = watch(['altText', 'slug', 'title', 'description', 'caption', 'fileName', 'decorative']);

  //   created
  // useEffect(() => {
  //   setPicUrl(initialData?.url);
  // }, [initialData?.url]);

  //   state
  const [expanded, setExpanded] = useState(false);
  const [picUrl, setPicUrl] = useState('');
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [checkbox, setCheckbox] = useState({
    slug: initialData?.slugAi ? initialData.slugAi : false,
    caption: initialData?.captionAi ? initialData.captionAi : false,
    altText: initialData?.altTextAi ? initialData.altTextAi : false,
    title: initialData?.titleAi ? initialData.titleAi : false,
    fileName: initialData?.fileNameAi ? initialData.fileNameAi : false,
    description: initialData?.descriptionAi ? initialData.descriptionAi : false,
  });
  const [pageLoading, setPageLoading] = useState(false);
  const [circleColor, setCircleColor] = useState({
    altText: 'bbai-bg-[#E2645F]',
    slug: 'bbai-bg-[#E2645F]',
    caption: 'bbai-bg-[#383838]',
    title: 'bbai-bg-[#E2645F]',
    fileName: 'bbai-bg-[#E2645F]',
    description: 'bbai-bg-[#383838]',
  });
  const [overallRating, setOverallRating] = useState(0);
  const [tooltipTexts, setTooltipTexts] = useState({
    altText: [],
    slug: [],
    title: [],
    caption: [],
    description: [],
    fileName: [],
  });
  const [status, setStatus] = useState({ altTextStatus: 0, fileNameStatus: 0 });
  const [openListOfPage, setOpenListOfPage] = useState(false);
  const [listOfPages, setListOfPages] = useState([]);
  const [lastPage, setLastPage] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [showPerPage, setShowPerPage] = useState(10);
  // const data
  const tableColumns = [
    { key: 'meta_title', label: 'Meta Title' },
    { key: 'published_date', label: 'Published Date' },
    { key: 'url', label: 'URL' },
  ];
  const showPerPageOption = [
    { value: 10, label: '10 per page' },
    { value: 25, label: '25 per page' },
    { value: 50, label: '50 per page' },
    { value: 100, label: '100 per page' },
  ];
  // const showPerPageOption = [
  //   { value: 1, label: '1 per page' },
  //   { value: 2, label: '2 per page' },
  //   { value: 3, label: '3 per page' },
  //   { value: 100, label: '100 per page' },
  // ];
  //   useeffect
  useEffect(() => {
    reset(initialData);
  }, [initialData, reset]);

  useEffect(() => {
    setPicUrl(initialData?.url);
    setCheckbox({
      slug: initialData?.slugAi ? initialData.slugAi : false,
      caption: initialData?.captionAi ? initialData.captionAi : false,
      altText: initialData?.altTextAi ? initialData.altTextAi : false,
      title: initialData?.titleAi ? initialData.titleAi : false,
      fileName: initialData?.fileNameAi ? initialData.fileNameAi : false,
      description: initialData?.descriptionAi ? initialData.descriptionAi : false,
    });
    updateCircleColorAll(initialData, checkbox);
  }, [initialData]);

  useEffect(() => {
    // useform's watch always triggered on rerender, so if we just watch the valuesWatch here, this useeffect will just trigger over and over again
    //  when there's a rerender somewhere else. json stringify used here so this useeffect will only
    // triggered when there's really changes
    let allValues = getValues();
    updateCircleColorAll(allValues, checkbox);
  }, [JSON.stringify(valuesWatch), checkbox]);
  //   methods
  const changeShowPerPage = (value) => {
    setShowPerPage(value);
    setPageLoading(true);
    axios
      .get(`${config.API_URL}/get-image-pages/?id=${initialData?.post_id}`, {
        params: { perPage: value },
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPageLoading(false);
        setOpenListOfPage(true);
        setListOfPages(response.data.data);
        setLastPage(response.data.pageNumber);
      })
      .catch(function (error) {
        console.log(error);
        setPageLoading(false);
      });
  }
  const resetListOfPagesState = () => {
    setOpenListOfPage(false);
    setListOfPages([]);
    setLastPage(null);
    setCurrentPage(1);
    setShowPerPage(10);
  };

  const pageClick = (page) => {
    setPageLoading(true);
    axios
      .get(`${config.API_URL}/get-image-pages/?id=${initialData?.post_id}`, {
        params: { page: page, perPage: showPerPage  },
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPageLoading(false);
        setOpenListOfPage(true);
        setListOfPages(response.data.data);
        setLastPage(response.data.pageNumber);
        setCurrentPage(page);
      })
      .catch(function (error) {
        console.log(error);
        setPageLoading(false);
      });
  };

  const getListOfPage = () => {
    setPageLoading(true);
    axios
      .get(`${config.API_URL}/get-image-pages/?id=${initialData?.post_id}`, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPageLoading(false);
        setOpenListOfPage(true);
        setListOfPages(response.data.data);
        setLastPage(response.data.pageNumber);
      })
      .catch(function (error) {
        console.log(error);
        setPageLoading(false);
      });
  };
  const updateCircleColorAll = (data, checkbox) => {
    if (data) {
      // console.log('============START===========');
      // console.log('updating circleColors for: ' + data.fileName);
      setOverallRating(0);
      let altText = circleColorGenerator.updateCircleColorAltText(
        data.altText,
        checkbox.altText,
        data.fileName,
        data.title,
        data.decorative
      );
      let title = circleColorGenerator.updateCircleColorTitle(data.title, checkbox.title, data.decorative);
      let caption = circleColorGenerator.updateCircleColorCaption(data.caption, checkbox.caption, data.decorative);
      let description = circleColorGenerator.updateCircleColorDescription(
        data.description,
        checkbox.description,
        data.decorative
      );
      let slug = circleColorGenerator.updateCircleColorSlug(data.slug, checkbox.slug, data.decorative);
      let fileName = circleColorGenerator.updateCircleColorFileName(data.fileName, checkbox.fileName);
      setCircleColor({
        altText: altText.color,
        title: title.color,
        caption: caption.color,
        description: description.color,
        slug: slug.color,
        fileName: fileName.color,
      });
      setTooltipTexts({
        altText: altText.tooltipText,
        title: title.tooltipText,
        caption: caption.tooltipText,
        description: description.tooltipText,
        slug: slug.tooltipText,
        fileName: fileName.tooltipText,
      });
      setStatus({
        altTextStatus: altText.value,
        fileNameStatus: fileName.value,
      });
      // SEO Formula
      // Title: 25%
      // Description: 5%
      // Slug: 15%
      // Alt Text: 25%
      // File Name: 20%
      // Caption: 5%

      // Title: 0%
      // Slug: 0%
      // File Name: 20%
      // Description: 0%
      // Alt Text: 80%
      // Caption: 0%

      // let titleScore = ((title.value * 0.25) / 2) * 100;
      // let descriptionScore = ((description.value * 0.05) / 2) * 100;
      // let slugScore = ((slug.value * 0.2) / 2) * 100;
      if (data.decorative) {
        let fileNameScore = (fileName.value / 2) * 100;
        setOverallRating(fileNameScore);
      } else {
        let altTextScore = ((altText.value * 0.5) / 2) * 100;
        let fileNameScore = ((fileName.value * 0.5) / 2) * 100;
        setOverallRating(altTextScore + fileNameScore);
      }
      // let captionScore = ((caption.value * 0.05) / 2) * 100;
      // setOverallRating(altTextScore + titleScore + captionScore + descriptionScore + slugScore + fileNameScore);
      // console.log('============END===========');
      // console.log('                              ');
    }
  };

  const updateCheckbox = (name, value) => {
    setCheckbox((prevCheckbox) => ({
      ...prevCheckbox,
      [name]: value,
    }));
  };

  const handleModalClick = () => {
    setIsOpen(false);
  };
  const onSubmit = (data) => {
    let payload = {
      post_id: data.post_id,
      caption: data.caption,
      title: data.title,
      slug: data.slug,
      description: data.description,
      altText: data.altText,
      altTextInitial: initialData.altTextInitial,
      fileName: data.fileName,
      decorative: data.decorative,
      decorativeInitial: initialData.decorativeInitial,
      path: data.metaData.file,
      // ai generated ?
      slugAi: checkbox.slug,
      captionAi: checkbox.caption,
      altTextAi: checkbox.altText,
      titleAi: checkbox.title,
      fileNameAi: checkbox.fileName,
      descriptionAi: checkbox.description,
      // status
      altTextStatus: status.altTextStatus,
      fileNameStatus: status.fileNameStatus,
    };
    submitData(payload);
  };

  const wandTrigger = (fieldName, data) => {
    if (license?.license) {
      updateImageId(initialData.post_id);
      setPageLoading(true);
      axios
        .post(
          `${config.API_URL}/chat-completions-generate`,
          { fieldName, post_image: initialData?.url },
          {
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': config.NONCE,
            },
          }
        )
        .then((response) => {
          if (response.status === 200 || response.status === 201) {
            const resData = response.data.choices[0].message.content;
            setValue(fieldName, resData);
            updateCheckbox(fieldName, true);
          }
          setPageLoading(false);
        })
        .catch(function (error) {
          console.log(error);
          if (error.response.status === 429 || error.response.status === 403) {
            setModalConfig({
              type: 'error',
              title: 'Error occured',
              description: error.response.data?.message,
              btnText: 'Continue',
            });
            setIsOpen(true);
          } else {
            // in this else, it handles all openai api's error response
            setModalConfig({
              type: 'error',
              title: error.response.data.error.code,
              description: error.response.data.error.message,
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
          setPageLoading(false);
        });
    } else {
      setModalConfig({
        type: 'error',
        title: 'Activate License',
        description: 'You have to activate your license to use this feature',
        btnText: 'Continue',
      });
      setIsOpen(true);
    }
  };

  const processCheckboxes = async () => {
    setPageLoading(true);
    const falseCheckboxes = Object.fromEntries(Object.entries(checkbox).filter(([_, value]) => value === false));
    let remainingCheckboxes = { ...falseCheckboxes };
    for (const property in remainingCheckboxes) {
      // console.log('Execute for: ', property);
      let apiError = false;
      try {
        const response = await axios.post(
          `${config.API_URL}/chat-completions-generate`,
          { fieldName: property, post_image: initialData?.url },
          {
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': config.NONCE,
            },
          }
        );

        if (response.status === 200 || response.status === 201) {
          const resData = response.data.choices[0].message.content;
          setValue(property, resData);
          updateCheckbox(property, true);
          // Process the response here
          // console.log(`Processed ${property}:`, resData);
          delete remainingCheckboxes[property];
        }
      } catch (error) {
        // if (error.response) {
        //   apiError = true;
        //   setModalConfig({
        //     type: 'error',
        //     title: error.response.data.error,
        //     description: error.response.data.message,
        //     btnText: 'Continue',
        //   });
        //   setIsOpen(true);
        // }
        if (error.response.status === 429 || error.response.status === 403) {
          apiError = true;
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: error.response.data?.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          apiError = true;
          // in this else, it handles all openai api's error response
          setModalConfig({
            type: 'error',
            title: error.response.data.error.code,
            description: error.response.data.error.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      }
      if (apiError) {
        console.log('process stopped because error');
        break;
      }
    }

    console.log('All checkboxes processed');
    setPageLoading(false);
  };

  const generateAll = () => {
    if (license?.license) {
      processCheckboxes();
    } else {
      setModalConfig({
        type: 'error',
        title: 'Activate License',
        description: 'You have to activate your license to use this feature',
        btnText: 'Continue',
      });
      setIsOpen(true);
    }
  };

  return (
    <div className="bbai-w-full bbai-flex bbai-gap-4 bbai-pt-8 bbai-pb-8 bbai-border-b bbai-border-b-[#D1D5DB]">
      <div className="bbai-flex-1">
        <div className="bbai-w-40 bbai-h-40 bbai-rounded-md bbai-flex bbai-justify-center bbai-items-center bbai-bg-[#F9FAFB]">
          <img className="bbai-object-cover bbai-object-center bbai-max-h-full bbai-max-w-full" src={picUrl}></img>
        </div>
        {/* expanded only */}
        {expanded && (
          <div className="bbai-mt-8 bbai-text-xs">
            <div className="bbai-font-bold ">Image Information</div>
            <div className="bbai-flex bbai-mt-3 bbai-flex-col bbai-gap-3 bbai-text-[#6B7280] bbai-break-all">
              <div>
                URL:{' '}
                <a href={initialData?.url} target="_blank" rel="noopener noreferrer">
                  {initialData?.url}
                </a>
              </div>
              <div>Format: {initialData?.url.split('.').pop()}</div>
              <div>
                Size: {initialData.metaData.width}x{initialData.metaData.height}
              </div>
              <div>
                Used:{' '}
                <span onClick={() => getListOfPage()} className="bbai-underline bbai-cursor-pointer">
                  {' '}
                  {initialData?.countImage}{' '}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
      <form className="bbai-flex bbai-gap-4 bbai-flex-[6]" onSubmit={handleSubmit(onSubmit)}>
        <div className="bbai-flex-1 bbai-flex bbai-flex-col bbai-gap-2">
          <TextArea
            triggerList={tooltipTexts.altText}
            wandTrigger={wandTrigger}
            updateCheckbox={updateCheckbox}
            checkboxValue={checkbox.altText}
            circleColor={circleColor.altText}
            id={`altText-${keyIndex}`}
            name="altText"
            label="Alt Text"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            rowNumber={2}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB] bbai-resize-none bbai-h-[80px]"
          />
          <TextInput
            triggerList={tooltipTexts.slug}
            circleColor={circleColor.slug}
            id={`slug-${keyIndex}`}
            name="slug"
            label="Slug"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB]"
            wandTrigger={wandTrigger}
            updateCheckbox={updateCheckbox}
            checkboxValue={checkbox.slug}
          />
          {expanded && (
            <>
              {/* expanded only */}

              <TextArea
                triggerList={tooltipTexts.caption}
                circleColor={circleColor.caption}
                id={`caption-${keyIndex}`}
                name="caption"
                label="Caption"
                placeholder="Write text here.."
                required={false}
                register={register}
                errors={errors}
                customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB] bbai-resize-none"
                wandTrigger={wandTrigger}
                updateCheckbox={updateCheckbox}
                checkboxValue={checkbox.caption}
              />
              <Button
                color="bbai-bg-[#EDEBFE]"
                hoverColor="bbai-bg-[#D6D4F9]"
                textColor="bbai-text-[#5521B5]"
                size="sm"
                customStyle="bbai-mt-3"
                onClick={() => generateAll()}
              >
                <svg
                  className="bbai-mr-2"
                  width="21"
                  height="21"
                  viewBox="0 0 21 21"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M16.5864 8.94238C16.5864 12.3031 13.8626 15.0269 10.5019 15.0269C7.14128 15.0269 4.41602 12.3031 4.41602 8.94238H7.66603C7.66603 10.5091 8.93524 11.7783 10.5019 11.7783C12.0687 11.7783 13.3379 10.5091 13.3379 8.94238H16.5864Z"
                    fill="#5521B5"
                  />
                  <path
                    d="M13.3378 8.94236H7.66602C7.66602 7.37565 8.93522 6.10645 10.5019 6.10645C12.0686 6.10645 13.3378 7.37565 13.3378 8.94236Z"
                    fill="#5521B5"
                  />
                </svg>
                Generate all atributes
              </Button>
            </>
          )}
        </div>

        <div className="bbai-flex-1 bbai-flex bbai-flex-col bbai-gap-2">
          {/* <TextInput
            circleColor={circleColor.altText}
            id={`altText-${keyIndex}`}
            name="altText"
            label="Alt Text"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB]"
            wandTrigger={wandTrigger}
          /> */}
          {/* <TextInput
            circleColor={circleColor.altText}
            id={`title-${keyIndex}`}
            name="title"
            label="Title"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB]"
            wandTrigger={wandTrigger}
          /> */}
          <TextArea
            triggerList={tooltipTexts.title}
            wandTrigger={wandTrigger}
            updateCheckbox={updateCheckbox}
            checkboxValue={checkbox.title}
            circleColor={circleColor.title}
            id={`title-${keyIndex}`}
            name="title"
            label="Title"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            rowNumber={2}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB] bbai-resize-none bbai-h-[80px]"
          />
          <TextInput
            triggerList={tooltipTexts.fileName}
            circleColor={circleColor.fileName}
            id={`fileName-${keyIndex}`}
            name="fileName"
            label="Filename"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB]"
            wandTrigger={wandTrigger}
            updateCheckbox={updateCheckbox}
            checkboxValue={checkbox.fileName}
          />
          {/* <TextInput
            circleColor={circleColor.altText}
            id={`url-${keyIndex}`}
            name="url"
            label="URL"
            placeholder="Write text here.."
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB]"
            wandTrigger={wandTrigger}
          /> */}
          {expanded && (
            <>
              {/* expanded only */}

              <TextArea
                triggerList={tooltipTexts.description}
                circleColor={circleColor.description}
                id={`description-${keyIndex}`}
                name="description"
                label="Description"
                placeholder="Write text here.."
                required={false}
                register={register}
                errors={errors}
                customStyle="bbai-w-full bbai-max-w-full bbai-bg-[#F9FAFB] bbai-resize-none"
                wandTrigger={wandTrigger}
                updateCheckbox={updateCheckbox}
                checkboxValue={checkbox.description}
              />
              <Button type="submit" size="sm" customStyle="bbai-mt-3">
                Save Changes
              </Button>
            </>
          )}
        </div>
      </form>
      <div className="bbai-flex-1">
        <div id="decorative" className="bbai-w-fit">
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('decorative')}
              type="checkbox"
              id={`decorative-${keyIndex}`}
              name="decorative"
              className="bbai-sr-only bbai-peer"
              // onClick={() => setDecorativeSwitch(!decorativeSwitch)}
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">Decorative</span>
          </label>
        </div>
        <div
          className={`${
            overallRating < 50 ? 'bbai-bg-[#FDE8E8]' : overallRating < 75 ? 'bbai-bg-[#FDF6B2]' : 'bbai-bg-[#DEF7EC]'
          } bbai-py-3 bbai-rounded-md bbai-flex bbai-justify-center bbai-items-center bbai-gap-2`}
        >
          <InfoCircleGenerator
            customStyle={'bbai-bg-[#4B5563] bbai-py-1 bbai-px-3'}
            className="bbai-mr-2"
            color={
              overallRating < 50 ? 'bbai-bg-[#E2645F]' : overallRating < 75 ? 'bbai-bg-[#E19F5F]' : 'bbai-bg-green-500'
            }
            tooltipText={`Rating: ${overallRating}`}
          />
          {overallRating < 50 ? 'Critical' : overallRating < 75 ? 'Warning' : 'Safe'}
        </div>
        <Button onClick={() => generateAll()} size="sm" customStyle="bbai-mt-5 bbai-w-full">
          <svg
            className="bbai-mr-2"
            width="20"
            height="20"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g mask="url(#mask0_2263_47974)">
              <path
                d="M9.99935 16.5625C9.76324 16.5625 9.53407 16.5104 9.31185 16.4062C9.08963 16.3021 8.89518 16.1528 8.72852 15.9583L2.35352 8.33333C2.22852 8.18056 2.13477 8.01389 2.07227 7.83333C2.00977 7.65278 1.97852 7.46528 1.97852 7.27083C1.97852 7.14583 1.98893 7.01736 2.00977 6.88542C2.0306 6.75347 2.07574 6.63194 2.14518 6.52083L3.70768 3.41667C3.86046 3.13889 4.06532 2.91667 4.32227 2.75C4.57921 2.58333 4.8674 2.5 5.18685 2.5H14.8118C15.1313 2.5 15.4195 2.58333 15.6764 2.75C15.9334 2.91667 16.1382 3.13889 16.291 3.41667L17.8535 6.52083C17.923 6.63194 17.9681 6.75347 17.9889 6.88542C18.0098 7.01736 18.0202 7.14583 18.0202 7.27083C18.0202 7.46528 17.9889 7.65278 17.9264 7.83333C17.8639 8.01389 17.7702 8.18056 17.6452 8.33333L11.2702 15.9583C11.1035 16.1528 10.9091 16.3021 10.6868 16.4062C10.4646 16.5104 10.2355 16.5625 9.99935 16.5625ZM8.02018 6.66667H11.9785L10.7285 4.16667H9.27018L8.02018 6.66667ZM9.16602 13.8958V8.33333H4.54102L9.16602 13.8958ZM10.8327 13.8958L15.4577 8.33333H10.8327V13.8958ZM13.8327 6.66667H16.041L14.791 4.16667H12.5827L13.8327 6.66667ZM3.95768 6.66667H6.16602L7.41602 4.16667H5.20768L3.95768 6.66667Z"
                fill="#EDEBFE"
              />
            </g>
          </svg>
          Generate All
        </Button>
        <Button
          onClick={() => setExpanded(!expanded)}
          color="bbai-bg-transparent"
          textColor="bbai-text-[#6B7280]"
          size="sm"
          customStyle="bbai-mt-5 bbai-border bbai-border-[#E5E7EB] bbai-w-full"
        >
          Expand
          <svg
            className={`bbai-ml-2 bbai-transition-all ${expanded ? 'bbai-rotate-180' : ''}`}
            width="13"
            height="13"
            viewBox="0 0 13 13"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M6.51288 9.33398C6.22647 9.33393 5.95181 9.22875 5.74932 9.04158L1.42932 5.04976C1.32617 4.9577 1.24389 4.84758 1.18729 4.72583C1.13069 4.60407 1.1009 4.47312 1.09965 4.34061C1.0984 4.2081 1.12573 4.07669 1.18003 3.95405C1.23434 3.8314 1.31453 3.71998 1.41593 3.62628C1.51734 3.53258 1.63792 3.45848 1.77065 3.4083C1.90338 3.35812 2.04559 3.33287 2.18899 3.33402C2.3324 3.33517 2.47411 3.3627 2.60588 3.41501C2.73764 3.46731 2.85681 3.54333 2.95644 3.63865L6.51288 6.92492L10.0693 3.63865C10.273 3.45686 10.5458 3.35628 10.829 3.35855C11.1122 3.36082 11.383 3.46578 11.5833 3.65081C11.7835 3.83583 11.8971 4.08613 11.8996 4.3478C11.902 4.60946 11.7932 4.86154 11.5964 5.04976L7.27644 9.04158C7.07395 9.22875 6.79929 9.33393 6.51288 9.33398Z"
              fill="#6B7280"
            />
          </svg>
        </Button>
      </div>
      {pageLoading && <Loader />}
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <BlankModal
        isOpen={openListOfPage}
        handleClose={() => {
          resetListOfPagesState();
        }}
        maxWidth="bbai-max-w-2xl"
      >
        <div className="bbai-text-xl bbai-font-bold">List of Pages</div>
        <div className="bbai-text-[#888888] -bbai-mt-2 bbai-w-2/4">
          This modal displays a list of pages that contain the selected image.
        </div>
        <TableCustom columns={tableColumns}>
          {listOfPages.length > 0 ? (
            listOfPages.map((page) => (
              <tr>
                <td class="bbai-p-1 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                  {page.post_title}
                </td>
                <td class="bbai-p-1 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                  {page.post_date.split(' ')[0]}
                </td>
                <td class="bbai-p-1 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900 ">
                  <a
                    className="bbai-text-[#374151] bbai-flex bbai-items-center bbai-gap-1"
                    href={page.link}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {page.link}
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M15 3H21V9"
                        stroke="#374151"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M10 14L21 3"
                        stroke="#374151"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M18 13V19C18 19.5304 17.7893 20.0391 17.4142 20.4142C17.0391 20.7893 16.5304 21 16 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V8C3 7.46957 3.21071 6.96086 3.58579 6.58579C3.96086 6.21071 4.46957 6 5 6H11"
                        stroke="#374151"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                    </svg>
                  </a>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan={3}
                class="bbai-text-center bbai-p-1 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900"
              >
                No pages found
              </td>
            </tr>
          )}
        </TableCustom>
        <div className="bbai-w-full bbai-flex bbai-justify-end">
          <div>
            <select
              id="showPerPage"
              onChange={(e) => changeShowPerPage(e.target.value)}
              class={`bbai-h-12 bbai-border bbai-border-gray-300 bbai-text-gray-600 bbai-text-base bbai-rounded-lg bbai-block bbai-py-2.5 bbai-px-4 focus:bbai-outline-none`}
            >
              {showPerPageOption.map((data, idx) => (
                <option key={idx} value={data.value}>
                  {data.label}
                </option>
              ))}
            </select>
          </div>
          {lastPage && (
            <Pagination pageClick={pageClick} lastPage={lastPage} currentPage={currentPage} className="bbai-mt-3" />
          )}
        </div>
      </BlankModal>
    </div>
  );
}
