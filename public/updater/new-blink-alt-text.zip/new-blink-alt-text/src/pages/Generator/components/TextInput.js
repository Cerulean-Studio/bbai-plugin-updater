import React from 'react';
import InfoCircleGenerator from './InfoCircleGenerator';
import TooltipCustomTarget from '../../../components/TooltipCustomTarget';

const TextInput = ({
  id = '',
  label = '',
  name = '',
  placeholder = '',
  type = 'text',
  required = false,
  customStyle = '',
  register,
  errors,
  circleColor,
  wandTrigger,
  updateCheckbox,
  checkboxValue = false,
  tooltipText,
  triggerList=[],
  ...props
}) => {
  return (
    <div className="relative">
      <div className="bbai-flex bbai-items-center bbai-mb-2 bbai-gap-1">
        <InfoCircleGenerator customChild={true} customStyle={'bbai-w-40 bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3'} color={circleColor} tooltipText={tooltipText}>
          <ul className='bbai-list-disc bbai-text-left bbai-pl-4'>
              {triggerList.map((data)=>(
                <li>{data}</li>
              ))}
          </ul>
        </InfoCircleGenerator>
        <label htmlFor={id} className="bbai-flex bbai-items-center bbai-text-sm bbai-font-medium bbai-text-gray-900">
          {label}
        </label>
      </div>
      <div className="bbai-relative">
        <input
          type={type}
          id={id}
          name={name}
          placeholder={placeholder}
          required={required}
          className={`bbai-block bbai-w-full bbai-px-4 bbai-py-2 bbai-text-base bbai-font-normal bbai-leading-relaxed bbai-text-gray-900 bbai-placeholder-gray-400 bbai-border bbai-border-gray-300 bbai-rounded-lg bbai-shadow-xs bbai-focus:outline-none ${customStyle}`}
          {...register(name, { required })}
          {...props}
        />
        <div className="bbai-h-6 bbai-gap-2 bbai-absolute bbai-right-5 bbai-top-2/4 -bbai-translate-y-2/4 bbai-cursor-pointer bbai-flex">
          <TooltipCustomTarget customStyle={'bbai-p-2'} tooltipText="Mark as reviewed and excellent">
          <input
            onClick={(e) => updateCheckbox(name, e.target.checked)}
            id="checkbox-default"
            type="checkbox"
            checked={checkboxValue}
            class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
          />
          </TooltipCustomTarget>
          <svg
            onClick={() => wandTrigger(name, `${name} auto generate`)}
            width="21"
            height="21"
            viewBox="0 0 21 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <rect width="21" height="21" rx="2" fill="#ECE8FF" />
            <path
              d="M5 17L11.6667 10.3333M15 7L13.3333 8.66667"
              stroke="#8856F6"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
            <path
              d="M9.33333 4.33301L9.96353 6.03613L11.6667 6.66634L9.96353 7.29655L9.33333 8.99967L8.70312 7.29655L7 6.66634L8.70312 6.03613L9.33333 4.33301Z"
              stroke="#8856F6"
              stroke-linejoin="round"
            />
            <path
              d="M15.6663 9.66699L16.0265 10.6402L16.9997 11.0003L16.0265 11.3605L15.6663 12.3337L15.3062 11.3605L14.333 11.0003L15.3062 10.6402L15.6663 9.66699Z"
              stroke="#8856F6"
              stroke-linejoin="round"
            />
          </svg>
        </div>
      </div>
      {errors[name] && <p className="bbai-mt-2 bbai-text-xs bbai-text-red-500">This field is required</p>}
    </div>
  );
};

export default TextInput;
