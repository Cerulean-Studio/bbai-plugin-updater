import React from 'react';
import { Outlet } from 'react-router-dom';
import { Header, Sidebar } from '../../layout';

const SettingPage = ({}) => {
  return (
    <div className="contianer">
      <Header />
      <div className="bbai-flex bbai-justify-between bbai-w-full bbai-gap-5 bbai-pr-5 bbai-mt-5">
        <Sidebar />
        <div className="bbai-flex bbai-items-center bbai-justify-between bbai-w-full bbai-p-6 bbai-bg-white bbai-border-r bbai-rounded-lg">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default SettingPage;
