import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import {
  TextInput,
  Button,
  NotificationModal,
  Loader,
  ConfirmationModal,
  Select,
  Toast,
} from '../../../components/index.js';
import TextInputAI from './components/TextInputAI';
import { saveSetting, checkApiKey, fetchSettings, removeSettings } from '../../../redux/actions/settingAction';
import { useSelector } from 'react-redux';
import TableCustom from '../../../components/TableCustom.js';
import Tooltip from '../../../components/Tooltip.js';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm();
  const generateType = watch('generateType');
  const automationWatch = watch('automation');
  const globalConfig = watch('globalConfig');
  // redux

  const settings = useSelector((state) => state.setting.settings);
  const loading = useSelector((state) => state.setting.isLoading);
  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Product Activated',
    description: 'Succesfully add valid product license!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [invalidRespon, setInvalidRespon] = useState('');
  const [showToastApiInvalid, setShowToastApiInvalid] = useState(false);
  const [checkedApiKey, setCheckedApiKey] = useState({
    clicked: false,
    valid: false,
  });

  // Const Data
  const languagesOptions = [
    { label: 'Choose a language', value: '' },
    { label: 'English', value: 'English' },
    { label: 'Bahasa Indonesia', value: 'Bahasa Indonesia' },
  ];

  const tableAttributes = [
    { attribute: 'Alt Text', aiModel: 'GPT-4o', key: 'altText' },
    { attribute: 'Title', aiModel: 'GPT-4o', key: 'title' },
    { attribute: 'Filename', aiModel: 'GPT-4o', key: 'filename' },
    { attribute: 'Caption', aiModel: 'GPT-4o', key: 'caption' },
    { attribute: 'Description', aiModel: 'GPT-4o', key: 'description' },
    { attribute: 'Slug/URL', aiModel: 'GPT-3.5-turbo', key: 'slug' },
  ];

  const tableColumns = [
    { key: 'attribute', label: 'Attribute' },
    { key: 'aiModel', label: 'AI Model' },
  ];

  const aiModelOptions = [
    { label: 'GPT-4o', value: 'gpt-4o' },
    { label: 'GPT-4o-mini', value: 'gpt-4o-mini' },
  ];

  // created
  useEffect(() => {
    fetchSettings();
  }, []);

  // useEffects

  useEffect(() => {
    // wp option always return it's value with string, html input checkbox wont recognize the string 'false' as a falsy so i have to convert it to boolean false here
    let tmp = { ...settings };
    tmp.automation = tmp.automation === 'true';
    tmp.individualAltText = tmp.individualAltText === 'true';
    tmp.individualCaption = tmp.individualCaption === 'true';
    tmp.individualDecorative = tmp.individualDecorative === 'true';
    tmp.individualDescription = tmp.individualDescription === 'true';
    tmp.individualFileName = tmp.individualFileName === 'true';
    tmp.individualSlug = tmp.individualSlug === 'true';
    tmp.individualTitle = tmp.individualTitle === 'true';
    reset(tmp);
  }, [settings, reset]);

  // methods

  const resetToDefault = () => {
    let aiModel = watch('aiModel');
    let globalConfig = watch('globalConfig');
    let tmp = { ...settings };
    tmp.globalConfig = globalConfig;
    tmp.aiModeltitle = aiModel;
    tmp.aiModelcaption = aiModel;
    tmp.aiModelslug = aiModel;
    tmp.aiModelaltText = aiModel;
    tmp.aiModelfilename = aiModel;
    tmp.aiModeldescription = aiModel;
    reset(tmp);
  }

  const openModalKeyValid = () => {
    setModalConfig({
      type: 'success',
      title: 'API Key Validation Successful',
      description:
        'The API key you entered is valid. Please continue filling out the remaining fields to complete the settings.',
      btnText: 'Continue',
    });
    setIsOpen(true);
  };
  const updateCheckState = (clicked, valid) => {
    setCheckedApiKey({ clicked, valid });
  };
  const triggerAlertFromTextInputAI = (data) => {
    setShowToastApiInvalid(true);
    setInvalidRespon(data);
    setTimeout(() => {
      setShowToastApiInvalid(false);
    }, 5000);
  };
  const handleDeactivate = () => {
    console.log('DEACTIVATING OPEN AI KEY');
    setOpenConfirmation(false);
    setSubmitLoading(true);
    removeSettings()
      .then((res) => {
        if (res.status === 200) {
          setSubmitLoading(false);
          setModalConfig({
            type: 'success',
            title: 'API Key Successfully Deleted',
            description: 'You have successfully deleted the API Key',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      })
      .catch((error) => {
        console.error('error', error);
        setSubmitLoading(false);
        setModalConfig({
          type: 'error',
          title: 'Error',
          description: error.response.data.error,
          btnText: 'Close',
        });
        setIsOpen(true);
      });
  };
  const censor = (text) => {
    // Get the first 3 characters
    const firstPart = text.slice(0, 3);

    // Get the last 4 characters
    const lastPart = text.slice(-4);

    // Combine them with 3 asterisks in between
    const result = `${firstPart}***${lastPart}`;
    return result;
  };

  const onSubmit = (data) => {
    // if apiKey already exist, then we only save the other settings
    // else, we check do further conditions (on else)
    if (settings.apiKey) {
      saveSetting(data).then((res) => {
        console.log(res);
        if (res.status === 200) {
          setSubmitLoading(false);
          setModalConfig({
            type: 'success',
            title: 'Submit Success',
            description: 'Successfully saving changes!',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      });
    } else {
      // apiKey doesnt exist here, we have few conditions
      if (data.apiKey) {
        // if field apikey is filled, we will check either user already click check or not
        if (!checkedApiKey.clicked) {
          // if havent check, throw error to validate key first
          setModalConfig({
            type: 'error',
            title: 'Validate your key',
            description: 'Before saving, you must validate your API key',
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else if (checkedApiKey.clicked && !checkedApiKey.valid) {
          // if clicked but not valid, tell to revalidate, make sure its valid before save
          setModalConfig({
            type: 'error',
            title: 'Validate your key',
            description:
              'Before saving, you must add a valid API key. If you think the API key you input should be valid, try to validate it again',
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          // if already clicked and already valid, save
          saveSetting(data).then((res) => {
            console.log(res);
            if (res.status === 200) {
              setSubmitLoading(false);
              setModalConfig({
                type: 'success',
                title: 'Submit Success',
                description: 'Successfully saving changes!',
                btnText: 'Continue',
              });
              setIsOpen(true);
            }
          });
        }
      } else {
        // if field apikey is empty, then save the other field changes
        saveSetting(data).then((res) => {
          console.log(res);
          if (res.status === 200) {
            setSubmitLoading(false);
            setModalConfig({
              type: 'success',
              title: 'Submit Success',
              description: 'Successfully saving changes!',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
      }
    }
  };

  const handleModalClick = () => {
    // if type is succes, it will reload.
    // but if the title is API Key Validation Successful, it will not reloaded, because its just an api check
    // and user still need to proceed filling the other fields
    if (modalConfig.type === 'success' && modalConfig.title != 'API Key Validation Successful') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };

  const closeShowToastApiInvalid = () => {
    setShowToastApiInvalid(false);
  };

  if (loading) {
    return <Loader />;
  }
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">AI Models</h1>
      <form
        autoComplete="off"
        onSubmit={handleSubmit(onSubmit)}
        className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6"
      >
        {settings?.apiKey ? (
          <div className="bbai-flex bbai-gap-2 bbai-w-full">
            <div className="bbai-text-base bbai-font-medium bbai-text-gray-500 bbai-flex-1">
              {censor(settings?.apiKey)}
            </div>
            <Button
              customStyle="bbai-w-4/12"
              color="bbai-bg-[#9B1C1C]"
              hoverColor="bbai-hover:bg-red-200"
              textColor="bbai-text-white"
              loading={submitLoading}
              onClick={() => {
                console.log('clicked');
                setOpenConfirmation(true);
              }}
            >
              Remove Key
            </Button>
          </div>
        ) : (
          <TextInputAI
            id="apiKey"
            name="apiKey"
            label="Open AI API Key"
            placeholder="API key.."
            register={register}
            errors={errors}
            tooltipInfo={true}
            triggerAlert={triggerAlertFromTextInputAI}
            updateCheckState={updateCheckState}
            openModalKeyValid={openModalKeyValid}
            tooltipText="Tooltip..."
          />
        )}

        <Select
          id="outputLanguage"
          name="outputLanguage"
          label="Output Languages"
          placeholder="Select a language.."
          required={false}
          register={register}
          errors={errors}
          customStyle="bbai-w-full bbai-max-w-full"
          options={languagesOptions}
        />
        <div>
          <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Global Settings Configuration</label>
          <div className="bbai-flex bbai-gap-2 bbai-mt-3">
            <input type="radio" id="globalConfig" name="globalConfig" {...register('globalConfig')} value="automatic" />
            <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Automatic</label>
            <input type="radio" id="globalConfig2" name="globalConfig" {...register('globalConfig')} value="manual" />
            <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Manual</label>
          </div>
          {globalConfig == 'manual' ? (
            <>
              <div className="bbai-mt-6 bbai-mb-6 bbai-flex bbai-justify-between bbai-w-full">
                <div className="bbai-flex">
                  <div className="bbai-font-medium">Attribute-based AI Model</div>
                  <Tooltip tooltipText="Tooltip..." />
                </div>

                <a
                  href="https://platform.openai.com/docs/guides/rate-limits"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bbai-underline bbai-font-medium bbai-text-xs bbai-text-[#6B7280]"
                >
                  AI Model Documentation
                </a>
              </div>
              <TableCustom columns={tableColumns} data={tableAttributes}>
                {tableAttributes.map((row) => (
                  <tr>
                    <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                      {row.attribute}
                    </td>
                    <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                      <Select
                        id={`aiModel${row.key}`}
                        name={`aiModel${row.key}`}
                        placeholder="Select model.."
                        customStyle='bbai-border-none focus:bbai-border-none'
                        required={false}
                        register={register}
                        errors={errors}
                        options={aiModelOptions}
                      />
                    </td>
                  </tr>
                ))}
              </TableCustom>
              <div onClick={()=> resetToDefault()} className="bbai-text-red-700 bbai-cursor-pointer bbai-font-medium bbai-text-xs bbai-mt-3">Reset to Default</div>
            </>
          ) : (
            <div className="bbai-mt-6">
              <Select
                id="aiModel"
                name="aiModel"
                label="Image-to-text Model"
                placeholder="Select model.."
                required={true}
                register={register}
                errors={errors}
                customStyle="bbai-w-full bbai-max-w-full"
                options={aiModelOptions}
                tooltipInfo={true}
                tooltipText="Tooltip..."
              />
            </div>
          )}
        </div>
        <div id="automation" className="bbai-w-fit">
          <div className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
            Automation
          </div>
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('automation')}
              type="checkbox"
              id="automation"
              name="automation"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full peer bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">
              Generate attributes on upload
            </span>
          </label>
        </div>
        {automationWatch && (
          <>
            <div className="bbai-flex bbai-flex-col bbai-gap-2">
              <div className="bbai-flex bbai-items-center">
                <input
                  type="radio"
                  id="queueImages"
                  name="queueImages"
                  value="all"
                  {...register('generateType')} // Register this radio button
                />
                <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900 bbai-ml-2">
                  Generate All Attributes
                </label>
              </div>
              <div className="bbai-flex bbai-items-center">
                <input
                  type="radio"
                  id="queueImages2"
                  name="queueImages"
                  value="individual"
                  {...register('generateType')} // Register this radio button
                />
                <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900 bbai-ml-2">
                  Select individual attributes
                </label>
              </div>
            </div>
            {generateType == 'individual' && (
              <div className="bbai-flex bbai-gap-4">
                <div className="bbai-flex bbai-flex-col bbai-gap-5">
                  <div className="bbai-border-r-[1px]">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualTitle')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1">Title</span>
                  </div>
                  <div className="bbai-border-r-[1px]">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualCaption')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1">Caption</span>
                  </div>
                  <div className="bbai-border-r-[1px]">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualSlug')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1 bbai-pr-4">Slug/URL</span>
                  </div>
                  <div className="bbai-border-r-[1px]">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualAltText')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1">Alt Text</span>
                  </div>
                </div>
                <div className="bbai-flex bbai-flex-col bbai-gap-5">
                  <div className="">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualFileName')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1">Filename</span>
                  </div>
                  <div className="">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualDescription')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1">Description</span>
                  </div>
                  <div className="">
                    <input
                      id="checkbox-default"
                      type="checkbox"
                      {...register('individualDecorative')}
                      class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                    />
                    <span className="bbai-text-sm bbai-ml-1 bbai-pr-4">Decorative</span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        <Button size="sm" type="submit" customStyle="bbai-mt-5 bbai-w-4/12" loading={submitLoading}>
          Save Changes
        </Button>
      </form>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <ConfirmationModal
        isOpen={openConfirmation}
        title={'Are you sure you want to delete the API key?'}
        description={
          'You cannot reverse this action. API Key will be deleted permanently and disappear forever as a result of this.'
        }
        btnTextTrue={'Yes, Delete'}
        handleClickTrue={handleDeactivate}
        btnTextFalse={'Cancel'}
        handleClickFalse={() => {
          setOpenConfirmation(false);
          console.log('Cancel Deactivation OPENAPIKEY');
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      />
      <Toast
        show={showToastApiInvalid}
        closeShow={closeShowToastApiInvalid}
        title="Invalid API Key"
        text={invalidRespon}
      />
    </div>
  );
}
