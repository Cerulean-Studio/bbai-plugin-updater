import React, { useEffect, useState } from 'react';
import { set, useForm } from 'react-hook-form';
import { Button, NotificationModal, Loader, InputMultiple } from '../../../components';
import { useSelector } from 'react-redux';
import { fetchRoleRestriction, saveRoleRestriction } from '../../../redux/actions/roleRestrictionAction';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  // redux

  const roleRestriction = useSelector((state) => state.roleRestriction.roleRestriction);
  const loading = useSelector((state) => state.roleRestriction.isLoading);

  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Limit Updated',
    description: 'Succesfully updated API limit!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [individualAttribute, setIndividualAttribute] = useState(roleRestriction.individualAttribute);
  const [bulkGeneration, setBulkGeneration] = useState(roleRestriction.bulkGeneration);
  const [setting, setSetting] = useState(roleRestriction.setting);
  const [optionRole, setOptionRole] = useState([{ value: '', label: '' }]);

  // Const Data

  // created
  useEffect(() => {
    console.log('render');
    fetchRoleRestriction();
  }, []);

  // useEffects

  useEffect(() => {
    console.log('huh');
    console.log(roleRestriction);
    // wp option always return it's value with string, html input checkbox wont recognize the string 'false' as a falsy so i have to convert it to boolean false here
    let tmp = { ...roleRestriction };
    if (tmp.featureRestriction == 'true') {
      tmp.featureRestriction = true;
    } else {
      tmp.featureRestriction = false;
    }
    let tmpRole = tmp?.roles;
    if (tmpRole) {
      let roleArray = Object.entries(tmpRole).map(([key, value]) => ({
        label: value,
        value: key,
      }));
      setOptionRole([{ label: '', value: '' }, ...roleArray]);
    }
    reset(tmp);
  }, [roleRestriction, reset]);

  // methods

  const onSubmit = (data) => {
    let { featureRestriction } = data;
    let tmp = {
      individualAttribute: individualAttribute || roleRestriction.individualAttribute,
      bulkGeneration: bulkGeneration || roleRestriction.bulkGeneration,
      setting: setting || roleRestriction.setting,
      featureRestriction,
    };
    saveRoleRestriction(tmp).then((res) => {
      if (res.status === 200) {
        setSubmitLoading(false);
        setModalConfig({
          type: 'success',
          title: 'Limit Updated',
          description: 'Succesfully updated API limit!',
          btnText: 'Continue',
        });
        setIsOpen(true);
      }
    });
  };

  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };

  if (loading) {
    return <Loader />;
  }
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Role-based restrictions</h1>
      <form
        autoComplete="off"
        onSubmit={handleSubmit(onSubmit)}
        className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6"
      >
        <div id="featureRestriction" className="bbai-w-fit">
          <div className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
            Feature restrictions
          </div>
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-3 bbai-cursor-pointer">
            <input
              {...register('featureRestriction')}
              type="checkbox"
              id="featureRestriction"
              name="featureRestriction"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full peer bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">Enable</span>
          </label>
          <div className="bbai-text-xs bbai-text-[#6B7280]">
            When enabled, the role listed in each input can access the feature, making it available to them.
          </div>
        </div>
        <div>
          <InputMultiple
            id="individualAttribute"
            name="individualAttribute"
            label="Invidual attribute generation"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.individualAttribute}
            onChange={setIndividualAttribute}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You cannot run individual attributes with a single click.
          </div>
        </div>
        <div>
          <InputMultiple
            id="bulkGeneration"
            name="bulkGeneration"
            label="Bulk Generation"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.bulkGeneration}
            onChange={setBulkGeneration}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You can use features in bulk, but customization options like prompt editing, workflow scheduling, and others
            are not available.
          </div>
        </div>
        <div>
          <InputMultiple
            id="setting"
            name="setting"
            label="Settings"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.setting}
            onChange={setSetting}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You don't have access to the settings, but you can access all other features.
          </div>
        </div>

        <div id="info" className="bbai-w-full bbai-bg-[#FDF6B2] bbai-flex bbai-p-2 bbai-gap-2">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_15146_41102)">
              <path
                d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346627 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C15.9977 5.87898 15.1541 3.8455 13.6543 2.34572C12.1545 0.845932 10.121 0.00232928 8 0ZM7.6 3.2C7.83734 3.2 8.06935 3.27038 8.26669 3.40224C8.46402 3.53409 8.61783 3.72151 8.70866 3.94078C8.79948 4.16005 8.82325 4.40133 8.77694 4.63411C8.73064 4.86688 8.61635 5.0807 8.44853 5.24853C8.28071 5.41635 8.06689 5.53064 7.83411 5.57694C7.60133 5.62324 7.36005 5.59948 7.14078 5.50865C6.92151 5.41783 6.7341 5.26402 6.60224 5.06668C6.47038 4.86934 6.4 4.63734 6.4 4.4C6.4 4.08174 6.52643 3.77651 6.75147 3.55147C6.97652 3.32643 7.28174 3.2 7.6 3.2ZM9.6 12H6.4C6.18783 12 5.98435 11.9157 5.83432 11.7657C5.68429 11.6157 5.6 11.4122 5.6 11.2C5.6 10.9878 5.68429 10.7843 5.83432 10.6343C5.98435 10.4843 6.18783 10.4 6.4 10.4H7.2V8H6.4C6.18783 8 5.98435 7.91571 5.83432 7.76568C5.68429 7.61565 5.6 7.41217 5.6 7.2C5.6 6.98782 5.68429 6.78434 5.83432 6.63431C5.98435 6.48428 6.18783 6.4 6.4 6.4H8C8.21218 6.4 8.41566 6.48428 8.56569 6.63431C8.71572 6.78434 8.8 6.98782 8.8 7.2V10.4H9.6C9.81217 10.4 10.0157 10.4843 10.1657 10.6343C10.3157 10.7843 10.4 10.9878 10.4 11.2C10.4 11.4122 10.3157 11.6157 10.1657 11.7657C10.0157 11.9157 9.81217 12 9.6 12Z"
                fill="#723B13"
              />
            </g>
            <defs>
              <clipPath id="clip0_15146_41102">
                <rect width="16" height="16" fill="white" />
              </clipPath>
            </defs>
          </svg>

          <span className="bbai-text-[#723B13] bbai-font-semibold">
            When no roles are assigned, the feature becomes accessible to all roles by default. To limit access, ensure
            specific roles are added to define who can use the feature.
          </span>
        </div>

        <Button size="sm" type="submit" customStyle="bbai-mt-2 bbai-w-4/12" loading={submitLoading}>
          Save Changes
        </Button>
      </form>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
    </div>
  );
}
