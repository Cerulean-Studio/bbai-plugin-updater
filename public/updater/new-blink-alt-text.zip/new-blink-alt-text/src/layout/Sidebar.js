import React, {useEffect} from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useLocation } from 'react-router-dom';
import {menuList} from './data'

function Sidebar() {
  const license = useSelector((state) => state.license.license);
  const navigate = useNavigate();

  const goToPage = (path) => {
    navigate(path);
  };
  // created
  const location = useLocation();

  useEffect(() => {
    const currentUrl = location.pathname + location.hash;
    console.log('CURRENT URL sidebar: ', currentUrl);
    console.log(location.pathname)
  }, [location]);

  // methods
  const filterMenu = (menuList) => {
    if(!license?.license){
      menuList = menuList.filter((data)=> !data.pro)
    }
    return menuList
  }

  return (
    <div className="bbai-inline-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-1/3 bbai-h-full bbai-gap-5 bbai-p-2 bbai-bg-white bbai-border-r bbai-rounded-lg xl:bbai-p-4">
      <div className="bbai-w-full">
        <div className="bbai-flex bbai-items-center bbai-w-full bbai-h-8">
          <h6 className="bbai-text-xl bbai-font-semibold bbai-leading-4 bbai-text-gray-800">Settings</h6>
        </div>
        <ul className="bbai-flex bbai-flex-col bbai-mt-6">
          {filterMenu(menuList).map(data =>(
            <li onClick={() => goToPage(data.link)}>
              <div className={`bbai-flex bbai-flex-col bbai-p-2.5 bbai-rounded-lg ${location.pathname == data.link?'bbai-bg-slate-200':'bbai-bg-white'} hover:bbai-bg-slate-200 bbai-cursor-pointer`}>
                <div className="bbai-flex bbai-items-center bbai-h-5 bbai-gap-3">
                  <div className="bbai-relative">
                    <div
                      className={`bbai-w-[12px] bbai-h-[12px] ${data.name == 'License Key' && license?.license? 'bbai-bg-green-500':data.dotColor} bbai-rounded-full`}
                    ></div>
                  </div>
                  <h2 className="bbai-text-sm bbai-font-semibold bbai-leading-snug bbai-text-gray-800">{data.name}</h2>
                </div>
              </div>
          </li>
          ))}
          
        </ul>
      </div>
    </div>
  );
}

export default Sidebar;
