import { renderWithRedux } from '..';
import CustomPageModal from '../inject-components/CustomPageModal';

export default function injectPageComponents() {
  if (!wp.media) return;
  const originalOpen = wp.media.view.Modal.prototype.open;
  wp.media.view.Modal.prototype.open = function () {
    originalOpen.apply(this, arguments);
    setTimeout(() => {
      const headerContainers = document.querySelectorAll('div.media-sidebar');
      headerContainers.forEach((headerContainer) => {
        if (!headerContainer.querySelector('#inject-page-modal')) {
          const newContainer = document.createElement('div');
          newContainer.id = 'inject-page-modal';

          // Insert the new container inside each headerContainer
          headerContainer.appendChild(newContainer);

          // Render the CustomPageModal component inside the new container
          renderWithRedux(<CustomPageModal />, newContainer);
        }
      });
    }, 100); // Adjust the timeout if necessary
  };
}
