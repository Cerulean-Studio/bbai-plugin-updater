const config = {
  API_URL: `${appLocalizer.apiUrl}/blink-alt-text/v1`,
  BASE_URL: `${appLocalizer.adminUrl}`,
  NONCE: `${appLocalizer.nonce}`,
};

export default config;
