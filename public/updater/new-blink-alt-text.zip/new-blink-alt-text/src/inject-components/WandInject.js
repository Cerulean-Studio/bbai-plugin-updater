import axios from 'axios';
import React, { useState } from 'react';
import config from '../config';
import { Loader, NotificationModal } from '../components';
import { useSelector } from 'react-redux';
import TooltipCustomTarget from '../components/TooltipCustomTarget';

export default function WandInject({
  input,
  name,
  triggerModal,
  setPageLoading,
  pageLoading,
  updateForm,
  checkboxValue,
  updateCheckbox,
  url,
}) {
  const license = useSelector((state) => state.license.license);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  // const [pageLoading, setPageLoading] = useState(false);
  const editValue = () => {
    if (license?.license) {
      setPageLoading(true);
      axios
        .post(
          `${config.API_URL}/chat-completions-generate`,
          { fieldName: name, post_image: url },
          {
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': config.NONCE,
            },
          }
        )
        .then((response) => {
          if (response.status === 200 || response.status === 201) {
            const resData = response.data.choices[0].message.content;
            input.value = resData;
            updateForm(resData);
          }
          setPageLoading(false);
        })
        .catch(function (error) {
          setPageLoading(false);
          if (error.response.status === 429 || error.response.status === 403) {
            setModalConfig({
              type: 'error',
              title: 'Error occured',
              description: error.response.data?.message,
              btnText: 'Continue',
            });
            setIsOpen(true);
          } else {
            // in this else, it handles all openai api's error response
            setModalConfig({
              type: 'error',
              title: error.response.data.error.code,
              description: error.response.data.error.message,
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
    } else {
      triggerModal('error', 'Activate License', 'Activate your license to use this feature');
    }
  };
  // because of the way the checkbox is injected, we need to use a local state to track the checkbox value
  const [localChecked, setLocalChecked] = useState(checkboxValue);
  // methods
  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };
  return (
    <div className="bbai-h-6 bbai-gap-1 bbai-absolute bbai-right-5 bbai-top-2/4 -bbai-translate-y-2/4 bbai-cursor-pointer bbai-flex">
      <TooltipCustomTarget customStyle={'bbai-p-2'} tooltipText="Mark as reviewed and excellent">
        <input
          onClick={(e) => {
            updateCheckbox(e.target.checked);
            setLocalChecked(e.target.checked);
          }}
          id={`checkbox-${name}`}
          type="checkbox"
          checked={localChecked}
          class="bbai-w-5 bbai-h-5 bbai-m-0 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
        />
      </TooltipCustomTarget>
      <div onClick={editValue}>
        <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="21" height="21" rx="2" fill="#ECE8FF" />
          <path
            d="M5 17L11.6667 10.3333M15 7L13.3333 8.66667"
            stroke="#8856F6"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M9.33333 4.33301L9.96353 6.03613L11.6667 6.66634L9.96353 7.29655L9.33333 8.99967L8.70312 7.29655L7 6.66634L8.70312 6.03613L9.33333 4.33301Z"
            stroke="#8856F6"
            stroke-linejoin="round"
          />
          <path
            d="M15.6663 9.66699L16.0265 10.6402L16.9997 11.0003L16.0265 11.3605L15.6663 12.3337L15.3062 11.3605L14.333 11.0003L15.3062 10.6402L15.6663 9.66699Z"
            stroke="#8856F6"
            stroke-linejoin="round"
          />
        </svg>
      </div>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      {pageLoading && <Loader />}
    </div>
  );
}
