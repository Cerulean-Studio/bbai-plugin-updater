import React, { useEffect, useState } from 'react';
import TextInputModal from './TextInputModal';
import config from '../config';
import axios from 'axios';
import { useSelector } from 'react-redux';
import { fecthLicense } from '../redux/actions/licenseAction';
import { Loader, NotificationModal } from '../components';
import { circleColorGenerator } from '../global';

export default function CustomMediaModal() {
  const license = useSelector((state) => state.license.license);
  // state
  const [postId, setPostId] = useState(null);
  const [initialValues, setInitialValues] = useState({
    altText: null,
    title: null,
    fileName: null,
    caption: null,
    description: null,
    slug: null,
    url: null,
  });
  const [decorativeFlag, setDecorativeFlag] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [pageLoading, setPageLoading] = useState(false);
  const [savingText, setSavingText] = useState('');
  const [checkbox, setCheckbox] = useState({
    slug: false,
    caption: false,
    altText: false,
    title: false,
    fileName: false,
    description: false,
  });
  const [circleColor, setCircleColor] = useState({
    altText: 'bbai-bg-[#E2645F]',
    slug: 'bbai-bg-[#E2645F]',
    caption: 'bbai-bg-[#383838]',
    title: 'bbai-bg-[#E2645F]',
    fileName: 'bbai-bg-[#E2645F]',
    description: 'bbai-bg-[#383838]',
  });
  const [status, setStatus] = useState({ altTextStatus: 0, fileNameStatus: 0 });
  const [tooltipTexts, setTooltipTexts] = useState({
    altText: [],
    slug: [],
    title: [],
    caption: [],
    description: [],
    fileName: [],
  });
  // created
  useEffect(() => {
    setPageLoading(true);
    fecthLicense();
    const params = new URLSearchParams(window.location.search);
    let item = params.get('item'); // Get the value of the 'item' parameter
    // If 'item' is not in the URL, try to get it from localStorage
    if (!item) {
      item = localStorage.getItem('recentItem');
    }

    setPostId(item); // Set the item ID in state

    axios
      .get(`${config.API_URL}/posts-byid`, {
        params: { postId: item },
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPageLoading(false);
        let tmp = response.data.data[0];
        setInitialValues({
          altText: tmp.altText,
          title: tmp.title,
          fileName: tmp.fileName,
          caption: tmp.caption,
          description: tmp.description,
          slug: tmp.slug,
          url: tmp.url,
          path: tmp.metaData?.file,
        });
        setCheckbox({
          slug: tmp.slugAi,
          caption: tmp.captionAi,
          altText: tmp.altTextAi,
          title: tmp.titleAi,
          fileName: tmp.fileNameAi,
          description: tmp.descriptionAi,
        });
        setDecorativeFlag(tmp.decorative);
      });
  }, []);
  // save item to local storage (for when user refresh the page while modal open)
  const savePostId = () => {
    const params = new URLSearchParams(window.location.search);
    let item = params.get('item'); // Get the value of the 'item' parameter
    if (item) {
      localStorage.setItem('recentItem', item);
    }
  };
  useEffect(() => {
    window.addEventListener('beforeunload', savePostId);
    return () => {
      window.removeEventListener('beforeunload', savePostId);
    };
  }, []);
  // watch
  useEffect(() => {
    updateCircleColorAll(initialValues, checkbox);
  }, [initialValues, checkbox, decorativeFlag]);

  // methods

  const updateCircleColorAll = (data, checkbox) => {
    if (data) {
      console.log(checkbox);
      console.log('============START===========');
      console.log('updating circleColors for: ' + data.fileName);
      let altText = circleColorGenerator.updateCircleColorAltText(
        data.altText,
        checkbox.altText,
        data.fileName,
        data.title,
        decorativeFlag
      );
      let title = circleColorGenerator.updateCircleColorTitle(data.title, checkbox.title, decorativeFlag);
      let caption = circleColorGenerator.updateCircleColorCaption(data.caption, checkbox.caption, decorativeFlag);
      let description = circleColorGenerator.updateCircleColorDescription(
        data.description,
        checkbox.description,
        decorativeFlag
      );
      let slug = circleColorGenerator.updateCircleColorSlug(data.slug, checkbox.slug, decorativeFlag);
      let fileName = circleColorGenerator.updateCircleColorFileName(data.fileName, checkbox.fileName);
      setCircleColor({
        altText: altText.color,
        title: title.color,
        caption: caption.color,
        description: description.color,
        slug: slug.color,
        fileName: fileName.color,
      });
      setTooltipTexts({
        altText: altText.tooltipText,
        title: title.tooltipText,
        caption: caption.tooltipText,
        description: description.tooltipText,
        slug: slug.tooltipText,
        fileName: fileName.tooltipText,
      });
      setStatus({
        altTextStatus: altText.value,
        fileNameStatus: fileName.value,
      });
      console.log('============END===========');
      console.log('                              ');
    }
  };

  const watchField = (data, inputName) => {
    // altText is the only one that's being watched here because we need the updated value
    // on decorative toggle
    setInitialValues((prevState) => ({
      ...prevState,
      [inputName]: data,
    }));
  };
  const handleModalClick = () => {
    setIsOpen(false);
  };
  const handleCopy = () => {
    navigator.clipboard
      .writeText(initialValues.url)
      .then(() => {
        console.log('URL copied to clipboard');
      })
      .catch((err) => {
        console.error('Failed to copy: ', err);
      });
  };
  const updateDecorative = (check) => {
    setSavingText('Saving...');
    setDecorativeFlag(!decorativeFlag);
    let payload = {
      key: 'decorative',
      value: check,
      post_id: postId,
      generatedByAi: false,
      altTextBlink: initialValues?.altText,
      path: initialValues?.path,
    };
    axios
      .post(`${config.API_URL}/save-inject`, payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setSavingText('Saved');
        setTimeout(() => {
          setSavingText('');
        }, 2000);
      })
      .catch(function (error) {
        setSavingText('Failed to save');
        setTimeout(() => {
          setSavingText('');
        }, 2000);
      });
  };

  const updateCheckbox = (name, value) => {
    setCheckbox((prevCheckbox) => ({
      ...prevCheckbox,
      [name]: value,
    }));
    axios.post(`${config.API_URL}/save-inject-checkbox`, {
      key: name,
      value: value,
      post_id: postId,
    });
  };

  const processCheckboxes = async () => {
    setPageLoading(true);
    const falseCheckboxes = Object.fromEntries(Object.entries(checkbox).filter(([_, value]) => value === false));
    let remainingCheckboxes = { ...falseCheckboxes };
    for (const property in remainingCheckboxes) {
      console.log('Execute for: ', property);
      let apiError = false;
      try {
        const response = await axios.post(
          `${config.API_URL}/chat-completions-generate`,
          { fieldName: property, post_image: initialValues?.url },
          {
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': config.NONCE,
            },
          }
        );

        if (response.status === 200 || response.status === 201) {
          const resData = response.data.choices[0].message.content;
          setInitialValues((prevState) => ({
            ...prevState,
            [property]: resData,
          }));
          updateCheckbox(property, true);

          let payload = {
            key: property,
            value: resData,
            post_id: postId,
            generatedByAi: true,
            altTextBlink: initialValues?.altText,
            path: initialValues?.path,
          };
          if (property == 'altText' || property == 'fileName') {
            // processcheckboxes will automatically set the field to checked, so auto green
            payload['score'] = 2;
          }
          axios.post(`${config.API_URL}/save-inject`, payload, {
            headers: {
              'Content-Type': 'application/json',
            },
          });
          console.log(`Processed ${property}:`, resData);
        }
      } catch (error) {
        // if (error.response) {
        //   apiError = true;
        //   setModalConfig({
        //     type: 'error',
        //     title: error.response.data.error,
        //     description: error.response.data.message,
        //     btnText: 'Continue',
        //   });
        //   setIsOpen(true);
        // }
        if (error.response.status === 429 || error.response.status === 403) {
          apiError = true;
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: error.response.data?.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          apiError = true;
          // in this else, it handles all openai api's error response
          setModalConfig({
            type: 'error',
            title: error.response.data.error.code,
            description: error.response.data.error.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      }
      if (apiError) {
        console.log('process stopped because error');
        break;
      }
    }
    console.log('All checkboxes processed');
    setPageLoading(false);
  };

  const generateAll = () => {
    if (license?.license) {
      processCheckboxes();
    } else {
      setModalConfig({
        type: 'error',
        title: 'Activate License',
        description: 'You have to activate your license to use this feature',
        btnText: 'Continue',
      });
      setIsOpen(true);
    }
  };
  return (
    <div className="bbai-p-1 bbai-mt-3">
      <div className="bbai-text-xs bbai-mb-3 bbai-w-[65%] bbai-float-right">{savingText}</div>
      <div
        className="bbai-bg-[#8856F6] bbai-text-white bbai-w-full md:bbai-w-2/3 bbai-px-11 bbai-py-2 bbai-text-center bbai-mb-3 bbai-rounded-md bbai-cursor-pointer bbai-flex bbai-items-center bbai-gap-2"
        style={{ float: 'right', boxSizing: 'border-box' }}
        onClick={generateAll}
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g mask="url(#mask0_2136_37365)">
            <path
              d="M7.99967 13.25C7.81079 13.25 7.62745 13.2083 7.44967 13.125C7.2719 13.0417 7.11634 12.9222 6.98301 12.7667L1.88301 6.66667C1.78301 6.54444 1.70801 6.41111 1.65801 6.26667C1.60801 6.12222 1.58301 5.97222 1.58301 5.81667C1.58301 5.71667 1.59134 5.61389 1.60801 5.50833C1.62467 5.40278 1.66079 5.30556 1.71634 5.21667L2.96634 2.73333C3.08856 2.51111 3.25245 2.33333 3.45801 2.2C3.66356 2.06667 3.89412 2 4.14967 2H11.8497C12.1052 2 12.3358 2.06667 12.5413 2.2C12.7469 2.33333 12.9108 2.51111 13.033 2.73333L14.283 5.21667C14.3386 5.30556 14.3747 5.40278 14.3913 5.50833C14.408 5.61389 14.4163 5.71667 14.4163 5.81667C14.4163 5.97222 14.3913 6.12222 14.3413 6.26667C14.2913 6.41111 14.2163 6.54444 14.1163 6.66667L9.01634 12.7667C8.88301 12.9222 8.72745 13.0417 8.54967 13.125C8.3719 13.2083 8.18856 13.25 7.99967 13.25ZM6.41634 5.33333H9.58301L8.58301 3.33333H7.41634L6.41634 5.33333ZM7.33301 11.1167V6.66667H3.63301L7.33301 11.1167ZM8.66634 11.1167L12.3663 6.66667H8.66634V11.1167ZM11.0663 5.33333H12.833L11.833 3.33333H10.0663L11.0663 5.33333ZM3.16634 5.33333H4.93301L5.93301 3.33333H4.16634L3.16634 5.33333Z"
              fill="white"
            />
          </g>
        </svg>
        <span>Generate All Image Information</span>
      </div>
      <div
        id="decorative"
        className="bbai-flex bbai-flex-col lg:bbai-flex-row bbai-w-full bbai-mb-[10px] bbai-relative bbai-items-center"
      >
        <span className="bbai-w-full lg:bbai-w-[35%] bbai-pr-[4%] bbai-box-border bbai-flex lg:bbai-justify-end">
          Decorative
        </span>
        <label className="bbai-relative bbai-flex bbai-items-center bbai-cursor-pointer">
          <input
            type="checkbox"
            id="decorative"
            name="decorative"
            className="bbai-sr-only bbai-peer"
            onClick={(e) => updateDecorative(e.target.checked)}
            checked={decorativeFlag}
          />
          <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
        </label>
      </div>
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.altText}
        path={initialValues.path}
        status={status.altTextStatus}
        triggerList={tooltipTexts.altText}
        checkboxValue={checkbox.altText}
        updateCheckbox={updateCheckbox}
        setSavingText={setSavingText}
        initialValue={initialValues.altText}
        decorative={decorativeFlag}
        postId={postId}
        name="altText"
        watchField={watchField}
        label="Alternative Text"
        type="area"
        license={license}
      />
      <div className="bbai-text-xs bbai-mb-3 bbai-w-[65%] bbai-float-right">
        <a
          tabindex={-1}
          href="https://www.w3.org/WAI/tutorials/images/decision-tree/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn how to describe the purpose of the image
        </a>
        . Leave empty if the image is purely decorative.
      </div>
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.title}
        triggerList={tooltipTexts.title}
        watchField={watchField}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.title}
        setSavingText={setSavingText}
        license={license}
        initialValue={initialValues.title}
        postId={postId}
        name="title"
        label="Title"
        type="text"
      />
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.fileName}
        watchField={watchField}
        status={status.fileNameStatus}
        triggerList={tooltipTexts.fileName}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.fileName}
        setSavingText={setSavingText}
        license={license}
        initialValue={initialValues.fileName}
        path={initialValues.path}
        postId={postId}
        name="fileName"
        label="File Name"
        type="text"
      />
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.caption}
        watchField={watchField}
        path={initialValues.path}
        triggerList={tooltipTexts.caption}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.caption}
        setSavingText={setSavingText}
        license={license}
        initialValue={initialValues.caption}
        postId={postId}
        name="caption"
        label="Caption"
        type="area"
      />
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.description}
        watchField={watchField}
        triggerList={tooltipTexts.description}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.description}
        setSavingText={setSavingText}
        license={license}
        initialValue={initialValues.description}
        postId={postId}
        name="description"
        label="Description"
        type="area"
      />
      <TextInputModal
        url={initialValues?.url}
        circleColor={circleColor.slug}
        watchField={watchField}
        triggerList={tooltipTexts.slug}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.slug}
        setSavingText={setSavingText}
        license={license}
        initialValue={initialValues.slug}
        postId={postId}
        name="slug"
        label="Slug"
        type="text"
      />
      <TextInputModal
        url={initialValues?.url}
        updateCheckbox={updateCheckbox}
        checkboxValue={checkbox.url}
        watchField={watchField}
        triggerList={tooltipTexts.slug}
        setSavingText={setSavingText}
        license={license}
        tabindex={-1}
        readOnly
        disabled={true}
        initialValue={initialValues.url}
        postId={postId}
        customStyle={'bbai-bg-[#f0f0f1]'}
        name="url"
        label="File URL"
        type="text"
      />
      <div className="bbai-text-xs bbai-mb-3 bbai-w-[65%] bbai-float-right">
        <button
          onClick={handleCopy}
          type="button"
          class="button button-small copy-attachment-url"
          data-clipboard-target="#attachment-details-two-column-copy-link"
        >
          Copy URL to clipboard
        </button>
      </div>
      {pageLoading && <Loader />}
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
    </div>
  );
}
