import { Routes, Route, useLocation } from 'react-router-dom';
import React, { useEffect } from 'react';
import routes from './routes';
import '../node_modules/pagedone/src/css/pagedone.css';
import { useSelector } from 'react-redux';
import { fecthLicense } from './redux/actions/licenseAction';

const App = () => {
  const location = useLocation();

  const license = useSelector((state) => state.license.license);
// created
  useEffect(() => {
    fecthLicense();
  }, []);
// useeffect
  useEffect(() => {
    const currentUrl = location.pathname + location.hash;
    const menuItems = document.querySelectorAll('ul.wp-submenu a');
    console.log('CURRENT URL: ', currentUrl);
    menuItems.forEach((menuItem) => {
      if (menuItem.href.includes(currentUrl)) {
        console.log('ADDED CURRENT');
        menuItem.classList.add('font-bold');
        menuItem.style.color = 'white';
      } else {
        menuItem.classList.remove('font-bold');
        menuItem.style.color = '';
        console.log('REMOVE CURRENT');
      }
    });

    document.addEventListener('DOMContentLoaded', () => {
      const root = document.querySelector('span.setting[data-setting="title"]');
      console.log(root);
      if (root) {
        console.log(root);
        // ReactDOM.render(<MyComponent />, root);
      }
    });
  }, [location]);
  // methods
  const filterRoute = (routes) => {
    if(!license?.license){
      routes = routes.filter((data)=> !data.pro)
    }
    return routes
  }

  return (
    <div className="App">
      <Routes>
        {routes.map((route, index) => (
          <Route key={index} path={route.path} element={<route.element />}>
            {filterRoute(route.child).map((child, index) => (
              <Route path={child.path} element={<child.element />} />
            ))}
          </Route>
        ))}
      </Routes>
    </div>
  );
};

export default App;
