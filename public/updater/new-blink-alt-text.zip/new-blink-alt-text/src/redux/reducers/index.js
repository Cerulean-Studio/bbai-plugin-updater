import { combineReducers } from "redux";
import licenseReducer from "./licenseReducer";
import utilReducer from "./utilReducer";
import settingReducer from "./settingReducer";
import generatorReducer from "./generatorReducer";
import promptReducer from "./promptReducer";
import roleRestriction from "./roleRestriction";
import limitAiReducer from "./limitAiReducer";
import utilitiesReducer from "./utilitiesReducer";
import scheduleReducer from "./scheduleReducer";
export default combineReducers({
    license: licenseReducer,
    util: utilReducer,
    setting: settingReducer,
    generator: generatorReducer,
    prompt: promptReducer,
    roleRestriction: roleRestriction,
    limitAi: limitAiReducer,
    utilities: utilitiesReducer,
    schedule: scheduleReducer
})