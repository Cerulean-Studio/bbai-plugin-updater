import { GET_SCHEDULE, SAVE_SCHEDULE } from '../actions/types';

const initialState = {
  isLoading: true,
  schedule: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_SCHEDULE:
      return {
        ...state,
        schedule: action.payload,
        isLoading: false,
      };
    case SAVE_SCHEDULE:
      return {
        ...state,
        schedule: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
