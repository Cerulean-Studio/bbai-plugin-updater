import { GET_LIMIT_AI, SAVE_LIMIT_AI } from '../actions/types';

const initialState = {
  isLoading: true,
  prompt: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_LIMIT_AI:
      return {
        ...state,
        limitAi: action.payload,
        isLoading: false,
      };
    case SAVE_LIMIT_AI:
      return {
        ...state,
        limitAi: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
