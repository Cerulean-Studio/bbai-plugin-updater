import { GET_ROLE_RESTRICTION, SAVE_ROLE_RESTRICTION } from '../actions/types';

const initialState = {
  isLoading: true,
  roleRestriction: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_ROLE_RESTRICTION:
      return {
        ...state,
        roleRestriction: action.payload,
        isLoading: false,
      };
    case SAVE_ROLE_RESTRICTION:
      return {
        ...state,
        roleRestriction: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
