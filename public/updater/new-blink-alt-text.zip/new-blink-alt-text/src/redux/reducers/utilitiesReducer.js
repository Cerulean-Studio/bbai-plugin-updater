import { GET_UTILITIES, SAVE_UTILITIES } from '../actions/types';

const initialState = {
  isLoading: true,
  prompt: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_UTILITIES:
      return {
        ...state,
        utilities: action.payload,
        isLoading: false,
      };
    case SAVE_UTILITIES:
      return {
        ...state,
        utilities: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
