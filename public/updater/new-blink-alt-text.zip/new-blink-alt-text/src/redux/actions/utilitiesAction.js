import { GET_UTILITIES, SAVE_UTILITIES } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchUtilities = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/utilities`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_UTILITIES, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};


export const saveUtilities = async (data) => {
  try {
    const formData = new FormData();
    formData.append('regenerateAltText', data.regenerateAltText);
    formData.append('sanitizeFileName', data.sanitizeFileName);
    const response = await axios.post(`${config.API_URL}/utilities`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_UTILITIES, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};