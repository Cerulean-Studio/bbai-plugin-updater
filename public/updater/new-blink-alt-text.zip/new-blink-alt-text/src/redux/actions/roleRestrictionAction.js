import { GET_ROLE_RESTRICTION, SAVE_ROLE_RESTRICTION } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchRoleRestriction = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/role_restriction`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_ROLE_RESTRICTION, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};


export const saveRoleRestriction = async (data) => {
  try {
    const formData = new FormData();
    formData.append('featureRestriction', data.featureRestriction);
    data.individualAttribute.forEach((item, index) => {
      formData.append(`individualAttribute[${index}]`, item);
    });
    
    data.bulkGeneration.forEach((item, index) => {
      formData.append(`bulkGeneration[${index}]`, item);
    });
    
    data.setting.forEach((item, index) => {
      formData.append(`setting[${index}]`, item);
    });
    const response = await axios.post(`${config.API_URL}/role_restriction`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_ROLE_RESTRICTION, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};