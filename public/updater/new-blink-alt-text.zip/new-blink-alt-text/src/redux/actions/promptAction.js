import { GET_PROMPT, SAVE_PROMPT } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchPrompt = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/prompt`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_PROMPT, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const checkApiKey = async (apiKey) => {
  try {
    const formData = new FormData();
    formData.append('api_key', apiKey);
    const response = await axios.get(`https://api.openai.com/v1/engines`, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });
    // console.log("check apikey redux", response.data);
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    return error;
  }
};

export const savePrompt = async (data) => {
  try {
    const formData = new FormData();
    formData.append('websiteTopic', data.websiteTopic);
    formData.append('toneVoice', data.toneVoice);
    formData.append('audienceDesc', data.audienceDesc);
    for (let i = 0; i < data.seoKeywords.length; i++) {
      formData.append('seoKeywords[]', data.seoKeywords[i]);
    }
    const response = await axios.post(`${config.API_URL}/prompt`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_PROMPT, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const removeSettings = async (data) => {
  try {
    const response = await axios.post(`${config.API_URL}/deactivated-settings`, {
      headers: {
        Accept: 'application/json',
      },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
