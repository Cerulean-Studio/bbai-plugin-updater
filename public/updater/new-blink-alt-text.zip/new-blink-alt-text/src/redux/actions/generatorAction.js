import { GET_POSTS } from "./types";
import config from "../../config";
import axios from "axios";
import { store } from "../store";

const { dispatch } = store;

export const fecthPosts = async (search, orderBy, orderDirection) => {
	// console.log(window.location.origin)
	try {
		const url = new URL(`${config.API_URL}/posts`);
		url.searchParams.append("search", search);
		url.searchParams.append("order_by", orderBy);
		url.searchParams.append("order_direction", orderDirection);
		const response = await axios.get(url, {
			headers: {
				Accept: "application/json",
			},
		});
		// console.log('posts redux', response.data);
		dispatch({ type: GET_POSTS, payload: response.data });
	} catch (error) {
		console.error("Error fetching data:", error);
	}
};

export const saveGenerate = async (data, postId, urImg) => {
	try {
		const dataParse = JSON.parse(data);
		// console.log("dataParse alt", dataParse.alt_text);
    // console.log("dataParse caption", dataParse.caption);
    // console.log("dataParse description", dataParse.description);

		const formData = new FormData();
		// // for (let i = 0; i < dataParse.data.length; i++) {
		// // 	formData.append("alt_text", dataParse[i].alt_text);
		// //   formData.append("caption", dataParse[i].caption);
		// //   formData.append("description", dataParse[i].description);
		// // }
    formData.append("alt_text", dataParse.alt_text);
    formData.append("caption", dataParse.caption);
    formData.append("description", dataParse.description);
		for (let i = 0; i < postId.length; i++) {
			formData.append("post_id", postId[i]);
		}
		for (let i = 0; i < urImg.length; i++) {
			formData.append("img_url", urImg[i]);
		}
		const response = await axios.post(`${config.API_URL}/generates`, formData, {
			headers: {
				"Content-Type": "application/json",
			},
		});
		console.log("save generate redux", response);
		return response;
	} catch (error) {
		console.error("Error fetching data:", error);
		return error;
	}
};
