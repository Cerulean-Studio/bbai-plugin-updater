import { GET_SETTINGS, SAVE_SETTINGS } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchSettings = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/settings`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_SETTINGS, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const checkApiKey = async (apiKey) => {
  try {
    const formData = new FormData();
    formData.append('api_key', apiKey);
    const response = await axios.get(`https://api.openai.com/v1/models`, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });
    // console.log("check apikey redux", response.data);
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
    return error;
  }
};

export const saveSetting = async (data) => {
  console.log('data params', data);
  try {
    const formData = new FormData();
    formData.append('apiKey', data.apiKey);
    formData.append('aiModel', data.aiModel);
    formData.append('outputLanguage', data.outputLanguage);
    formData.append('globalConfig', data.globalConfig);
    // for (let i = 0; i < data.outputGenerator.length; i++) {
    //   formData.append('output_generator[]', data.outputGenerator[i]);
    // }
    formData.append('automation', data.automation);
    formData.append('generateType', data.generateType);
    formData.append('aiModelaltText', data.aiModelaltText);
    formData.append('aiModelcaption', data.aiModelcaption);
    formData.append('aiModeldescription', data.aiModeldescription);
    formData.append('aiModelfilename', data.aiModelfilename);
    formData.append('aiModelslug', data.aiModelslug);
    formData.append('aiModeltitle', data.aiModeltitle);
    formData.append('individualTitle', data.individualTitle);
    formData.append('individualCaption', data.individualCaption);
    formData.append('individualSlug', data.individualSlug);
    formData.append('individualAltText', data.individualAltText);
    formData.append('individualFileName', data.individualFileName);
    formData.append('individualDescription', data.individualDescription);
    formData.append('individualDecorative', data.individualDecorative);
    const response = await axios.post(`${config.API_URL}/settings`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_SETTINGS, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const removeSettings = async (data) => {
  try {
    const response = await axios.post(`${config.API_URL}/deactivated-settings`, {
      headers: {
        Accept: 'application/json',
      },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
