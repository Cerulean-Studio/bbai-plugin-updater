import React from 'react';


function TableCustom({ columns = [], children }) {
  return (
    <div class="bbai-flex bbai-flex-col">
      <div class="bbai-overflow-x-auto">
        <div class="bbai-min-w-full bbai-inline-block bbai-align-middle">
          <div class="bbai-overflow-hidden bbai-border bbai-rounded-lg bbai-border-gray-300">
            <table class="bbai-min-w-full bbai-rounded-xl">
              <thead>
                <tr class="bbai-bg-gray-50">
                  {columns.map((column) => (
                    <th
                      scope="col"
                      class="bbai-p-5 bbai-text-left bbai-text-sm bbai-leading-6 bbai-font-semibold bbai-text-gray-900 bbai-capitalize"
                    >
                      {column.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody class="bbai-divide-y bbai-divide-gray-300">
                {children}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TableCustom;
