import React from 'react';

const Button = ({
  type = 'button',
  onClick,
  children,
  color = 'bbai-bg-primary',
  hoverColor = 'hover:bbai-bg-[#6e40ca]',
  textColor = 'bbai-text-white',
  size = 'md',
  customStyle = '',
  loading,
  disabled = false,
  ...props
}) => {
  const buttonSize = size === 'sm' ? 'bbai-py-2 bbai-px-2' : size === 'lg' ? 'bbai-py-3.5 bbai-px-8' : 'bbai-py-3 bbai-px-7';

  return (
    <button
      type={type}
      onClick={onClick}
      className={`${buttonSize} bbai-text-sm ${color} hover:${hoverColor} ${textColor} bbai-border-0 bbai-flex bbai-items-center bbai-justify-center bbai-rounded-lg bbai-cursor-pointer bbai-font-normal xl:bbai-font-semibold bbai-text-center bbai-shadow-xs bbai-transition-all bbai-duration-500 ${customStyle}`}
      disabled={loading || disabled}
      {...props}
    >
      {loading && (
        <span
          class="bbai-animate-spin bbai-inline-block bbai-w-4 bbai-h-4 bbai-border-[3px] bbai-border-current bbai-border-t-transparent bbai-rounded-full bbai-mr-2"
          role="status"
          aria-label="loading"
        ></span>
      )}

      {children}
    </button>
  );
};

export default Button;
