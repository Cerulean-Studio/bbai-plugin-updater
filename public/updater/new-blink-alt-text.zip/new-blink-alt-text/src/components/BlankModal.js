import React from 'react';
import { Description, Dialog, DialogPanel, DialogTitle, DialogBackdrop } from '@headlessui/react';

/**
 * BlankModal Component
 *
 * A flexible and customizable Modal component that can display any type of content (not limited to text).
 * The content is passed as a child from the parent component, allowing you to render not just text, 
 * but also React elements, JSX components, or other complex structures within the modal.
 *
 * Props:
 * - `children` (ReactNode): The content to be displayed inside the modal. This can be text, JSX, or any valid React element.
 *
 */

const BlankModal = ({
  handleClose,
  isOpen,
  width = 'bbai-w-full',
  maxWidth = 'bbai-max-w-sm',
  children
}) => {
  return (
    <Dialog
      open={isOpen}
      onClose={handleClose}
      transition
      className="bbai-relative bbai-z-[999] bbai-transition bbai-duration-200 bbai-ease-out data-[closed]:bbai-opacity-0"
    >
      {/* The backdrop, rendered as a fixed sibling to the panel container */}
      <DialogBackdrop className="bbai-fixed bbai-inset-0 bbai-bg-black/30" />

      {/* Full-screen container to center the panel */}
      <div className="bbai-fixed bbai-inset-0 bbai-flex bbai-items-center bbai-justify-center bbai-w-screen bbai-p-4">
        {/* The actual dialog panel  */}
        <DialogPanel className={`bbai-flex bbai-flex-col ${width} ${maxWidth} bbai-p-6 bbai-gap-6 bbai-bg-white bbai-rounded-lg bbai-min-h-64`}>
          {children}
        </DialogPanel>
      </div>
    </Dialog>
  );
};

export default BlankModal;
