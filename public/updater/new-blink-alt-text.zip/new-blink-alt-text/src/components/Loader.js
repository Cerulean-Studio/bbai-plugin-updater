import React from 'react';

const Loader = () => {
  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 999999,
      }}
    >
      <span
        class="bbai-animate-spin bbai-inline-block bbai-w-6 bbai-h-6 bbai-border-[3px] bbai-border-current bbai-border-t-transparent bbai-border-solid bbai-text-white bbai-rounded-full"
        role="status"
        aria-label="loading"
      ></span>
    </div>
  );
};

export default Loader;
