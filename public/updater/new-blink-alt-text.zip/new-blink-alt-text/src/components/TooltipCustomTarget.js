import React from 'react';

/**
 * TooltipCustomTarget component
 * 
 * This component is used to wrap any child component and display a tooltip when hovered.
 * 
 * @param {Object} props - The properties object.
 * @param {string} props.tooltipText - The text to display inside the tooltip.
 * @param {string} props.customStyle - Additional custom CSS classes for the tooltip.
 * @param {React.ReactNode} props.children - The child components to wrap with the tooltip.
 * 
 * @returns {JSX.Element} The TooltipCustomTarget component.
 */

export default function TooltipCustomTarget({tooltipText, customStyle, children}) {
  return (
    <span className="bbai-ml-2 tooltip">
      {children}
      <div className={`tooltiptext ${customStyle}`}>{tooltipText}</div>
    </span>
  );
}
