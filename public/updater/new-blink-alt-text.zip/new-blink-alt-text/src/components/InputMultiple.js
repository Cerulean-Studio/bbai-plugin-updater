import React, { useEffect, useState } from 'react';

const TextInput = ({
  id = '',
  label = '',
  name = '',
  placeholder = '',
  type = 'text',
  required = false,
  customStyle = '',
  register,
  errors,
  tooltipInfo,
  initialValue = [],
  ref,
  onChange,
  options = [],
  ...props
}) => {
  // states
  const [value, setValue] = useState(initialValue);
  const [inputValue, setInputValue] = useState('');
  // useEffect(() => {
  //   setValue(initialValue);
  
  // }, [initialValue])
  
  // methods
  const addValue = (e) => {
    e.preventDefault();

    if (e.target.value != '') {
      // Check if the value already exists in the array
      if (!value.includes(e.target.value)) {
        let tmp = [...value, e.target.value];
        setValue(tmp);
        onChange(tmp);
        setInputValue('');
      }
    }
  };
  const removeValue = (index) => {
    let tmp = [...value];
    tmp.splice(index, 1);
    setValue(tmp);
    onChange(tmp);
  };
  return (
    <div className="bbai-relative">
      {label && (
        <label
          htmlFor={id}
          className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900"
        >
          {label}
          {tooltipInfo && (
            <span className="bbai-ml-2">
              <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M8 16.5C6.41775 16.5 4.87103 16.0308 3.55544 15.1518C2.23985 14.2727 1.21447 13.0233 0.608967 11.5615C0.00346627 10.0997 -0.15496 8.49113 0.153721 6.93928C0.462403 5.38743 1.22433 3.96197 2.34315 2.84315C3.46197 1.72433 4.88743 0.962403 6.43928 0.653721C7.99113 0.34504 9.59966 0.503466 11.0615 1.10897C12.5233 1.71447 13.7727 2.73985 14.6518 4.05544C15.5308 5.37103 16 6.91775 16 8.5C15.9977 10.621 15.1541 12.6545 13.6543 14.1543C12.1545 15.6541 10.121 16.4977 8 16.5ZM8 2.1C6.7342 2.1 5.49683 2.47536 4.44435 3.1786C3.39188 3.88184 2.57157 4.88138 2.08717 6.05083C1.60277 7.22028 1.47603 8.5071 1.72298 9.74858C1.96992 10.9901 2.57946 12.1304 3.47452 13.0255C4.36958 13.9205 5.50995 14.5301 6.75142 14.777C7.9929 15.024 9.27973 14.8972 10.4492 14.4128C11.6186 13.9284 12.6182 13.1081 13.3214 12.0556C14.0246 11.0032 14.4 9.7658 14.4 8.5C14.3981 6.8032 13.7232 5.17644 12.5234 3.97662C11.3236 2.7768 9.6968 2.10191 8 2.1Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M8 12.5C7.78783 12.5 7.58435 12.4157 7.43432 12.2657C7.28429 12.1157 7.2 11.9122 7.2 11.7V8.5H6.4C6.18783 8.5 5.98435 8.41572 5.83432 8.26569C5.68429 8.11566 5.6 7.91218 5.6 7.7C5.6 7.48783 5.68429 7.28435 5.83432 7.13432C5.98435 6.98429 6.18783 6.9 6.4 6.9H8C8.21217 6.9 8.41566 6.98429 8.56569 7.13432C8.71572 7.28435 8.8 7.48783 8.8 7.7V11.7C8.8 11.9122 8.71572 12.1157 8.56569 12.2657C8.41566 12.4157 8.21217 12.5 8 12.5Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M9.6 12.5H6.4C6.18783 12.5 5.98435 12.4157 5.83432 12.2657C5.68429 12.1157 5.6 11.9122 5.6 11.7C5.6 11.4878 5.68429 11.2843 5.83432 11.1343C5.98435 10.9843 6.18783 10.9 6.4 10.9H9.6C9.81217 10.9 10.0157 10.9843 10.1657 11.1343C10.3157 11.2843 10.4 11.4878 10.4 11.7C10.4 11.9122 10.3157 12.1157 10.1657 12.2657C10.0157 12.4157 9.81217 12.5 9.6 12.5Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M7.6 6.1C8.26274 6.1 8.8 5.56274 8.8 4.9C8.8 4.23726 8.26274 3.7 7.6 3.7C6.93726 3.7 6.4 4.23726 6.4 4.9C6.4 5.56274 6.93726 6.1 7.6 6.1Z"
                  fill="#B5B5C3"
                />
              </svg>
            </span>
          )}
        </label>
      )}
      <div
        className={`bbai-w-full bbai-px-4 bbai-py-2 bbai-text-base bbai-font-normal bbai-leading-relaxed bbai-text-gray-900 bbai-placeholder-gray-400 bbai-bg-transparent bbai-border bbai-border-gray-300 bbai-rounded-lg bbai-shadow-xs bbai-focus:outline-none ${customStyle} bbai-flex bbai-gap-2 bbai-flex-wrap`}
      >
        <div className="bbai-flex bbai-gap-1 bbai-flex-wrap">
          {Array.isArray(value)
            ? value.map((data, index) => (
                <div className="bbai-p-1 bbai-rounded bbai-flex bbai-bg-[#F3F4F6] bbai-items-center">
                  <div className="bbai-mr-2 bbai-font-medium bbai-text-xs">{data}</div>
                  <svg
                    className="bbai-cursor-pointer"
                    onClick={() => removeValue(index)}
                    width="10"
                    height="10"
                    viewBox="0 0 10 10"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <g clip-path="url(#clip0_2134_31001)">
                      <path
                        d="M5.90741 5L9.30409 1.60332C9.36538 1.54412 9.41427 1.47331 9.4479 1.39502C9.48153 1.31672 9.49924 1.23252 9.49998 1.14731C9.50072 1.0621 9.48448 0.977595 9.45221 0.898729C9.41995 0.819863 9.3723 0.748212 9.31204 0.687958C9.25179 0.627705 9.18014 0.580054 9.10127 0.547787C9.0224 0.515521 8.9379 0.499284 8.85269 0.500024C8.76748 0.500765 8.68328 0.518468 8.60498 0.5521C8.52669 0.585733 8.45588 0.634621 8.39668 0.695913L5 4.09259L1.60332 0.695913C1.48229 0.579017 1.32019 0.514333 1.15193 0.515796C0.983666 0.517258 0.822712 0.584748 0.70373 0.70373C0.584748 0.822712 0.517258 0.983666 0.515796 1.15193C0.514333 1.32019 0.579017 1.48229 0.695913 1.60332L4.09259 5L0.695913 8.39668C0.634621 8.45588 0.585733 8.52669 0.5521 8.60498C0.518468 8.68328 0.500765 8.76748 0.500024 8.85269C0.499284 8.9379 0.515521 9.0224 0.547787 9.10127C0.580054 9.18014 0.627705 9.25179 0.687958 9.31204C0.748212 9.3723 0.819863 9.41995 0.898729 9.45221C0.977595 9.48448 1.0621 9.50072 1.14731 9.49998C1.23252 9.49924 1.31672 9.48153 1.39502 9.4479C1.47331 9.41427 1.54412 9.36538 1.60332 9.30409L5 5.90741L8.39668 9.30409C8.51771 9.42098 8.67981 9.48567 8.84807 9.4842C9.01633 9.48274 9.17729 9.41525 9.29627 9.29627C9.41525 9.17729 9.48274 9.01633 9.4842 8.84807C9.48567 8.67981 9.42098 8.51771 9.30409 8.39668L5.90741 5Z"
                        fill="#6B7280"
                      />
                    </g>
                    <defs>
                      <clipPath id="clip0_2134_31001">
                        <rect width="10" height="10" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                </div>
              ))
            : ''}
        </div>
        {type === 'text' ? (
          <input
            type={type}
            id={id}
            name={name}
            placeholder={placeholder}
            required={required}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className={`bbai-flex-1 bbai-p-2 bbai-text-base bbai-font-normal bbai-border-none bbai-focus:outline-none bbai-focus:ring-0 bbai-bg-transparent`}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === 'Tab') {
                addValue(e);
              }
            }}
          />
        ) : (
          <select
            value={null}
            onChange={(e) => {
              addValue(e);
              setInputValue(e.target.value);
            }}
            id={name + '-select'}
            class={`bbai-flex-1 bbai-p-2 bbai-text-base bbai-font-normal bbai-border-none bbai-focus:outline-none bbai-focus:ring-0 bbai-bg-transparent`}
          >
            {options.map((data, idx) => (
              <option key={idx} value={data.value}>
                {data.label}
              </option>
            ))}
          </select>
        )}
      </div>
      {errors[name] && <p className="bbai-mt-2 bbai-text-xs bbai-text-red-500">This field is required</p>}
    </div>
  );
};

export default TextInput;
