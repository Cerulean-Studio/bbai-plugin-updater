<?php

namespace BLINK_ALT_TEXT;

class BulkGenerateRoute
{

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'create_rest_routes']);
        add_action('bat_bulk_generate', [$this, 'bat_bulk_generate_cronjob']);
    }

    public function create_rest_routes()
    {
        register_rest_route('blink-alt-text/v1', '/generate-all-count', [
            'methods' => 'POST',
            'callback' => [$this, 'generate_all_count'],
            'permission_callback' => [$this, 'generate_all_count_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/bulk-generate', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_generate'],
            'permission_callback' => [$this, 'bulk_generate_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/bulk-generate-on-page', [
            'methods' => 'POST',
            'callback' => [$this, 'bulk_generate_on_page'],
            'permission_callback' => [$this, 'bulk_generate_on_page_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/stop-bulk-generate', [
            'methods' => 'POST',
            'callback' => [$this, 'stop_bulk_generate'],
            'permission_callback' => [$this, 'stop_bulk_generate_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/stop-queue-bulk-generate', [
            'methods' => 'POST',
            'callback' => [$this, 'stop_queue_bulk_generate'],
            'permission_callback' => [$this, 'stop_queue_bulk_generate_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/turn-off-failed-notify', [
            'methods' => 'POST',
            'callback' => [$this, 'turn_off_failed_notify'],
            'permission_callback' => [$this, 'turn_off_failed_notify_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/get-failed-notify', [
            'methods' => 'get',
            'callback' => [$this, 'get_failed_notify'],
            'permission_callback' => [$this, 'get_failed_notify_permission']
        ]);
        register_rest_route('blink-alt-text/v1', '/status-bulk-generate', [
            'methods' => 'GET',
            'callback' => [$this, 'status_bulk_generate'],
            'permission_callback' => [$this, 'status_bulk_generate_permission']
        ]);

        register_rest_route('blink-alt-text/v1', '/status-on-going-bulk-generate', [
            'methods' => 'GET',
            'callback' => [$this, 'status_on_going_bulk_generate'],
            'permission_callback' => [$this, 'status_on_going_bulk_generate_permission']
        ]);

        register_rest_route('blink-alt-text/v1', '/trigger-start-bulk-generate', [
            'methods' => 'POST',
            'callback' => [$this, 'bat_bulk_generate_cronjob'],
            'permission_callback' => [$this, 'bat_bulk_generate_cronjob_permission']
        ]);
    }

    public function generate_all_count($req)
    {
        global $wpdb;
        $data = $req->get_params();
        // $filter = $data['filter'];
        if ($data['modeBulk'] == 'all') {
            $filter = array(
                'altText' => true,
                'title' => true,
                'caption' => true,
                'slug' => true,
                'description' => true,
                'fileName' => true
            );
        } else {
            $filter = $data['filter'];
        }
        $prepareQuery = $this->prepareQueryBulkGenerate($filter, $data);
        $select_clause = $prepareQuery['select_clause'];
        $where_clause = $prepareQuery['where_clause'];
        $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
        $mediaWithEmpties = "SELECT {$select_clause}
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
            LEFT JOIN {$media_detail} md ON p.ID = md.post_id
            WHERE p.post_type = 'attachment'
            AND p.post_status = 'inherit'
            {$where_clause}
            ORDER BY p.ID DESC
            ";
        $mediaWithEmpties = $wpdb->get_results($mediaWithEmpties);
        $response = new \WP_REST_Response($mediaWithEmpties);
        $response->set_status(200);
        return $response;
    }

    public function generate_all_count_permission()
    {
        $roleAndCapabilities = new RoleAndCapabilities();
        return $roleAndCapabilities->user_capable('bat_bulk_generate');
        // return current_user_can('bat_bulk_generate');
    }

    public function bulk_generate($req)
    {
        global $wpdb;
        $data = $req->get_params();
        if ($data['modeBulk'] == 'all') {
            $filter = array(
                'altText' => true,
                'title' => true,
                'caption' => true,
                'slug' => true,
                'description' => true,
                'fileName' => true
            );
        } else {
            $filter = $data['filter'];
        }
        $prepareQuery = $this->prepareQueryBulkGenerate($filter, $data);
        $select_clause = $prepareQuery['select_clause'];
        $where_clause = $prepareQuery['where_clause'];
        $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
        $mediaWithEmpties = "SELECT {$select_clause}
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
            LEFT JOIN {$media_detail} md ON p.ID = md.post_id
            WHERE p.post_type = 'attachment'
            AND p.post_status = 'inherit'
            {$where_clause}
            ORDER BY p.ID DESC
            ";
        if ($data['generateType'] == 'partial') {
            $mediaWithEmpties .= 'LIMIT ' . $data['generateLimit'];
        }
        $mediaWithEmpties = $wpdb->get_results($mediaWithEmpties);
        $response = new \WP_REST_Response($mediaWithEmpties);
        $response->set_status(200);
        if (isset($mediaWithEmpties) && !empty($mediaWithEmpties)) {
            $batch_query = "SELECT MAX(batch) as max_batch FROM {$wpdb->prefix}blink_alt_text_queue";
            $max_batch = $wpdb->get_var($batch_query);
            $new_batch = $max_batch ? $max_batch + 1 : 1;
            // for ($j = 0; $j < 15000; $j++) {
            // foreach ($mediaWithEmpties as $data) {
            //     $queue_data = array(
            //         'batch' => $new_batch,
            //         'post_id' => $data->ID,
            //         'done' => 0,
            //         'generateAltText' => empty($data->altTextBlink) ? (empty($data->altText) ? 1 : 0) : 0,
            //         'generateTitle' => empty($data->post_title) ? 1 : 0,
            //         'generateCaption' => empty($data->post_excerpt) ? 1 : 0,
            //         'generateSlug' => empty($data->post_name) ? 1 : 0,
            //         'generateDescription' => empty($data->post_content) ? 1 : 0,
            //         'generateFileName' => empty($data->fileName) ? 1 : 0
            //     );
            //     $wpdb->insert($wpdb->prefix . 'blink_alt_text_queue', $queue_data);
            // }
            for ($i = 0; $i < count($mediaWithEmpties); $i++) {
                // Perform the check every 1000 iterations
                if ($i % 1000 === 0 && $i != 0) {
                    error_log('Checking stop flag by user on iteration: ' . $i);
                    $table_name_options = $wpdb->prefix . 'options';
                    $flagStop = $wpdb->get_var(
                        "SELECT option_value FROM $table_name_options WHERE option_name = 'blink_alt_text_bulk_stop_queue_flag' LIMIT 1"
                    );
                    // Update $flagStop based on the option value
                    if ($flagStop == '1') {
                        $flagStop = true;
                    } else {
                        $flagStop = false;
                    }
                    if ($flagStop) {
                        error_log('Queueing stopped by user');
                        update_option('blink_alt_text_bulk_stop_queue_flag', false);
                        $response = new \WP_REST_Response();
                        $response->set_status(409);
                        return $response;
                    }
                }

                $data = $mediaWithEmpties[$i];
                // an attribute have to exist and empty to be generated
                // explanation:
                //    'generateTitle' => property_exists($data, 'post_title')
                //             ? (empty($data->post_title) ? 1 : 0)
                //             : 0,
                // generateTitle will have value 1 (generate) if post_title attribute exist and empty
                $queue_data = array(
                    'batch' => $new_batch,
                    'post_id' => $data->ID,
                    'done' => 0,
                    // 'generateAltText' => (isset($data->altTextBlink) && ($data->altTextBlink === '' || $data->altTextBlink === null))
                    //     ? (empty($data->altText) ? 1 : 0)
                    //     : 0,
                    'generateAltText' => (property_exists($data, 'altTextBlink') || property_exists($data, 'altText'))
                        ? (empty($data->altTextBlink) ? (empty($data->altText) ? 1 : 0) : 0)
                        : 0,
                    'generateTitle' => property_exists($data, 'post_title')
                        ? (empty($data->post_title) ? 1 : 0)
                        : 0,
                    'generateCaption' => property_exists($data, 'post_excerpt')
                        ? (empty($data->post_excerpt) ? 1 : 0)
                        : 0,
                    'generateSlug' => property_exists($data, 'post_name')
                        ? (empty($data->post_name) ? 1 : 0)
                        : 0,
                    'generateDescription' => property_exists($data, 'post_content')
                        ? (empty($data->post_content) ? 1 : 0)
                        : 0,
                    'generateFileName' => property_exists($data, 'fileName')
                        ? (empty($data->fileName) ? 1 : 0)
                        : 0,
                );
                error_log(json_encode($queue_data));

                $wpdb->insert($wpdb->prefix . 'blink_alt_text_queue', $queue_data);
                // sleep(1);
            }
            // }
        }
        if (count($mediaWithEmpties) >= 1) {
            error_log('Run bulk');
            update_option('blink_alt_text_bulk_started', true);
            update_option('blink_alt_text_bulk_stop_flag', false);
            // $this->custom_core_activate();
            // $this->bat_bulk_generate_cronjob();
        } else {
            error_log('All optimized');
            error_log(count($mediaWithEmpties));
        }
        return $response;
    }


    public function bulk_generate_permission()
    {
        return true;
    }

    public function bulk_generate_on_page($req)
    {
        $datas = $req->get_params();
        foreach ($datas['mediaUpdatesQueue'] as $data) {
            $media_url = wp_get_attachment_url($data['post_id']);
            $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
            $dataToUpdate = array();
            if ($data['altText'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'altText',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['altText'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }
            if ($data['title'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'title',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['title'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }

            if ($data['caption'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'caption',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['caption'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }

            if ($data['slug'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'slug',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['slug'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }

            if ($data['description'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'description',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['description'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }

            if ($data['fileName'] == true) {
                $payloadChatCompletion = array(
                    'fieldName' => 'fileName',
                    'post_image' => $media_url,
                );
                $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route, false);
                if ($generateField['status'] == true) {
                    $dataToUpdate['fileName'] = $generateField['value'];
                } else {
                    $response = new \WP_REST_Response($generateField);
                    $response->set_status(500);
                    return $response;
                }
            }
            $this->save_to_database($dataToUpdate, $data['post_id'], $media_url);
        }
        $response = new \WP_REST_Response();
        $response->set_status(200);
        return $response;
    }

    public function bulk_generate_on_page_permission()
    {
        return true;
    }

    public function stop_bulk_generate()
    {
        update_option('blink_alt_text_bulk_started', false);
        update_option('blink_alt_text_bulk_stop_flag', true);
        $response = new \WP_REST_Response();
        $response->set_status(200);
        return $response;
    }

    public function stop_bulk_generate_permission()
    {
        return true;
    }

    public function turn_off_failed_notify()
    {
        update_option('blink_alt_text_bulk_failed_notify', false);
        update_option('blink_alt_text_bulk_failed_message', '');
        $response = new \WP_REST_Response();
        $response->set_status(200);
        return $response;
    }

    public function turn_off_failed_notify_permission()
    {
        return true;
    }

    public function get_failed_notify()
    {
        $notify = get_option('blink_alt_text_bulk_failed_notify', false);
        $message = get_option('blink_alt_text_bulk_failed_message', '');
        if ($notify == '1') {
            $notify = true;
        } else {
            $notify = false;
        }
        $response = new \WP_REST_Response(array('status' => $notify, 'message' => $message));
        $response->set_status(200);
        return $response;
    }

    public function get_failed_notify_permission()
    {
        return true;
    }

    public function stop_queue_bulk_generate()
    {
        update_option('blink_alt_text_bulk_stop_queue_flag', true);
        $response = new \WP_REST_Response();
        $response->set_status(200);
        return $response;
    }

    public function stop_queue_bulk_generate_permission()
    {
        return true;
    }

    public function status_bulk_generate()
    {
        global $wpdb;
        $status_query = "SELECT done, COUNT(*) as count 
                        FROM {$wpdb->prefix}blink_alt_text_queue 
                        WHERE batch = (SELECT MAX(batch) FROM {$wpdb->prefix}blink_alt_text_queue)
                        GROUP BY done";
        $status = $wpdb->get_results($status_query);
        $tmp = [
            'notDone' => 0,
            'done' => 0
        ];

        foreach ($status as $row) {
            if ($row->done == '0') {
                $tmp['notDone'] = (int) $row->count;
            } elseif ($row->done == '1') {
                $tmp['done'] = (int) $row->count;
            }
        }
        $response = new \WP_REST_Response($tmp);
        $response->set_status(200);
        return $response;
    }

    public function status_bulk_generate_permission()
    {
        return true;
    }

    public function status_on_going_bulk_generate()
    {
        $bulk_on_going = get_option('blink_alt_text_bulk_started', false);
        if ($bulk_on_going == '1') {
            $tmp = true;
        } else {
            $tmp = false;
        }
        $response = new \WP_REST_Response(array('status' => $tmp));
        $response->set_status(200);
        return $response;
    }

    public function status_on_going_bulk_generate_permission()
    {
        return true;
    }

    function custom_core_activate()
    {
        $startTime = get_option('blink_alt_text_start_time', '00:00');
        $timezone = get_option('blink_alt_text_timezone', 0);
        // if (wp_next_scheduled('bat_bulk_generate')) {
        //     wp_unschedule_event(wp_next_scheduled('bat_bulk_generate'), 'bat_bulk_generate_cronjob');
        // }
        // Clear the existing schedule for 'bat_bulk_generate'
        wp_clear_scheduled_hook('bat_bulk_generate');
        // wp_schedule_event(strtotime('today ' . $startTime . ' +' . $timezone . ' hours'), 'everyminute', 'bat_bulk_generate');
        wp_schedule_event(time(), 'hourly', 'bat_bulk_generate');
    }

    //   register_activation_hook(__FILE__, 'custom_core_activate');

    /**
     * Do whatever you want to do in the cron job.
     */
    function bat_bulk_generate_cronjob()
    {
        global $wpdb;
        $endReason = '';
        do {
            $table_name_queue = $wpdb->prefix . 'blink_alt_text_queue';
            $result_queue = $wpdb->get_results(
                "SELECT * FROM $table_name_queue WHERE batch = (SELECT MAX(batch) FROM $table_name_queue) AND done = 0 LIMIT 1"
            );
            if (empty($result_queue)) {
                update_option('blink_alt_text_bulk_started', false);
                $endReason = 'No more items to process';
                break;
            }

            wp_cache_delete('blink_alt_text_bulk_stop_flag', 'options');
            $table_name_options = $wpdb->prefix . 'options';
            $flagStop = $wpdb->get_var(
                "SELECT option_value FROM $table_name_options WHERE option_name = 'blink_alt_text_bulk_stop_flag' LIMIT 1"
            );
            error_log("result: " . $flagStop);
            error_log("Flag stop: " . $flagStop);

            // Update $flagStop based on the option value
            if ($flagStop == '1') {
                $flagStop = true;
            } else {
                $flagStop = false;
            }

            // Check if flag is set to stop
            if ($flagStop) {
                update_option('blink_alt_text_bulk_started', false);
                $endReason = 'Stopped by user';
                break;
            }
            if ($result_queue[0]) {
                $data = $result_queue[0];
                $media_url = wp_get_attachment_url($data->post_id);
                $extension = pathinfo($media_url, PATHINFO_EXTENSION);
                error_log($extension);
                $supported_extensions = ['png', 'jpeg', 'gif', 'webp', 'jpg'];
                if (!in_array($extension, $supported_extensions)) {
                    error_log('Extension not supported, continue to next loop');
                    $wpdb->update(
                        $table_name_queue,
                        array('done' => 1),
                        array('id' => $data->id),
                        array('%d'),
                        array('%d')
                    );
                    continue;
                }
                $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
                $dataToUpdate = array();
                if ($data->generateAltText == 1) {
                    error_log("Generate altText for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'altText',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['altText'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                if ($data->generateTitle == 1) {
                    error_log("Generate title for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'title',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['title'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                if ($data->generateCaption == 1) {
                    error_log("Generate Caption for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'caption',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['caption'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                if ($data->generateSlug == 1) {
                    error_log("Generate slug for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'slug',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['slug'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                if ($data->generateDescription == 1) {
                    error_log("Generate description for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'description',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['description'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                if ($data->generateFileName == 1) {
                    error_log("Generate fileName for post id: " . $data->post_id);
                    $payloadChatCompletion = array(
                        'fieldName' => 'fileName',
                        'post_image' => $media_url,
                    );
                    $generateField = $this->generateField($payloadChatCompletion, $chat_completion_route);
                    if ($generateField['status'] == true) {
                        $dataToUpdate['fileName'] = $generateField['value'];
                    } else {
                        $endReason = $generateField['value'];
                        break;
                    }
                }
                // Update result_queue's done status to 1
                $wpdb->update(
                    $table_name_queue,
                    array('done' => 1),
                    array('id' => $data->id),
                    array('%d'),
                    array('%d')
                );
                $this->save_to_database($dataToUpdate, $data->post_id, $media_url);
            }
            // error_log("Sleep 5 seconds");
            // usleep(10000000); // 500,000 microseconds = 0.5 seconds
        } while (($data && !empty($data)) || !$flagStop);
        // generate ended
        error_log("Generate ended: " . $endReason);
        update_option('blink_alt_text_bulk_started', false);
        update_option('blink_alt_text_bulk_stop_flag', true);
        // only return value when its failed because success condition already handled with interval on frontend
        if ($generateField['status'] == false) {
            error_log('Bulk Generate interupted');
            error_log(json_encode($generateField));
            $data = array(
                'message' => $generateField['value']
            );
            // option to notify user if generation is failed
            update_option('blink_alt_text_bulk_failed_notify', true);
            update_option('blink_alt_text_bulk_failed_message', $generateField['value']);
            $response = new \WP_REST_Response($data);
            $response->set_status(500);
            return $response;
        }
    }

    // research using for loop
    // function bat_bulk_generate_cronjob()
    // {
    //     // global $wpdb;
    //     // $table_name_queue = $wpdb->prefix . 'blink_alt_text_queue';
    //     // $result_queue = $wpdb->get_results(
    //     //     "SELECT * FROM $table_name_queue WHERE batch = (SELECT MAX(batch) FROM $table_name_queue) AND done = 0 LIMIT 1"
    //     // );
    //     // error_log(json_encode($result_queue));

    //     for ($i = 0; $i < 5; $i++) {
    //         if ($i >= 1) {
    //             $flagStop = get_option('blink_alt_text_bulk_stop_flag', false);
    //             error_log("Flag stop: " . $flagStop);

    //             // Update $flagStop based on the option value
    //             if ($flagStop == '1') {
    //                 $flagStop = true;
    //             } else {
    //                 $flagStop = false;
    //             }

    //             // Check if flag is set to stop
    //             if ($flagStop) {
    //                 error_log('Stopped by user');
    //                 update_option('blink_alt_text_bulk_started', false);
    //                 break;
    //             }
    //         }
    //         error_log("Iterasi ke - " . $i);
    //         usleep(3000000); // 500,000 microseconds = 0.5 seconds
    //     }
    //     // generate ended
    //     update_option('blink_alt_text_bulk_started', false);
    //     update_option('blink_alt_text_bulk_stop_flag', true);
    //     error_log("Generate ended");
    // }

    public function bat_bulk_generate_cronjob_permission()
    {
        return true;
    }

    public function save_to_database($data, $post_id, $media_url)
    {
        global $wpdb;
        // $table_name_media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
        // $wpdb->update(
        //     $table_name_media_detail,
        //     $dataToUpdate,
        //     array('post_id' => $post_id),
        //     array('%s'),
        //     array('%d')
        // );
        $generator_route = new \BLINK_ALT_TEXT\GeneratorRoute();
        $wpdb->show_errors(false);
        $wpdb->query('START TRANSACTION');
        try {
            $post = array(
                'ID' => $post_id,
            );
            if (isset($data['caption'])) {
                $post['post_excerpt'] = $data['caption'];
            }
            if (isset($data['title'])) {
                $post['post_title'] = $data['title'];
            }
            if (isset($data['slug'])) {
                $post['post_name'] = $data['slug'];
            }
            if (isset($data['description'])) {
                $post['post_content'] = $data['description'];
            }
            wp_update_post($post);
            // check if altText exist in data
            $table_name = $wpdb->prefix . 'blink_alt_text_media_detail'; // Add prefix if necessary
            if (isset($data['altText'])) {
                // Get decorative value from media detail table
                $decorative_query = $wpdb->prepare(
                    "SELECT decorative FROM $table_name WHERE post_id = %d",
                    $post_id
                );
                $decorative = $wpdb->get_var($decorative_query);
                if ($decorative === null) {
                    $decorative = false;
                }
                $data['decorative'] = (bool)$decorative;
                $array = array(
                    'path' => $media_url,
                    'post_id' => $post_id,
                    'altText' => $data['altText'],
                    'decorative' => $data['decorative']
                );
                $generator_route->bulk_modify_post_page_content($array);
                // saving alt text will be affected by decorative flag
                if ($data['decorative'] == true) {
                    delete_post_meta($post_id, '_wp_attachment_image_alt');
                } else {
                    update_post_meta($post_id, '_wp_attachment_image_alt', $data['altText']);
                }
            }

            // updating detail
            $columns = [];
            $values = [];
            $update_parts = [];
            $query_params = [$post_id]; // Start with post_id
            $field_mappings = [
                'altText' => ['column' => 'altTextBlink', 'ai_flag' => 'altTextAi', 'status' => 'altTextStatus'],
                'title' => ['ai_flag' => 'titleAi'],
                'caption' => ['ai_flag' => 'captionAi'],
                'slug' => ['ai_flag' => 'slugAi'],
                'description' => ['ai_flag' => 'descriptionAi'],
                'fileName' => ['ai_flag' => 'fileNameAi', 'status' => 'fileNameStatus'],
            ];

            foreach ($field_mappings as $field => $mapping) {
                if (isset($data[$field])) {
                    // $status = 0;
                    // if ($field == 'altText') {
                    //     $status = $generator_route->getAltTextStatus($data[$field], '', '');
                    // } else if ($field == 'fileName') {
                    //     $status = $generator_route->getAltTextStatus($data[$field], '', '');
                    // }
                    if (isset($mapping['column'])) {
                        $columns[] = $mapping['column'];
                        $values[] = '%s';
                        $update_parts[] = "{$mapping['column']} = VALUES({$mapping['column']})";
                        $query_params[] = $data[$field];
                    }
                    if (isset($mapping['ai_flag'])) {
                        $columns[] = $mapping['ai_flag'];
                        $values[] = '%d';
                        $update_parts[] = "{$mapping['ai_flag']} = VALUES({$mapping['ai_flag']})";
                        $query_params[] = 1;
                    }
                    if (isset($mapping['status'])) {
                        $columns[] = $mapping['status'];
                        $values[] = '%d';
                        $update_parts[] = "{$mapping['status']} = VALUES({$mapping['status']})";
                        $query_params[] = 2;
                    }
                }
            }

            // Construct the dynamic query
            $columns_str = implode(', ', array_merge(['post_id'], $columns));
            $values_str = implode(', ', array_merge(['%d'], $values));
            $update_str = implode(', ', $update_parts);

            $query = $wpdb->prepare(
                "INSERT INTO $table_name ($columns_str)
                VALUES ($values_str)
                ON DUPLICATE KEY UPDATE $update_str",
                ...$query_params
            );

            $queryMediaAiStatus = $wpdb->query($query);

            // Check if the query was successful
            if ($queryMediaAiStatus === false) {
                throw new \Exception("Database error: " . $wpdb->last_error);
            }
            // updating filename and metadatas
            if (isset($data['fileName'])) {
                $generator_route_api = new \BLINK_ALT_TEXT\GeneratorRoute();
                $relative_path = str_replace(wp_get_upload_dir()['baseurl'] . '/', '', $media_url); //convert http://localhost/wordpress/wordpress/wp-content/uploads/2024/12/zxczxczxczxc.jpg  to 2024/12/zxczxczxc.jpg
                $generator_route_api->updateFileName($data['fileName'], $relative_path, $post_id);
            }
            $wpdb->query('COMMIT');
            $data = array(
                'title' => 'Success',
                'message' => 'Media successfully updated',
            );
            $response = new \WP_REST_Response($data);
            $response->set_status(200);
            return $response;
        } catch (\Throwable $th) {
            $wpdb->query('ROLLBACK');
            $data = array(
                'error' => 'Update Failed',
                'message' => 'Update failed, try again'
            );
            $response = new \WP_REST_Response($data);
            $response->set_status(400);
            return $response;
        } finally {
            // Restore WordPress database error display to default behavior after the transaction
            $wpdb->show_errors(true);
        }
    }

    public function generateField($payloadChatCompletion, $chat_completion_route, $bypassLimit = true)
    {
        $maxRetries = 3;
        $retryCount = 0;
        while ($retryCount < $maxRetries) {
            error_log("Retry count: " . $retryCount);
            $generated_alt_text = $chat_completion_route->chat_completions_generator($payloadChatCompletion, $bypassLimit);
            // $generated_alt_text = $chat_completion_route->chat_completions_generator($payloadChatCompletion);
            if ($generated_alt_text->get_status() == 200) {
                error_log("Generated  " . $payloadChatCompletion['fieldName'] . ": " . $generated_alt_text->get_data()['choices'][0]['message']['content']);
                return array('value' => $generated_alt_text->get_data()['choices'][0]['message']['content'], 'status' => true);
            } else if ($generated_alt_text->get_status() == 429) {
                // return array('value' => 'Too Many Requests', 'status' => false);
                $retryCount++;
                if ($retryCount < $maxRetries) {
                    sleep(1);
                    continue;
                } else {
                    return array('value' => 'Too Many Requests', 'status' => false); // Exceeded retries
                }
            } else if ($generated_alt_text->get_status() == 500) {
                $retryCount++;
                if ($retryCount < $maxRetries) {
                    sleep(1);
                    continue;
                } else {
                    return array('value' => 'Internal Server Error', 'status' => false); // Exceeded retries
                }
            } else if ($generated_alt_text->get_status() == 400) {
                $retryCount++;
                if ($retryCount < $maxRetries) {
                    sleep(1);
                    continue;
                } else {
                    return array('value' => 'Bad Request', 'status' => false); // Exceeded retries
                }
            } else if ($generated_alt_text->get_status() == 401) {
                return array('value' => 'Unauthorized', 'status' => false);
            } else if ($generated_alt_text->get_status() == 403) {
                $retryCount++;
                if ($retryCount < $maxRetries) {
                    sleep(1);
                    continue;
                } else {
                    return array('value' => 'Forbidden', 'status' => false); // Exceeded retries
                }
            } else if ($generated_alt_text->get_status() == 404) {
                return array('value' => 'Not Found', 'status' => false);
            } else {
                $retryCount++;
                if ($retryCount < $maxRetries) {
                    sleep(1);
                    continue;
                } else {
                    return array('value' => 'Unknown Error: Error Code ' . $generated_alt_text->get_status(), 'status' => false); // Exceeded retries
                }
            }
        }
    }

    public function prepareQueryBulkGenerate($data, $payload)
    {
        // Build dynamic WHERE conditions
        $conditions = [];
        $select_fields = ['p.ID'];

        // Alt Text fields and condition
        if (!empty($data['altText'])) {
            $select_fields[] = 'pm.meta_value AS altText';
            $select_fields[] = 'md.altTextBlink';
            $conditions[] = "((md.altTextBlink IS NULL OR md.altTextBlink = '') 
                AND (pm.meta_value IS NULL OR pm.meta_value = ''))";
        }

        // Title field and condition
        if (!empty($data['title'])) {
            $select_fields[] = 'p.post_title';
            $conditions[] = "(p.post_title IS NULL OR p.post_title = '')";
        }

        // File Name field and condition
        if (!empty($data['fileName'])) {
            $select_fields[] = 'SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, \'/\', -1), \'.\', 1) AS fileName';
            $conditions[] = "(SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, '/', -1), '.', 1) IS NULL 
                OR SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, '/', -1), '.', 1) = '')";
        }

        // Caption field and condition
        if (!empty($data['caption'])) {
            $select_fields[] = 'p.post_excerpt';
            $conditions[] = "(p.post_excerpt IS NULL OR p.post_excerpt = '')";
        }

        // Description field and condition
        if (!empty($data['description'])) {
            $select_fields[] = 'p.post_content';
            $conditions[] = "(p.post_content IS NULL OR p.post_content = '')";
        }

        // Slug field and condition
        if (!empty($data['slug'])) {
            $select_fields[] = 'p.post_name';
            $conditions[] = "(p.post_name IS NULL OR p.post_name = '')";
        }

        
        // Join conditions with OR
        $where_clause = !empty($conditions) ? 'AND (' . implode(' OR ', $conditions) . ')' : '';
        if($payload['modeBulk'] == 'individual' && !empty($payload['selectedItems'])) {
            $where_clause .= "AND p.ID IN (" . implode(',', $payload['selectedItems']) . ")";
        }
        $select_clause = implode(', ', $select_fields);

        // error_log($where_clause);
        return [
            'select_clause' => $select_clause,
            'where_clause' => $where_clause
        ];
    }
}
