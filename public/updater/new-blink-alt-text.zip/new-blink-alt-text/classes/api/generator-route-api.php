<?php

namespace BLINK_ALT_TEXT;

class GeneratorRoute
{

  public function __construct()
  {
    add_action('rest_api_init', [$this, 'create_rest_routes']);

    // add_filter('rest_authentication_errors', function ($result) {
    //   if (!is_user_logged_in()) {
    //     return new \WP_Error(
    //       'rest_not_logged_in',
    //       __('not logged in.'),
    //       array('status' => 401)
    //     );
    //   } else {
    //     $current_user = wp_get_current_user();
    //     error_log('Authentication successful: User ID: ' . $current_user->ID);
    //     error_log('User capabilities: ' . json_encode($current_user->allcaps));
    //   }
    //   return $result;
    // });
  }

  public function create_rest_routes()
  {
    register_rest_route('blink-alt-text/v1', '/posts', [
      'methods' => 'GET',
      'callback' => [$this, 'get_posts'],
      'permission_callback' => [$this, 'get_posts_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/get-widget-data', [
      'methods' => 'GET',
      'callback' => [$this, 'get_widget_data'],
      'permission_callback' => [$this, 'get_widget_data_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/generates', [
      'methods' => 'POST',
      'callback' => [$this, 'save_generates'],
      'permission_callback' => [$this, 'save_generates_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/save-post', [
      'methods' => 'POST',
      'callback' => [$this, 'save_post'],
      'permission_callback' => [$this, 'save_post_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/posts-byid', [
      'methods' => 'GET',
      'callback' => [$this, 'get_posts_byid'],
      'permission_callback' => [$this, 'get_posts_byid_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/save-inject', [
      'methods' => 'POST',
      'callback' => [$this, 'save_inject'],
      'permission_callback' => [$this, 'save_inject_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/save-inject-checkbox', [
      'methods' => 'POST',
      'callback' => [$this, 'save_inject_checkbox'],
      'permission_callback' => [$this, 'save_inject_checkbox_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/get-image-pages', [
      'methods' => 'get',
      'callback' => [$this, 'get_image_pages'],
      'permission_callback' => [$this, 'get_image_pages_permission']
    ]);
    // register_rest_route('blink-alt-text/v1', '/bulk-generate', [
    //   'methods' => 'POST',
    //   'callback' => [$this, 'bulk_generate'],
    //   'permission_callback' => [$this, 'bulk_generate_permission']
    // ]);
  }

  public function background_test_permission()
  {
    return true;
  }

  public function bulk_generate()
  {
    global $wpdb;
    $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
    $mediaWithEmpties = "SELECT p.ID, 
    pm.meta_value AS altText, p.post_excerpt, p.post_content, 
    p.post_title, p.post_name, p.post_content,
    md.altTextBlink,
    SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, '/', -1), '.', 1) AS fileName
    FROM {$wpdb->posts} p
    LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
    LEFT JOIN {$media_detail} md ON p.ID = md.post_id
    WHERE p.post_type = 'attachment'
    AND p.post_status = 'inherit'
    AND (
       ((md.altTextBlink IS NULL OR md.altTextBlink = '')
    AND (pm.meta_value IS NULL OR pm.meta_value = ''))
    OR (p.post_excerpt IS NULL OR p.post_excerpt = '')
    OR (p.post_content IS NULL OR p.post_content = '')
    OR (p.post_title IS NULL OR p.post_title = '')
    OR (p.post_name IS NULL OR p.post_name = '')
    OR (p.post_content IS NULL OR p.post_content = '')
    OR (SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, '/', -1), '.', 1) IS NULL OR SUBSTRING_INDEX(SUBSTRING_INDEX(p.guid, '/', -1), '.', 1) = '')
    )
    ORDER BY p.ID DESC
    ";
    $mediaWithEmpties = $wpdb->get_results($mediaWithEmpties);
    $response = new \WP_REST_Response($mediaWithEmpties);
    $response->set_status(200);

    if (isset($mediaWithEmpties) && !empty($mediaWithEmpties)) {
      $batch_query = "SELECT MAX(batch) as max_batch FROM {$wpdb->prefix}blink_alt_text_queue";
      $max_batch = $wpdb->get_var($batch_query);
      $new_batch = $max_batch ? $max_batch + 1 : 1;
      foreach ($mediaWithEmpties as $data) {
        $queue_data = array(
          'batch' => $new_batch,
          'post_id' => $data->ID,
          'done' => 0,
          'generateAltText' => empty($data->altTextBlink) ? (empty($data->altText) ? 1 : 0) : 0,
          'generateTitle' => empty($data->post_title) ? 1 : 0,
          'generateCaption' => empty($data->post_excerpt) ? 1 : 0,
          'generateSlug' => empty($data->post_name) ? 1 : 0,
          'generateDescription' => empty($data->post_content) ? 1 : 0,
          'generateFileName' => empty($data->fileName) ? 1 : 0
        );

        $wpdb->insert($wpdb->prefix . 'blink_alt_text_queue', $queue_data);
      }
    }

    return $response;
  }

  public function bulk_generate_permission()
  {
    return true;
  }

  public function get_posts()
  {
    global $wpdb;
    // error_log('before');
    // do_action('my_plugin_file_renamed');
    // error_log('after');
    // $search = isset($_GET['search']) ? $_GET['search'] : '';
    $orderBy = isset($_GET['order_by']) ? $_GET['order_by'] : 'ID';
    $orderDirection = isset($_GET['order_direction']) ? $_GET['order_direction'] : 'DESC';
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $postPerPage = 10;
    $offset = ($page - 1) * $postPerPage;

    $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';

    $total_records_query_after_filter = "SELECT COUNT(*) 
    FROM {$wpdb->posts} p
    LEFT JOIN {$media_detail} md ON p.ID = md.post_id
    WHERE post_type = 'attachment' 
    AND post_status = 'inherit'";

    $useless_types_conditions = "
      post_status NOT IN ('inherit', 'trash', 'auto-draft')
      AND post_type NOT IN ('attachment', 'shop_order', 'shop_order_refund', 'nav_menu_item', 'revision', 'auto-draft', 'wphb_minify_group', 'customize_changeset', 'oembed_cache', 'nf_sub', 'jp_img_sitemap')
      AND post_type NOT LIKE 'dlssus_%'
      AND post_type NOT LIKE 'ml-slide%'
      AND post_type NOT LIKE '%acf-%'
      AND post_type NOT LIKE '%edd_%'
      ";

    // prepare query
    $baseQuery = "SELECT p.ID, p.post_mime_type, p.post_title, p.post_name, p.post_excerpt, p.post_content, p.post_date,
           md.*,
           (SELECT count(*) FROM {$wpdb->posts} where {$useless_types_conditions} and post_content like CONCAT('%wp-image-', p.ID, '%')) as countImage
          FROM {$wpdb->posts} p
          LEFT JOIN {$media_detail} md ON p.ID = md.post_id
          WHERE p.post_type = 'attachment'
          AND p.post_status = 'inherit'";
    // filters

    // if(isset($_GET['altText']) == true){
    //   $baseQuery .= " AND (md.altTextBlink IS NULL OR md.altTextBlink = '')";
    //   $total_records_query_after_filter .= " AND (md.altTextBlink IS NULL OR md.altTextBlink = '')";
    // }
    // if(isset($_GET['title']) == true){
    //   $baseQuery .= " AND (p.post_title IS NULL OR p.post_title = '')";
    //   $total_records_query_after_filter .= " AND (p.post_title IS NULL OR p.post_title = '')";
    // }
    // // if($_GET['fileName'] == true){
    // //   $baseQuery .= " AND (md.altTextBlink IS NULL OR md.altTextBlink = '')";
    // // }
    // if(isset($_GET['caption']) == true){
    //   $baseQuery .= " AND (p.post_excerpt IS NULL OR p.post_excerpt = '')";
    //   $total_records_query_after_filter .= " AND (p.post_excerpt IS NULL OR p.post_excerpt = '')";
    // }
    // if(isset($_GET['description']) == true){
    //   $baseQuery .= " AND (p.post_content IS NULL OR p.post_content = '')";
    //   $total_records_query_after_filter .= " AND (p.post_content IS NULL OR p.post_content = '')";
    // }
    // if(isset($_GET['slug']) == true){
    //   $baseQuery .= " AND (p.post_name IS NULL OR p.post_name = '')";
    //   $total_records_query_after_filter .= " AND (p.post_name IS NULL OR p.post_name = '')";
    // }

    if (isset($_GET['altText']) == true) {
      $baseQuery .= " AND (md.altTextAi IS NULL OR md.altTextAi = 0)";
      $total_records_query_after_filter .= " AND (md.altTextAi IS NULL OR md.altTextAi = 0)";
    }
    if (isset($_GET['title']) == true) {
      $baseQuery .= " AND (md.titleAi IS NULL OR md.titleAi = 0)";
      $total_records_query_after_filter .= " AND (md.titleAi IS NULL OR md.titleAi = 0)";
    }
    if (isset($_GET['fileName']) == true) {
      $baseQuery .= " AND (md.fileNameAi IS NULL OR md.fileNameAi = 0)";
      $total_records_query_after_filter .= " AND (md.fileNameAi IS NULL OR md.fileNameAi = 0)";
    }
    if (isset($_GET['caption']) == true) {
      $baseQuery .= " AND (md.captionAi IS NULL OR md.captionAi = 0)";
      $total_records_query_after_filter .= " AND (md.captionAi IS NULL OR md.captionAi = 0)";
    }
    if (isset($_GET['description']) == true) {
      $baseQuery .= " AND (md.descriptionAi IS NULL OR md.descriptionAi = 0)";
      $total_records_query_after_filter .= " AND (md.descriptionAi IS NULL OR md.descriptionAi = 0)";
    }
    if (isset($_GET['slug']) == true) {
      $baseQuery .= " AND (md.slugAi IS NULL OR md.slugAi = 0)";
      $total_records_query_after_filter .= " AND (md.slugAi IS NULL OR md.slugAi = 0)";
    }
    // add the rest query
    $baseQuery .= " ORDER BY p.{$orderBy} {$orderDirection}
          LIMIT {$postPerPage}
          OFFSET {$offset}";

    $attachments = $wpdb->get_results(
      $wpdb->prepare(
        $baseQuery
      )
    );
    $total_records_after_filter = $wpdb->get_var($total_records_query_after_filter);
    $total_pages = ceil($total_records_after_filter / $postPerPage);


    $images_all = array();

    if (isset($attachments) && !empty($attachments)) {
      foreach ($attachments as $attachment) {

        $post_id = $attachment->ID;
        $post_mime_type = sanitize_mime_type($attachment->post_mime_type);
        $post_title = $attachment->post_title;
        $post_name = $attachment->post_name;
        $post_excerpt = $attachment->post_excerpt;
        $description = $attachment->post_content;
        $countImage = $attachment->countImage;
        // media detial
        $outlineAi = (bool) $attachment->outlineAi;
        $slugAi = (bool) $attachment->slugAi;
        $captionAi = (bool) $attachment->captionAi;
        $altTextAi = (bool) $attachment->altTextAi;
        $fileNameAi = (bool) $attachment->fileNameAi;
        $decorative = (bool) $attachment->decorative;
        $titleAi = (bool) $attachment->titleAi;
        $descriptionAi = (bool) $attachment->descriptionAi;
        $url = wp_get_original_image_url($post_id);
        $file_name = $this->fileNameExtract($url);
        $post_date = date("F j, Y, g:i a", strtotime($attachment->post_date));
        // $altTextBlink = $attachment->altTextBlink;
        // $altTextWP = get_post_meta($post_id, '_wp_attachment_image_alt', true);
        // if (!$altTextBlink) {
        //   // condition 1: alttext blink is null then just use alttext from wp
        //   $altText = $altTextWP;
        // } else if ($altTextBlink != $altTextWP && ($altTextWP != null || $altTextWP != '')) {
        //   // condition 2 : alttext blink is not same with alttextwp (but alttext wp does exist, might be edited from native page)
        //   $altText = $altTextWP;
        // } else if ($altTextWP != null || $altTextWP != '') {
        //   // if alttext wp is null, use alttextblink (it might be caused by blink's decorative function)
        //   $altText = $altTextBlink;
        // } else {
        //   $altText = $altTextBlink;
        // }
        $altText = $this->conditional_alt_text($attachment->altTextBlink, $post_id);
        $metaData = get_post_meta($post_id, '_wp_attachment_metadata', true);
        if (str_contains($post_mime_type, 'image')) {
          $images_all[] = array(
            'post_id' => $post_id,
            'post_image' => $url,
            'title' => $post_title,
            'slug' => $post_name,
            'url' => $url,
            'countImage' => $countImage,
            'fileName' => $file_name,
            'post_date' => $post_date,
            'caption' => $post_excerpt,
            'altText' => $altText,
            'description' => $description,
            'metaData' => $metaData,
            'outlineAi' => $outlineAi,
            'slugAi' => $slugAi,
            'captionAi' => $captionAi,
            'altTextAi' => $altTextAi,
            'titleAi' => $titleAi,
            'fileNameAi' => $fileNameAi,
            'decorative' => $decorative,
            'descriptionAi' => $descriptionAi,
          );
        }
      }
    }
    $data = array(
      'data' => $images_all,
      'pageNumber' => $total_pages,
    );
    $response = new \WP_REST_Response($data);
    $response->set_status(200);

    return $response;
  }

  public function get_posts_permission()
  {
    // return current_user_can( 'edit_others_posts' );
    return true;
  }

  public function get_widget_data()
  {
    global $wpdb;
    // $total_records_query_total = "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit'";
    // $total_records_total = $wpdb->get_var($total_records_query_total);
    $table_name_post = $wpdb->prefix . 'posts';
    $table_name_media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
    $analytic_query = "SELECT decorative,count(*) as totalImages,sum(md.altTextStatus ) as altTextScore, sum(md.fileNameStatus) fileNameScore
          FROM $table_name_post p
          LEFT JOIN $table_name_media_detail md ON p.ID = md.post_id
          WHERE p.post_type = 'attachment'
          AND p.post_status = 'inherit'
          group by decorative";
    $analytics = $wpdb->get_results($analytic_query);
    $totalImageNonDecorative = 0;
    $totalImage = 0;
    $altTextScore = 0;
    $fileNameScore = 0;
    foreach ($analytics as $analytic) {
      if ($analytic->decorative == 0 && $analytic->decorative !== null) {
        $totalImageNonDecorative += $analytic->totalImages;
        $altTextScore += $analytic->altTextScore;
      }
      $totalImage += $analytic->totalImages;
      $fileNameScore += $analytic->fileNameScore;
    }
    // percentage
    if ($totalImageNonDecorative == 0) {
      $altTextPercentage =  0;
    } else {
      $altTextPercentage =  round(($altTextScore / $totalImageNonDecorative) / 2 * 100, 2);
    }
    if ($totalImage == 0) {
      $fileNamePercentage =  0;
    } else {
      $fileNamePercentage = round(($fileNameScore / $totalImage) / 2 * 100, 2);
    }

    $data = array(
      'totalImages' => $totalImage,
      'totalImageNonDecorative' => $totalImageNonDecorative,
      'altTextScore' => $altTextScore,
      'altTextPercentage' => $altTextPercentage,
      // 'altTextPercentage' => 40,
      'fileNameScore' => $fileNameScore,
      'fileNamePercentage' => $fileNamePercentage,
      // 'fileNamePercentage' => 20,
    );
    $response = new \WP_REST_Response($data);
    $response->set_status(200);

    return $response;
  }

  public function get_widget_data_permission()
  {
    return true;
  }

  public function get_posts_byid()
  {
    global $wpdb;
    $postId = isset($_GET['postId']) ? $_GET['postId'] : null;

    $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';

    $baseQuery = "SELECT p.ID, p.post_mime_type, p.post_title, p.post_name, p.post_excerpt, p.post_content, p.post_date,
           md.*
          FROM {$wpdb->posts} p
          LEFT JOIN {$media_detail} md ON p.ID = md.post_id
          WHERE p.post_type = 'attachment'
          AND p.post_status = 'inherit'
          AND ID = {$postId}";

    $attachments = $wpdb->get_results(
      $wpdb->prepare(
        $baseQuery
      )
    );

    if (isset($attachments) && !empty($attachments)) {
      foreach ($attachments as $attachment) {

        $post_id = $attachment->ID;
        $post_mime_type = sanitize_mime_type($attachment->post_mime_type);
        $post_title = $attachment->post_title;
        $post_name = $attachment->post_name;
        $post_excerpt = $attachment->post_excerpt;
        $description = $attachment->post_content;
        // media detial
        $outlineAi = (bool) $attachment->outlineAi;
        $slugAi = (bool) $attachment->slugAi;
        $captionAi = (bool) $attachment->captionAi;
        $altTextAi = (bool) $attachment->altTextAi;
        $fileNameAi = (bool) $attachment->fileNameAi;
        $decorative = (bool) $attachment->decorative;
        $titleAi = (bool) $attachment->titleAi;
        $descriptionAi = (bool) $attachment->descriptionAi;
        $url = wp_get_original_image_url($post_id);
        $file_name = $this->fileNameExtract($url);
        $post_date = date("F j, Y, g:i a", strtotime($attachment->post_date));
        $altText = $this->conditional_alt_text($attachment->altTextBlink, $post_id);
        $metaData = get_post_meta($post_id, '_wp_attachment_metadata', true);
        if (str_contains($post_mime_type, 'image')) {
          $images_all[] = array(
            'post_id' => $post_id,
            'post_image' => $url,
            'title' => $post_title,
            'slug' => $post_name,
            'url' => $url,
            'fileName' => $file_name,
            'post_date' => $post_date,
            'caption' => $post_excerpt,
            'altText' => $altText,
            'description' => $description,
            'metaData' => $metaData,
            'outlineAi' => $outlineAi,
            'slugAi' => $slugAi,
            'captionAi' => $captionAi,
            'altTextAi' => $altTextAi,
            'titleAi' => $titleAi,
            'fileNameAi' => $fileNameAi,
            'decorative' => $decorative,
            'descriptionAi' => $descriptionAi,
          );
        }
      }
    }
    $data = array(
      'data' => $images_all,
    );
    $response = new \WP_REST_Response($data);
    $response->set_status(200);

    return $response;
  }

  public function get_posts_byid_permission()
  {
    return true;
  }

  public function save_generates($req)
  {
    $data = $req->get_params();
    // return $data['alt_text'];
    $this->alt_generate_content($data['post_id'], $data['alt_text'], $data['caption'], $data['description']);
    // if (sizeof($data['post_id']) > 0) {
    //   foreach ($data['post_id'] as $post_id) {
    //   $this->alt_generate_content($data['post_id'], $data['alt_text'], $data['caption'], $data['description']);
    //   }
    // }
  }

  public function save_generates_permission()
  {
    return true;
  }

  public function save_post($req)
  {
    $data = $req->get_params();
    global $wpdb;

    $wpdb->show_errors(false);
    $wpdb->query('START TRANSACTION');
    try {
      $table_name = $wpdb->prefix . 'blink_alt_text_media_detail'; // Add prefix if necessary
      // check if there's changes on decorative or altTextBlink, if there's any, update the contents
      $mediaDetailQuery = "SELECT decorative, altTextBlink FROM $table_name WHERE post_id = %d";
      $mediaDetailResult = $wpdb->get_row($wpdb->prepare($mediaDetailQuery, $data['post_id']));
      if (empty($mediaDetailResult)) {
        error_log('updateAltTextContent true: Media detail result is empty');
        $this->bulk_modify_post_page_content($data);
      } else {
        if ($data['altText'] != $mediaDetailResult->altTextBlink || $data['decorative'] != $mediaDetailResult->decorative) {
          error_log('updateAltTextContent true: Alt Text Changed,');
          $this->bulk_modify_post_page_content($data);
        } else {
          error_log('updateAltTextContent false:Alt Text still same');
        }
      }

      $post = array(
        'ID' => $data['post_id'],
        'post_excerpt' => $data['caption'],
        'post_title' => $data['title'],
        'post_name' => $data['slug'],
        'post_content' => $data['description'],
      );
      wp_update_post($post);
      // saving alt text will be affected by decorative flag
      if ($data['decorative'] == true) {
        delete_post_meta($data['post_id'], '_wp_attachment_image_alt');
      } else {
        update_post_meta($data['post_id'], '_wp_attachment_image_alt', $data['altText']);
      }
      // updating detail

      $tmp = array(
        'post_id' => $data['post_id'],
        // outlineAi for now is deleted, so it will keep signed as 0 (false)
        'outlineAi' => 0,
        'slugAi' => $data['slugAi'],
        'captionAi' => $data['captionAi'],
        'altTextAi' => $data['altTextAi'],
        'titleAi' => $data['titleAi'],
        'fileNameAi' => $data['fileNameAi'],
        'descriptionAi' => $data['descriptionAi'],
        'decorative' => $data['decorative'],
        'altTextBlink' => $data['altText'],
        'altTextStatus' => $data['altTextStatus'],
        'fileNameStatus' => $data['fileNameStatus'],
      );
      $queryMediaAiStatus = $wpdb->query(
        $wpdb->prepare(
          "
            INSERT INTO $table_name (post_id, outlineAi, slugAi, captionAi, altTextAi, titleAi, fileNameAi, descriptionAi, decorative, altTextBlink, altTextStatus, fileNameStatus)
            VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %s, %d, %d)
            ON DUPLICATE KEY UPDATE
                outlineAi = VALUES(outlineAi),
                slugAi = VALUES(slugAi),
                captionAi = VALUES(captionAi),
                altTextAi = VALUES(altTextAi),
                titleAi = VALUES(titleAi),
                fileNameAi = VALUES(fileNameAi),
                descriptionAi = VALUES(descriptionAi),
                decorative = VALUES(decorative),
                altTextBlink = VALUES(altTextBlink),
                altTextStatus = VALUES(altTextStatus),
                fileNameStatus = VALUES(fileNameStatus)
            ",
          $tmp['post_id'],
          $tmp['outlineAi'],
          $tmp['slugAi'],
          $tmp['captionAi'],
          $tmp['altTextAi'],
          $tmp['titleAi'],
          $tmp['fileNameAi'],
          $tmp['descriptionAi'],
          $tmp['decorative'],
          $tmp['altTextBlink'],
          $tmp['altTextStatus'],
          $tmp['fileNameStatus'],
        )
      );

      // Check if the query was successful
      if ($queryMediaAiStatus === false) {
        throw new \Exception("Database error: " . $wpdb->last_error);
      }
      // updating filename and metadatas

      $this->updateFileName($data['fileName'], $data['path'], $data['post_id']);
      $wpdb->query('COMMIT');
      $data = array(
        'title' => 'Success',
        'message' => 'Media successfully updated',
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(200);
      return $response;
    } catch (\Throwable $th) {
      error_log($th);
      $wpdb->query('ROLLBACK');
      $data = array(
        'error' => 'Update Failed',
        'message' => 'Update failed, try again'
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(400);
      return $response;
    } finally {
      // Restore WordPress database error display to default behavior after the transaction
      $wpdb->show_errors(true);
    }
  }

  public function save_post_permission()
  {
    return true;
  }

  public function save_bulk($req)
  {
    $data = $req->get_params();
    global $wpdb;

    $wpdb->show_errors(false);
    $wpdb->query('START TRANSACTION');
    try {
      $post = array(
        'ID' => $data['post_id'],
        'post_excerpt' => $data['caption'],
        'post_title' => $data['title'],
        'post_name' => $data['slug'],
        'post_content' => $data['description'],
      );
      wp_update_post($post);
      // saving alt text will be affected by decorative flag
      if ($data['decorative'] == true) {
        delete_post_meta($data['post_id'], '_wp_attachment_image_alt');
      } else {
        update_post_meta($data['post_id'], '_wp_attachment_image_alt', $data['altText']);
      }
      // updating detail
      $table_name = $wpdb->prefix . 'blink_alt_text_media_detail'; // Add prefix if necessary
      $tmp = array(
        'post_id' => $data['post_id'],
        'outlineAi' => $data['outlineAi'],
        'slugAi' => $data['slugAi'],
        'captionAi' => $data['captionAi'],
        'altTextAi' => $data['altTextAi'],
        'titleAi' => $data['titleAi'],
        'fileNameAi' => $data['fileNameAi'],
        'descriptionAi' => $data['descriptionAi'],
        'decorative' => $data['decorative'],
        'altTextBlink' => $data['altText'],
      );
      $queryMediaAiStatus = $wpdb->query(
        $wpdb->prepare(
          "
            INSERT INTO $table_name (post_id, outlineAi, slugAi, captionAi, altTextAi, titleAi, fileNameAi, descriptionAi, decorative, altTextBlink)
            VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %s)
            ON DUPLICATE KEY UPDATE
                outlineAi = VALUES(outlineAi),
                slugAi = VALUES(slugAi),
                captionAi = VALUES(captionAi),
                altTextAi = VALUES(altTextAi),
                titleAi = VALUES(titleAi),
                fileNameAi = VALUES(fileNameAi),
                descriptionAi = VALUES(descriptionAi),
                decorative = VALUES(decorative),
                altTextBlink = VALUES(altTextBlink)
            ",
          $tmp['post_id'],
          $tmp['outlineAi'],
          $tmp['slugAi'],
          $tmp['captionAi'],
          $tmp['altTextAi'],
          $tmp['titleAi'],
          $tmp['fileNameAi'],
          $tmp['descriptionAi'],
          $tmp['decorative'],
          $tmp['altTextBlink']
        )
      );

      // Check if the query was successful
      if ($queryMediaAiStatus === false) {
        throw new \Exception("Database error: " . $wpdb->last_error);
      }
      // updating filename and metadatas
      $this->updateFileName($data['fileName'], $data['path'], $data['post_id']);
      $wpdb->query('COMMIT');
      $data = array(
        'title' => 'Success',
        'message' => 'Media successfully updated',
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(200);
      return $response;
    } catch (\Throwable $th) {
      $wpdb->query('ROLLBACK');
      $data = array(
        'error' => 'Update Failed',
        'message' => 'Update failed, try again'
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(400);
      return $response;
    } finally {
      // Restore WordPress database error display to default behavior after the transaction
      $wpdb->show_errors(true);
    }
  }

  public function save_bulk_permission()
  {
    return true;
  }

  public function save_inject($req)
  {
    $data = $req->get_params();
    global $wpdb;
    $wpdb->show_errors(false);
    $wpdb->query('START TRANSACTION');
    try {
      if ($data['key'] == 'slug' || $data['key'] == 'title' || $data['key'] == 'caption' || $data['key'] == 'description') {
        // these variables are all on table media
        if ($data['key'] == 'slug') {
          $key = 'post_name';
        } else if ($data['key'] == 'title') {
          $key = 'post_title';
        } else if ($data['key'] == 'caption') {
          $key = 'post_excerpt';
        } else if ($data['key'] == 'description') {
          $key = 'post_content';
        }
        $post = array(
          'ID' => $data['post_id'],
          $key => $data['value'],
        );
        wp_update_post($post);
      } else if ($data['key'] == 'altText') {
        // updating contents
        $array = array(
          'path' => $data['path'],
          'post_id' => $data['post_id'],
          'altText' => $data['value'],
          'decorative' => $data['decorative']
        );
        $this->bulk_modify_post_page_content($array);

        if ($data['decorative'] == true) {
          delete_post_meta($data['post_id'], '_wp_attachment_image_alt');
        } else {
          update_post_meta($data['post_id'], '_wp_attachment_image_alt', $data['value']);
        }

        $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
        // $query = "UPDATE $table_name SET altTextBlink = %s where post_id = %s";
        $query = "INSERT INTO $table_name (post_id, altTextBlink, altTextStatus)
            VALUES (%s, %s, %d)
            ON DUPLICATE KEY UPDATE
                altTextBlink = VALUES(altTextBlink),
                altTextStatus = VALUES(altTextStatus)";
        $updateAltText = $wpdb->query(
          $wpdb->prepare($query, $data['post_id'], $data['value'], $data['score'])
        );
        if ($updateAltText === false) {
          throw new \Exception("Database error: " . $wpdb->last_error);
        }
      } else if ($data['key'] == 'fileName') {
        $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
        // $query = "UPDATE $table_name SET altTextBlink = %s where post_id = %s";
        $query = "INSERT INTO $table_name (post_id, fileNameStatus)
            VALUES (%s, %d)
            ON DUPLICATE KEY UPDATE
                fileNameStatus = VALUES(fileNameStatus)";
        $updateAltText = $wpdb->query(
          $wpdb->prepare($query, $data['post_id'], $data['score'])
        );
        if ($updateAltText === false) {
          throw new \Exception("Database error: " . $wpdb->last_error);
        }
        $this->updateFileName($data['value'], $data['path'], $data['post_id']);
      } else if ($data['key'] == 'decorative') {
        $array = array(
          'path' => $data['path'],
          'post_id' => $data['post_id'],
          'altText' => $data['altTextBlink'],
          'decorative' => $data['value']
        );
        $this->bulk_modify_post_page_content($array);
        if ($data['value'] == true) {
          delete_post_meta($data['post_id'], '_wp_attachment_image_alt');
        } else {
          update_post_meta($data['post_id'], '_wp_attachment_image_alt', $data['altTextBlink']);
        }
        $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
        // $query = "UPDATE $table_name SET decorative = %d where post_id = %s";
        $query = "INSERT INTO $table_name (post_id, decorative)
            VALUES (%s, %d)
            ON DUPLICATE KEY UPDATE
                decorative = VALUES(decorative)";
        $updateData = $wpdb->query(
          $wpdb->prepare($query, $data['post_id'], $data['value'])
        );
        if ($updateData === false) {
          throw new \Exception("Database error: " . $wpdb->last_error);
        }
      }

      if ($data['generatedByAi'] == true) {
        if ($data['key'] == 'slug') {
          $key = 'slugAi';
        } else if ($data['key'] == 'title') {
          $key = 'titleAi';
        } else if ($data['key'] == 'caption') {
          $key = 'captionAi';
        } else if ($data['key'] == 'description') {
          $key = 'descriptionAi';
        } else if ($data['key'] == 'altText') {
          $key = 'altTextAi';
        } else if ($data['key'] == 'fileName') {
          $key = 'fileNameAi';
        }
        $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
        $query = "UPDATE $table_name SET $key = %s where post_id = %s";
        $updateAi = $wpdb->query(
          $wpdb->prepare($query, 1, $data['post_id'])
        );
        if ($updateAi === false) {
          throw new \Exception("Database error: " . $wpdb->last_error);
        }
      }

      $wpdb->query('COMMIT');
      $data = array(
        'title' => 'Success',
        'message' => 'Media successfully updated',
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(200);
      return $response;
    } catch (\Throwable $th) {
      $wpdb->query('ROLLBACK');
      $data = array(
        'error' => 'Update Failed',
        'message' => 'Update failed, try again'
      );
      $response = new \WP_REST_Response($data);
      $response->set_status(400);
      return $response;
    } finally {
      // Restore WordPress database error display to default behavior after the transaction
      $wpdb->show_errors(true);
    }
  }

  public function save_inject_permission()
  {
    return true;
  }

  public function save_inject_checkbox($req)
  {
    global $wpdb;
    $data = $req->get_params();
    if ($data['key'] == 'slug') {
      $key = 'slugAi';
    } else if ($data['key'] == 'title') {
      $key = 'titleAi';
    } else if ($data['key'] == 'caption') {
      $key = 'captionAi';
    } else if ($data['key'] == 'description') {
      $key = 'descriptionAi';
    } else if ($data['key'] == 'altText') {
      $key = 'altTextAi';
    } else if ($data['key'] == 'fileName') {
      $key = 'fileNameAi';
    }
    $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
    $query = "UPDATE $table_name SET $key = %d where post_id = %s";
    $updateAi = $wpdb->query(
      $wpdb->prepare($query, $data['value'], $data['post_id'])
    );
    if ($updateAi === false) {
      throw new \Exception("Database error: " . $wpdb->last_error);
    }
    $data = array(
      'title' => 'Success',
      'message' => 'Media successfully updated',
    );
    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function save_inject_checkbox_permission()
  {
    return true;
  }

  public function alt_generate_content($post_id, $alt_text, $caption, $description)
  {
    $output_generator = explode(';', get_option('blink_alt_text_generator'));
    $image_url = wp_get_attachment_image_src($post_id);

    if ($alt_text) {
      $post = array(
        'ID' => $post_id,
      );
      if (in_array('image_title', $output_generator)) $post['post_title'] = $caption;
      if (in_array('image_title', $output_generator)) $post['post_name'] = $caption;
      if (in_array('image_caption', $output_generator)) $post['post_excerpt'] = $alt_text;
      if (in_array('image_description', $output_generator)) $post['post_content'] = $description;
      wp_update_post($post);
      update_post_meta($post_id, '_wp_attachment_image_alt', $alt_text);
      update_post_meta($post_id, '_wp_attachment_alt_generated', 'success');
      return wp_send_json_success('success');
    } else {
      update_post_meta($post_id, '_wp_attachment_alt_error_reason', 'API Error: Invalid metadata format' . $response);
      update_post_meta($post_id, '_wp_attachment_alt_generated', 'error');
      return wp_send_json_error('error');
    }
  }

  public function fileNameExtract($url)
  {

    $file_name_with_ext = basename($url);

    $file_name = pathinfo($file_name_with_ext, PATHINFO_FILENAME);

    return $file_name; // Outputs: edit
  }

  public function conditionalSanitizeFileName($fileName)
  {
    $sanitize = get_option('blink_alt_text_sanitize_file_name', false) === 'true';
    if ($sanitize) {
      $fileName = $this->clean_filename($fileName);
    } else {
      // sanitize with native wordpress
      $fileName = sanitize_file_name($fileName);
    }
    return $fileName;
  }

  public function updateFileName($fileName, $path, $id)
  {
    $file_path = get_attached_file($id); // full path ex: C:\\xampp\\htdocs\\wordpress\\wordpress\/wp-content\/uploads\/2024\/11
    $file_info = pathinfo($file_path);

    // sanitize filename
    $fileName = $this->conditionalSanitizeFileName($fileName);

    if ($file_info['filename'] != $fileName) {
      error_log('updateFileName true: File name changed');
      $extension = pathinfo($path, PATHINFO_EXTENSION);
      // $attachment_post = get_post($id);
      // if (!$attachment_post) {
      //   return new WP_Error('attachment_not_found', 'Attachment not found.');
      // }

      // get whole directory (for renaming purposes)
      // ex: C:\xampp\htdocs\wordpress\wordpress/wp-content/uploads/2024/11
      $base_dir = $file_info['dirname'];
      $base_name = $fileName;
      $new_file_path = $base_dir . '/' . $base_name . '.' . $extension;
      $name_with_counter = $base_name;
      $counter = 2;
      // error_log('file_path: ' . $file_path);
      // error_log('file_info: ' . json_encode($file_info));
      // error_log('base_dir: ' . $base_dir);
      // error_log('base_name: ' . $base_name);

      // Check if the file already exists and add a counter if it does
      while (file_exists($new_file_path)) {
        // $new_file_path = $base_dir . '/' . $base_name . '-[' . $counter . '].' . $extension;
        $new_file_path = $base_dir . '/' . $base_name . '-' . $counter . '.' . $extension;
        // $name_with_counter = $base_name . '-[' . $counter . ']';
        $name_with_counter = $base_name . '-' . $counter . '';
        $counter++;
      }

      // error_log('new_file_path: ' . $new_file_path);
      if (!rename($file_path, $new_file_path)) {
        return new WP_Error('file_rename_failed', 'Failed to rename file.');
      }
      // get path from upload folder (for updating db and meta puroses)
      $path_prefix = dirname($path); // ex: 2024/11
      $new_path = $path_prefix . '/' . $name_with_counter . '.' . $extension;
      update_post_meta($id, '_wp_attached_file', $new_path);
      $meta_data = wp_get_attachment_metadata($id);
      if ($meta_data) {
        $meta_data['file'] = $new_path;
        $meta_data['url'] = $name_with_counter . '.' . $extension;
        wp_update_attachment_metadata($id, $meta_data);
        // clean_post_cache($id);
        $old_path = $path_prefix . '/' . $file_info['basename'];
        $this->bulk_rename_content($old_path, $new_path); // update contents on post/pages
      }
      return array(
        'file' => $new_path,
        'url' => $name_with_counter . '.' . $extension
      );
    } else {
      error_log('updateFileName false: File name still same');
    }
  }

  public function clean_filename($fileName)
  {

    // Replace whitespaces with dashes.
    $cleaned_filename = str_replace(' ', '-', $fileName);

    // Specific replacements not handled at all or not handled well by remove_accents().
    $specific_replacements = array(
      'А'   => 'a',
      'Ά'   => 'a',
      'Á'   => 'a',
      'Α'   => 'a',
      'Ä'   => 'a',
      'Å'   => 'a',
      'Ã'   => 'a',
      'Â'   => 'a',
      'À'   => 'a',
      'α'   => 'a',
      'Ą'   => 'a',
      'а'   => 'a',
      'ά'   => 'a',
      'Æ'   => 'ae',
      'å'   => 'a',
      'ä'   => 'a',
      'б'   => 'b',
      'Б'   => 'b',
      'Ć'   => 'c',
      'Ç'   => 'c',
      'ц'   => 'c',
      'Ц'   => 'c',
      'Č'   => 'c',
      'Ч'   => 'ch',
      'χ'   => 'ch',
      'ч'   => 'ch',
      'Χ'   => 'ch',
      'д'   => 'd',
      'Ď'   => 'd',
      'Д'   => 'd',
      'δ'   => 'd',
      'Δ'   => 'd',
      'Ð'   => 'd',
      'ε'   => 'e',
      'έ'   => 'e',
      'Έ'   => 'e',
      'Э'   => 'e',
      'Ę'   => 'e',
      'Ε'   => 'e',
      'э'   => 'e',
      'Ê'   => 'e',
      'Ě'   => 'e',
      'É'   => 'e',
      'Е'   => 'e',
      'е'   => 'e',
      'È'   => 'e',
      'Ë'   => 'e',
      'Φ'   => 'f',
      'Ф'   => 'f',
      'φ'   => 'f',
      'ф'   => 'f',
      'Γ'   => 'g',
      'γ'   => 'g',
      'ґ'   => 'g',
      'Г'   => 'g',
      'Ґ'   => 'g',
      'г'   => 'g',
      'Х'   => 'h',
      'х'   => 'h',
      'Ή'   => 'i',
      'Ί'   => 'i',
      'І'   => 'i',
      'і'   => 'i',
      'ΐ'   => 'i',
      'Η'   => 'i',
      'Ι'   => 'i',
      'η'   => 'i',
      'ϊ'   => 'i',
      'ι'   => 'i',
      'Ï'   => 'i',
      'Ì'   => 'i',
      'ή'   => 'i',
      'Í'   => 'i',
      'Î'   => 'i',
      'ί'   => 'i',
      'Ϊ'   => 'i',
      'и'   => 'i',
      'И'   => 'i',
      'й'   => 'j',
      'Й'   => 'j',
      'Я'   => 'ja',
      'я'   => 'ja',
      'ю'   => 'ju',
      'Ю'   => 'ju',
      'Κ'   => 'k',
      'κ'   => 'k',
      'к'   => 'k',
      'К'   => 'k',
      'л'   => 'l',
      'Λ'   => 'l',
      'λ'   => 'l',
      'Ł'   => 'l',
      'Л'   => 'l',
      'Μ'   => 'm',
      'м'   => 'm',
      'М'   => 'm',
      'μ'   => 'm',
      'Ñ'   => 'n',
      'ν'   => 'n',
      'Ν'   => 'n',
      'н'   => 'n',
      'Ň'   => 'n',
      'Ń'   => 'n',
      'Н'   => 'n',
      'ώ'   => 'o',
      'Ò'   => 'o',
      'ό'   => 'o',
      'Ő'   => 'o',
      'Ώ'   => 'o',
      'Õ'   => 'o',
      'Ο'   => 'o',
      'Ø'   => 'o',
      'ο'   => 'o',
      'Ό'   => 'o',
      'Ω'   => 'o',
      'Ó'   => 'o',
      'Ö'   => 'o',
      'ö'   => 'o',
      'О'   => 'o',
      'о'   => 'o',
      'ω'   => 'o',
      'Ô'   => 'o',
      'п'   => 'p',
      'þ'   => 'p',
      'π'   => 'p',
      'Π'   => 'p',
      'П'   => 'p',
      'Þ'   => 'p',
      'Ψ'   => 'ps',
      'ψ'   => 'ps',
      'Р'   => 'r',
      'Ř'   => 'r',
      'Ρ'   => 'r',
      'р'   => 'r',
      'ρ'   => 'r',
      'С'   => 's',
      'σ'   => 's',
      'Ś'   => 's',
      'ς'   => 's',
      'Σ'   => 's',
      'Š'   => 's',
      'с'   => 's',
      'Ш'   => 'sh',
      'ш'   => 'sh',
      'щ'   => 'shch',
      'Щ'   => 'shch',
      'ß'   => 'ss',
      'Τ'   => 't',
      'τ'   => 't',
      'Ť'   => 't',
      'т'   => 't',
      'Т'   => 't',
      'θ'   => 'th',
      'Θ'   => 'th',
      'Ў'   => 'u',
      'ў'   => 'u',
      'Ű'   => 'u',
      'Ú'   => 'u',
      'У'   => 'u',
      'Ù'   => 'u',
      'Û'   => 'u',
      'Ů'   => 'u',
      'у'   => 'u',
      'ü'   => 'u',
      'Ü'   => 'u',
      'в'   => 'v',
      'В'   => 'v',
      'Β'   => 'v',
      'β'   => 'v',
      'Ξ'   => 'x',
      '×'   => 'x',
      'ξ'   => 'x',
      'Ϋ'   => 'y',
      'Ÿ'   => 'y',
      'Ý'   => 'y',
      'Υ'   => 'y',
      'υ'   => 'y',
      'Ύ'   => 'y',
      'ύ'   => 'y',
      'ΰ'   => 'y',
      'ϋ'   => 'y',
      'ы'   => 'y',
      'Ы'   => 'y',
      'є'   => 'ye',
      'Є'   => 'ye',
      'ї'   => 'yi',
      'Ї'   => 'yi',
      'ё'   => 'yo',
      'Ё'   => 'yo',
      'з'   => 'z',
      'Ź'   => 'z',
      'З'   => 'z',
      'Ž'   => 'z',
      'ζ'   => 'z',
      'Ζ'   => 'z',
      'Ż'   => 'z',
      'Ж'   => 'zh',
      'ж'   => 'zh',
      '_'   => '-',
      '%20' => '-',
    );

    // Replace specific characters.
    $cleaned_filename = str_replace(array_keys($specific_replacements), array_values($specific_replacements), $cleaned_filename);

    // Convert characters to ASCII equivalents.
    $cleaned_filename = remove_accents($cleaned_filename);

    // Convert filename to lowercase.
    $cleaned_filename = strtolower($cleaned_filename);

    // Remove characters that are not a-z, 0-9, or - (dash).
    $cleaned_filename = preg_replace('/[^a-z0-9-]/', '', $cleaned_filename);

    // Remove multiple dashes in a row.
    $cleaned_filename = preg_replace('/-+/', '-', $cleaned_filename);

    // Trim potential leftover dashes at each end of filename.
    $cleaned_filename = trim($cleaned_filename, '-');

    return $cleaned_filename;
  }

  /**
   * Generates values for a newly uploaded image using the OpenAI API.
   *
   * This function is triggered when an image is uploaded. It interacts with the OpenAI API to 
   * generate specific values (e.g., alt text, description) for the image based on its image.
   * The generated values are then saved to the image's metadata in WordPress.
   *
   * @param int $attachment_id The ID of the uploaded image attachment.
   *
   * @return void This function does not return a value but directly updates the image metadata.
   */

  public function upload_new_image($attachment_id)
  {

    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_media_detail'; // Add prefix if necessary
    // Set a timeout for the script
    if (wp_attachment_is_image($attachment_id)) {
      $automation = get_option('blink_alt_text_automation', false) === 'true';
      $file_path = get_attached_file($attachment_id);
      $file_name = basename($file_path);
      // Get the WordPress uploads directory info
      $upload_dir = wp_upload_dir();
      $upload_base = trailingslashit($upload_dir['basedir']);

      // Remove the base path to leave just the year/month structure
      $relative_path = str_replace($upload_base, '', $file_path);

      // Extract the year/month portion (e.g., "2024/11")
      $subdirectory = dirname($relative_path);

      $file = $subdirectory . '/' . $file_name;
      if ($automation) {
        error_log('automation true');
        // check generate all or individually
        $generateAll = get_option('blink_alt_text_automation_generate_type', false) === 'all';
        $decorative = false;
        if ($generateAll) {
          $fieldNames = array(
            'altText',
            'title',
            'slug',
            'fileName',
            'caption',
            'description',
          );
        } else {
          $fieldNames = array();
          if (get_option('blink_alt_text_automation_individual_title', false) === 'true') {
            $fieldNames[] = 'title';
          }
          if (get_option('blink_alt_text_automation_individual_caption', false) === 'true') {
            $fieldNames[] = 'caption';
          }
          if (get_option('blink_alt_text_automation_individual_slug', false) === 'true') {
            $fieldNames[] = 'slug';
          }
          if (get_option('blink_alt_text_automation_individual_alt_text', false) === 'true') {
            $fieldNames[] = 'altText';
          }
          if (get_option('blink_alt_text_automation_individual_file_name', false) === 'true') {
            $fieldNames[] = 'fileName';
          }
          if (get_option('blink_alt_text_automation_individual_description', false) === 'true') {
            $fieldNames[] = 'description';
          }
          if (get_option('blink_alt_text_automation_individual_decorative', false) === 'true') {
            $decorative = true;
          }
        }

        $dataToUpdate = array();
        $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
        $bulk_generate_route = new \BLINK_ALT_TEXT\BulkGenerateRoute();
        foreach ($fieldNames as $fieldName) {
          $payloadChatCompletion = array(
            'fieldName' => $fieldName,
            'post_image' => wp_get_attachment_url($attachment_id),
          );
          $generateField = $bulk_generate_route->generateField($payloadChatCompletion, $chat_completion_route);
          if ($generateField['status'] == true) {
            $dataToUpdate[$fieldName] = $generateField['value'];
          } else {
            $dataToUpdate[$fieldName] = '';
          }
        }

        $wpdb->show_errors(false);
        $wpdb->query('START TRANSACTION');
        try {
          $fileName = $this->getFileName($file);
          // fill title, slug, and filename with default wordpress behaviour if automation is individual and
          // it doesnt include any of them
          if (!in_array('title', $fieldNames)) {
            $dataToUpdate['title'] = $fileName;
          }
          if (!in_array('slug', $fieldNames)) {
            $dataToUpdate['slug'] = sanitize_title($fileName);
          }
          if (!in_array('fileName', $fieldNames)) {
            $conditionedFileName = $this->conditionalSanitizeFileName($fileName);
            $dataToUpdate['fileName'] = $conditionedFileName;
          }
          $post = array(
            'ID' => $attachment_id,
            'post_excerpt' => $dataToUpdate['caption'],
            'post_title' => $dataToUpdate['title'],
            'post_name' => $dataToUpdate['slug'],
            'post_content' => $dataToUpdate['description'],
          );
          wp_update_post($post);
          update_post_meta($attachment_id, '_wp_attachment_image_alt', $dataToUpdate['altText']);
          // updating detail
          // prepare status

          // these are for calculating status of filename and alttext, but recent logic is that everytime field is checked it will becomes green
          // analyze on upload new image will always check all field so no need to calculate 
          // $tmpFileNameWithPath = $subdirectory . '/' . $dataToUpdate['fileName'];
          if (in_array('fileName', $fieldNames)) {
            $fileNameStatus = 2;
          } else {
            $fileNameStatus = $this->getFileNameStatus($file, $automation);
          }
          // $altTextStatus = $this->getAltTextStatus($dataToUpdate['altText'], $dataToUpdate['fileName'], $dataToUpdate['title']);

          $tmp = array(
            'post_id' => $attachment_id,
            'outlineAi' => in_array('outline', $fieldNames),
            'slugAi' => in_array('slug', $fieldNames),
            'captionAi' => in_array('caption', $fieldNames),
            'altTextAi' => in_array('altText', $fieldNames),
            'titleAi' => in_array('title', $fieldNames),
            'fileNameAi' => in_array('fileName', $fieldNames),
            'descriptionAi' => in_array('description', $fieldNames),
            'decorative' => $decorative,
            // 'altTextBlink' => in_array('altText', $fieldNames),
            'altTextBlink' => '',
            'fileNameStatus' => $fileNameStatus,
            'altTextStatus' => in_array('altText', $fieldNames) ? 2 : 0
          );
          $queryMediaAiStatus = $wpdb->query(
            $wpdb->prepare(
              "
              INSERT INTO $table_name (post_id, outlineAi, slugAi, captionAi, altTextAi, titleAi, fileNameAi, descriptionAi, decorative, altTextBlink, altTextStatus, fileNameStatus)
              VALUES (%d, %d, %d, %d, %d, %d, %d, %d, %d, %s, %d, %d)
              ON DUPLICATE KEY UPDATE
                  outlineAi = VALUES(outlineAi),
                  slugAi = VALUES(slugAi),
                  captionAi = VALUES(captionAi),
                  altTextAi = VALUES(altTextAi),
                  titleAi = VALUES(titleAi),
                  fileNameAi = VALUES(fileNameAi),
                  descriptionAi = VALUES(descriptionAi),
                  decorative = VALUES(decorative),
                  altTextBlink = VALUES(altTextBlink),
                  altTextStatus = VALUES(altTextStatus),
                  fileNameStatus = VALUES(fileNameStatus)
              ",
              $tmp['post_id'],
              $tmp['outlineAi'],
              $tmp['slugAi'],
              $tmp['captionAi'],
              $tmp['altTextAi'],
              $tmp['titleAi'],
              $tmp['fileNameAi'],
              $tmp['descriptionAi'],
              $tmp['decorative'],
              $tmp['altTextBlink'],
              $tmp['altTextStatus'],
              $tmp['fileNameStatus']
            )
          );

          // Check if the query was successful
          if ($queryMediaAiStatus === false) {
            throw new \Exception("Database error: " . $wpdb->last_error);
          }
          // updating filename and metadatas
          // Get the full file path of the attachment (cant use the same flow as save_post because get_post_meta is not set yet on the database)
          // $file_path = get_attached_file($attachment_id);
          // $file_name = basename($file_path);


          add_filter('wp_generate_attachment_metadata', function ($metadata) use ($file, $dataToUpdate, $attachment_id) {
            return $this->after_metadata_creation($metadata, $dataToUpdate['fileName'], $file, $attachment_id);
          });
          // $this->updateFileName($dataToUpdate['fileName'], $file, $attachment_id);
          $wpdb->query('COMMIT');
          $data = array(
            'title' => 'Success',
            'message' => 'Media successfully updated',
          );
          // $response = new \WP_REST_Response($data);
          // $response->set_status(200);
          error_log('upload with generate success');
          // return $response;
        } catch (\Throwable $th) {
          $wpdb->query('ROLLBACK');
          $data = array(
            'error' => 'Update Failed',
            'message' => 'Update failed, try again'
          );
          // $response = new \WP_REST_Response($data);
          // $response->set_status(400);
          error_log('upload with generate failed' . $th);
          // return $response;
        } finally {
          // Restore WordPress database error display to default behavior after the transaction
          $wpdb->show_errors(true);
        }
      } else {
        // cleaning filename if sanitize is true
        $sanitize = get_option('blink_alt_text_sanitize_file_name', false);
        if ($sanitize == 'true') {
          $sanitize = true;
        } else {
          $sanitize = false;
        }
        $fileName = $this->getFileName($file);
        if ($sanitize) {
          add_filter('wp_generate_attachment_metadata', function ($metadata) use ($file, $fileName, $attachment_id) {
            return $this->after_metadata_creation($metadata, $fileName, $file, $attachment_id);
          });
        }
        // adding things to media detail
        $fileNameStatus = $this->getFileNameStatus($file, $automation);

        error_log($fileNameStatus);
        $queryMediaAiStatus = $wpdb->query(
          $wpdb->prepare(
            "
          INSERT INTO $table_name (post_id, fileNameStatus)
          VALUES (%d, %d)
          ON DUPLICATE KEY UPDATE
              fileNameStatus = VALUES(fileNameStatus)
          ",
            $attachment_id,
            $fileNameStatus
          )
        );
      }
    }
  }

  /**
   * Updates the metadata of an image after it has been uploaded.
   *
   * This function is triggered after an image has been uploaded and its initial metadata 
   * is created. It allows additional modifications or updates of a filename to the metadata.
   *
   * @param array  $metadata      The metadata array generated for the uploaded image.
   * @param string $fileName      The name of the uploaded file.
   * @param string $file          The full file path of the uploaded image.
   * @param int    $attachment_id The ID of the attachment associated with the uploaded image.
   *
   * @return array The updated metadata array with modifications applied.
   */

  public function after_metadata_creation($metadata, $fileName, $file, $attachment_id)
  {
    error_log('metadata' . json_encode($metadata));
    error_log('file' . $file);
    $tmp = $this->updateFileName($fileName, $file, $attachment_id);
    error_log('tmp' . json_encode($tmp));
    if (!empty($tmp)) {
      $metadata['file'] = $tmp['file'];
      $metadata['url'] = $tmp['url'];
    }
    return $metadata;
  }

  /**
   * Calculates the score or status of a filename based on specific criteria.
   *
   * This function evaluates a filename to determine its compliance with certain rules or standards.
   * It uses the provided filename and automation settings to calculate a score or status, which
   * could reflect factors such as length, special characters, or naming conventions.
   *
   * @param string $file       The filename to be evaluated.
   * @param bool   $automation A flag indicating whether automation is enabled, potentially 
   *                            modifying the scoring or evaluation logic.
   *
   * @return int The calculated score or status of the filename.
   */

  public function getFileNameStatus($file, $automation)
  {
    // filename
    $fileName = $this->getFileName($file);
    $count = $this->countWords($fileName);
    $nonStandardSymbolsFileName = $this->containsNonStandardPunctuation($fileName ?? '', '/[^a-z0-9-]/');
    $fileNameRedCondition1 = $nonStandardSymbolsFileName;
    $fileNameRedCondition2 = $count > 8;
    $fileNameYellowCondition1 = $count < 3;
    error_log('fileName: ' . $fileName);
    error_log('fileNameRedCondition1: ' . $fileNameRedCondition1);
    error_log('fileNameRedCondition2: ' . $fileNameRedCondition2);
    error_log('fileNameYellowCondition1: ' . $fileNameYellowCondition1);
    if ($fileNameRedCondition1 || $fileNameRedCondition2) {
      $fileNameStatus = 0;
    } elseif ($fileNameYellowCondition1) {
      $fileNameStatus = 1;
    } else {
      $fileNameStatus = 1;
    }

    return $fileNameStatus;
  }

  // public function getAltTextStatus($altText, $fileName, $title)
  // {
  //   $nonStandardSymbols = $this->containsNonStandardPunctuation($altText ?? '');

  //   $altTextRedCondition2 = isset($altText) && strlen($altText) > 125;
  //   $altTextRedCondition3 = $altText == $fileName || $altText == $title;
  //   $altTextRedCondition4 = $nonStandardSymbols;
  //   $altTextYellowCondition1 = isset($altText) && strlen($altText) < 60;
  //   $altTextGreenCondition1 = true;
  //   if ($altTextRedCondition2 || $altTextRedCondition3 || $altTextRedCondition4) {
  //     $altTextStatus = 0;
  //   } elseif ($altTextYellowCondition1) {
  //     $altTextStatus = 1;
  //   } elseif ($altTextGreenCondition1) {
  //     $altTextStatus = 2;
  //   } else {
  //     // Since all red checks passed, remaining possibility is field has its value
  //     $altTextStatus = 1;
  //   }

  //   return $altTextStatus;
  // }

  public function containsNonStandardPunctuation($str, $pattern = '/[^\w\s.,!?\'"`’:]/')
  {
    error_log($str);
    return preg_match($pattern, $str);
  }

  public function getFileName($filePath)
  {
    return pathinfo($filePath, PATHINFO_FILENAME);
  }

  /**
   * Counts the number of words in a given text based on a specified separator.
   *
   * This function splits the input text using the provided separator, filters out empty words,
   * and returns the count of non-empty words. Useful for processing delimited strings.
   *
   * @param string $text      The input text to be analyzed. If empty or null, the function returns 0.
   * @param string $separator The character used to split the text into words. Default is '-'.
   *
   * @return int The number of non-empty words in the input text.
   */

  public function countWords($text, $separator = '-')
  {
    if ($text) {
      return count(array_filter(explode($separator, trim($text)), function ($word) {
        return strlen($word) > 0;
      }));
    }
    return 0;
  }

  /**
   * Renames all occurrences of an image URL in the content of posts and pages.
   *
   * This function searches for all instances of the original image URL (`$orig_image_url`) 
   * embedded in the content of posts or pages and replaces them with the new image URL 
   * (`$new_image_url`). The function iterates through all relevant content and performs the 
   * update directly in the database or appropriate storage.
   *
   * @param string $orig_image_url The original URL of the image to be replaced.
   * @param string $new_image_url  The new URL of the image to replace the original.
   *
   * @return int The number of posts/pages updated during the operation.
   */

  public function bulk_rename_content($orig_image_url, $new_image_url)
  {
    global $wpdb;
    $useless_types_conditions = "
      post_status NOT IN ('inherit', 'trash', 'auto-draft')
      AND post_type NOT IN ('attachment', 'shop_order', 'shop_order_refund', 'nav_menu_item', 'revision', 'auto-draft', 'wphb_minify_group', 'customize_changeset', 'oembed_cache', 'nf_sub', 'jp_img_sitemap')
      AND post_type NOT LIKE 'dlssus_%'
      AND post_type NOT LIKE 'ml-slide%'
      AND post_type NOT LIKE '%acf-%'
      AND post_type NOT LIKE '%edd_%'
    ";

    // Get the IDs that require an update
    $query = $wpdb->prepare("SELECT ID FROM $wpdb->posts 
			WHERE post_content LIKE '%s'
			AND {$useless_types_conditions}", '%' . $orig_image_url . '%');
    $ids = $wpdb->get_col($query);
    if (empty($ids)) {
      return array();
    }

    // Prepare SQL (WHERE IN)
    $ids_to_update = array_map(function ($id) {
      return "'" . esc_sql($id) . "'";
    }, $ids);
    $ids_to_update = implode(',', $ids_to_update);


    // Execute updates
    $query = $wpdb->prepare("UPDATE $wpdb->posts 
			SET post_content = REPLACE(post_content, '%s', '%s')
			WHERE ID IN (" . $ids_to_update . ")", $orig_image_url, $new_image_url);
    $wpdb->query($query);


    return $ids;
  }

  /**
   * Updates all embedded alt text for a specific image across posts and pages.
   *
   * This function processes the provided image data, retrieves all instances where the image is embedded
   * in posts or pages, and updates the alt text for each occurrence. It internally utilizes the 
   * `updateAltTextOnContent` function to modify the HTML content of each post or page.
   *
   * @param array $data An associative array containing the following keys:
   *   - 'path' (string): url of the image.
   *   - 'decorative' (boolean): flag either the image is decorative or not
   *   - `id` (int): The ID of the image whose alt text is to be updated.
   *   - `altText` (string): The new alt text to be applied to all embedded instances of the image.
   *
   * @return void This function does not return any value but performs updates directly on the content.
   */

  public function bulk_modify_post_page_content($data)
  {
    // check if the option to auto update alt text on content is true or not
    $auto_update = get_option('blink_alt_text_auto_update_contents', false);
    if ($auto_update == 'true') {
      $auto_update = true;
    } else {
      $auto_update = false;
    }
    if ($auto_update) {
      error_log('Auto update contents is on, Executing updates');
      global $wpdb;
      // get original image url
      $path_prefix = dirname($data['path']); // ex: 2024/11
      $file_path = get_attached_file($data['post_id']); // full path ex: C:\\xampp\\htdocs\\wordpress\\wordpress\/wp-content\/uploads\/2024\/11
      $file_info = pathinfo($file_path);
      $orig_image_url = $path_prefix . '/' . $file_info['basename'];
      error_log($orig_image_url);

      $useless_types_conditions = "
        post_status NOT IN ('inherit', 'trash', 'auto-draft')
        AND post_type NOT IN ('attachment', 'shop_order', 'shop_order_refund', 'nav_menu_item', 'revision', 'auto-draft', 'wphb_minify_group', 'customize_changeset', 'oembed_cache', 'nf_sub', 'jp_img_sitemap')
        AND post_type NOT LIKE 'dlssus_%'
        AND post_type NOT LIKE 'ml-slide%'
        AND post_type NOT LIKE '%acf-%'
        AND post_type NOT LIKE '%edd_%'
      ";

      // Get the IDs that require an update
      $query = $wpdb->prepare("SELECT ID, post_content FROM $wpdb->posts 
			WHERE post_content LIKE '%s'
			AND {$useless_types_conditions}", '%' . $orig_image_url . '%');
      $ids = $wpdb->get_results($query);
      if (empty($ids)) {
        return array();
      }
      if ($data['decorative']) {
        $altTextOnSite = '';
      } else {
        $altTextOnSite = $data['altText'];
      }
      foreach ($ids as $value) {
        $updatedHtml = $this->updateAltTextOnContent($value->post_content, $orig_image_url, $altTextOnSite);
        // error_log($updatedHtml);
        $query = $wpdb->prepare(
          "UPDATE $wpdb->posts 
      SET post_content = '%s'
      WHERE ID = $value->ID",
          $updatedHtml
        );
        $wpdb->query($query);
      }
    } else {
      error_log('Auto update contents is off');
    }
  }

  /**
   * Updates all embedded alt text for images within the provided HTML content.
   *
   * This function searches for all <img> tags in the given HTML string that match the specified filename
   * and updates their `alt` attributes with the provided new alt text.
   *
   * @param string $htmlString The HTML content containing the <img> tags.
   * @param string $filename   The name of the image file to locate within the <img> tags' `src` attributes.
   * @param string $newAlt     The new alt text to set for the matching <img> tags.
   *
   * @return string The updated HTML string with the modified alt attributes.
   */

  public function updateAltTextOnContent($htmlString, $filename, $newAlt)
  {
    // Load the HTML string into DOMDocument
    $dom = new \DOMDocument();
    libxml_use_internal_errors(true); // Suppress errors due to invalid HTML
    $dom->loadHTML($htmlString, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    // Get all <img> elements
    $images = $dom->getElementsByTagName('img');

    foreach ($images as $img) {
      $src = $img->getAttribute('src');
      error_log($src);
      error_log($filename);
      if (strpos($src, $filename) !== false) { // Check if filename exists in src
        $img->setAttribute('alt', $newAlt); // Update the alt attribute
      }
    }

    // Save the updated HTML and return it
    return $dom->saveHTML();
  }

  public function check_user_role($role)
  {
    $current_user = wp_get_current_user();

    // Check if the user has the specified role
    if (in_array($role, $current_user->roles)) {
      return true;
    }

    return false;


    // usage example
    // if (check_user_role('administrator')) {
    //   // Code for administrators
    //   add_action('admin_notices', function () {
    //     echo '<div class="notice notice-success"><p>Welcome, Administrator!</p></div>';
    //   });
    // } elseif (check_user_role('editor')) {
    //   // Code for editors
    //   add_action('admin_notices', function () {
    //     echo '<div class="notice notice-warning"><p>Welcome, Editor!</p></div>';
    //   });
    // }
  }

  public function conditional_alt_text($altTextBlink, $id)
  {
    $altTextBlink = $altTextBlink;
    $altTextWP = get_post_meta($id, '_wp_attachment_image_alt', true);
    if (!$altTextBlink) {
      // condition 1: alttext blink is null then just use alttext from wp
      $altText = $altTextWP;
    } else if ($altTextBlink != $altTextWP && ($altTextWP != null || $altTextWP != '')) {
      // condition 2 : alttext blink is not same with alttextwp (but alttext wp does exist, might be edited from native page)
      $altText = $altTextWP;
    } else if ($altTextWP != null || $altTextWP != '') {
      // if alttext wp is null, use alttextblink (it might be caused by blink's decorative function)
      $altText = $altTextBlink;
    } else {
      $altText = $altTextBlink;
    }
    return $altText;
  }

  public function get_image_pages(\WP_REST_Request $request)
  {
    global $wpdb;

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $postPerPage = isset($_GET['perPage']) ? $_GET['perPage'] : 10;
    $offset = ($page - 1) * $postPerPage;

    $id = $request->get_param('id');
    $useless_types_conditions = "
      post_status NOT IN ('inherit', 'trash', 'auto-draft')
      AND post_type NOT IN ('attachment', 'shop_order', 'shop_order_refund', 'nav_menu_item', 'revision', 'auto-draft', 'wphb_minify_group', 'customize_changeset', 'oembed_cache', 'nf_sub', 'jp_img_sitemap')
      AND post_type NOT LIKE 'dlssus_%'
      AND post_type NOT LIKE 'ml-slide%'
      AND post_type NOT LIKE '%acf-%'
      AND post_type NOT LIKE '%edd_%'
      ";
    // get count
    $countQuery = "
      SELECT COUNT(ID)
      FROM {$wpdb->posts} 
      WHERE {$useless_types_conditions} 
      AND post_content LIKE CONCAT('%wp-image-', %d, '%')
      ORDER BY post_date DESC
    ";
    // Prepare the count query with the 'id' parameter
     $preparedCountQuery = $wpdb->prepare($countQuery, $id);
    $total_records_after_filter = $wpdb->get_var($preparedCountQuery);
    $total_pages = ceil($total_records_after_filter / $postPerPage);
    // get data
    $baseQuery = "
      SELECT ID, post_title, post_date
      FROM {$wpdb->posts} 
      WHERE {$useless_types_conditions} 
      AND post_content LIKE CONCAT('%wp-image-', %d, '%')
      ORDER BY post_date DESC
      LIMIT {$postPerPage}
      OFFSET {$offset}
    ";

    // Prepare the query with the 'id' parameter
    $preparedQuery = $wpdb->prepare($baseQuery, $id);

    // Execute the query
    $attachments = $wpdb->get_results($preparedQuery);
    foreach ($attachments as $attachment) {
      $attachment->link = get_permalink($attachment->ID);
    }
    $data = array(
      'data' => $attachments,
      'pageNumber' => $total_pages,
    );
    $response = new \WP_REST_Response($data);
    $response->set_status(200);

    return $response;
  }

  public function get_image_pages_permission()
  {
    return true;
  }

  public function get_page_links(\WP_REST_Request $request)
  {
    // Get the 'id' parameter from the request
    $id = $request->get_param('id');

    // Validate the ID
    if (empty($id) || !is_numeric($id)) {
      return new \WP_Error('invalid_id', __('Invalid post ID.'), array('status' => 400));
    }

    // Get the permalink for the post
    $permalink = get_permalink($id);

    // Check if the permalink was retrieved successfully
    if (!$permalink) {
      return new \WP_Error('not_found', __('Post not found.'), array('status' => 404));
    }

    // Create the response
    $data = array('link' => $permalink);
    $response = new \WP_REST_Response($data);
    $response->set_status(200);

    return $response;
  }

  public function get_page_links_permission()
  {
    return true;
  }
}
