<?php

namespace BLINK_ALT_TEXT;

class RoleRestrictionRoute
{
  protected $roleAndCapabilities;

  public function __construct() 
  {
    $this->roleAndCapabilities = new \BLINK_ALT_TEXT\RoleAndCapabilities;
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/role_restriction', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_role_restriction' ],
        'permission_callback' => [ $this, 'get_role_restriction_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/role_restriction', [
        'methods' => 'POST',
        'callback' => [ $this, 'save_role_restriction' ],
        'permission_callback' => [ $this, 'save_role_restriction_permission' ]
    ] );
  }

  public function get_role_restriction() 
  {
    global $wpdb;

    $current_blink_alt_text_feature_restriction = esc_attr(get_option('blink_alt_text_feature_restriction'));
    $roles = $this->roleAndCapabilities->get_system_role();
    $roleWithInvidualAttribute = $this->roleAndCapabilities->get_roles_with_capability('bat_individual_attribute');
    $roleWithBulkGeneration = $this->roleAndCapabilities->get_roles_with_capability('bat_bulk_generate');
    $roleWithSetting = $this->roleAndCapabilities->get_roles_with_capability('bat_setting');
    $data = [
      'featureRestriction' => $current_blink_alt_text_feature_restriction,
      'roles' => $roles,
      'individualAttribute' => $roleWithInvidualAttribute,
      'bulkGeneration' => $roleWithBulkGeneration,
      'setting' => $roleWithSetting
    ];

    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
    return $response;
  }

  public function get_role_restriction_permission() 
  {
      return true;
  }

  public function save_role_restriction( $req ) 
  {
      $featureRestriction = sanitize_text_field( $req['featureRestriction'] );
      $this->roleAndCapabilities->add('bat_individual_attribute', $req['individualAttribute']);
      $this->roleAndCapabilities->add('bat_bulk_generate', $req['bulkGeneration']);
      $this->roleAndCapabilities->add('bat_setting', $req['setting']);
      update_option( 'blink_alt_text_feature_restriction', $featureRestriction );
      $data = [
        'featureRestriction' => $featureRestriction,
        'individualAttribute' => $req['individualAttribute'],
        'bulkGeneration' => $req['bulkGeneration'],
        'setting' => $req['setting']
      ];
      $response = new \WP_REST_Response( $data );
      $response->set_status( 200 );
      return $response;
  }

  public function save_role_restriction_permission() {
      // return current_user_can( 'publish_posts' );
      return true;
  }
}
