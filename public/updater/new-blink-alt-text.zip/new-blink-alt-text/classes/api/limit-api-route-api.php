<?php

namespace BLINK_ALT_TEXT;

class LimitApiRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/limit_ai', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_limit_ai' ],
        'permission_callback' => [ $this, 'get_limit_ai_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/limit_ai', [
        'methods' => 'POST',
        'callback' => [ $this, 'save_limit_ai' ],
        'permission_callback' => [ $this, 'save_limit_ai_permission' ]
    ] );
  }

  public function get_limit_ai() 
  {
    global $wpdb;

    $current_blink_alt_text_limit_ai = esc_attr(get_option('blink_alt_text_limit_ai'));
    $current_blink_alt_text_generation_limit = esc_attr(get_option('blink_alt_text_generation_limit'));
    $current_blink_alt_text_limit_timing = esc_attr(get_option('blink_alt_text_limit_timing'));
    $current_blink_alt_text_cost_limit = esc_attr(get_option('blink_alt_text_cost_limit'));
    $current_blink_alt_text_limit_timing_cost = esc_attr(get_option('blink_alt_text_limit_timing_cost'));
    $data = [
      'limitAi' => $current_blink_alt_text_limit_ai,
      'generationLimit' => $current_blink_alt_text_generation_limit,
      'limitTiming' => $current_blink_alt_text_limit_timing,
      'costLimit' => $current_blink_alt_text_cost_limit,
      'limitTimingCost' => $current_blink_alt_text_limit_timing_cost
    ];

    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
    return $response;
  }

  public function get_limit_ai_permission() 
  {
      return true;
  }

  public function save_limit_ai( $req ) 
  {
      $limitAi = sanitize_text_field( $req['limitAi'] );
      $generationLimit  = sanitize_text_field( $req['generationLimit'] );
      $limitTiming = sanitize_text_field( $req['limitTiming'] );
      $costLimit  = sanitize_text_field( $req['costLimit'] );
      $limitTimingCost = sanitize_text_field( $req['limitTimingCost'] );
      update_option( 'blink_alt_text_limit_ai', $limitAi );
      update_option( 'blink_alt_text_generation_limit', $generationLimit );
      update_option( 'blink_alt_text_limit_timing', $limitTiming );
      update_option( 'blink_alt_text_cost_limit', $costLimit );
      update_option( 'blink_alt_text_limit_timing_cost', $limitTimingCost );
      $data = [
        'limitAi' => $limitAi,
        'generationLimit' => $generationLimit,
        'limitTiming' => $limitTiming,
        'costLimit' => $costLimit,
        'limitTimingCost' => $limitTimingCost,
      ];
      $response = new \WP_REST_Response( $data );
      $response->set_status( 200 );
      return $response;
  }

  public function save_limit_ai_permission() {
      // return current_user_can( 'publish_posts' );
      return true;
  }

}
