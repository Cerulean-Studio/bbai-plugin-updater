<?php

namespace BLINK_ALT_TEXT;

class ScheduleRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/schedule', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_schedule' ],
        'permission_callback' => [ $this, 'get_schedule_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/schedule', [
        'methods' => 'POST',
        'callback' => [ $this, 'save_schedule' ],
        'permission_callback' => [ $this, 'save_schedule_permission' ]
    ] );

    // register_rest_route( 'blink-alt-text/v1', '/deactivated-schedule', [
    //   'methods' => 'post',
    //   'callback' => [ $this, 'remove_settings' ],
    //   'permission_callback' => [ $this, 'remove_settings_permission' ]
    // ] );
  }

  public function get_schedule() 
  {
    global $wpdb;

    $table_name = $wpdb->prefix . 'blink_alt_text_schedule_days'; // Add prefix if necessary
    $results = $wpdb->get_col( "SELECT day FROM $table_name");
    $current_schedule_active = esc_attr(get_option( 'blink_alt_text_schedule_active' ));
    $current_timezone = esc_attr(get_option( 'blink_alt_text_timezone' ));
    $current_start_time = esc_attr(get_option('blink_alt_text_start_time'));
    $current_end_time = esc_attr(get_option('blink_alt_text_end_time'));
    $data = [
      'scheduleActive' => $current_schedule_active,
      'timezone' => $current_timezone,
      'startTime' => $current_start_time,
      'endTime' => $current_end_time,
      'days' => $results
    ];

    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
    return $response;
  }

  public function get_schedule_permission() 
  {
      return true;
  }

  public function save_schedule( $req ) 
  {
      $scheduleActive = sanitize_text_field( $req['scheduleActive'] );
      $timezone  = sanitize_text_field( $req['timezone'] );
      $startTime = sanitize_text_field( $req['startTime'] );
      $endTime = sanitize_text_field( $req['endTime'] );
      update_option( 'blink_alt_text_schedule_active', $scheduleActive );
      update_option( 'blink_alt_text_timezone', $timezone );
      update_option( 'blink_alt_text_start_time', $startTime );
      update_option( 'blink_alt_text_end_time', $endTime );

      $data = [
        'scheduleActive' => $scheduleActive,
        'timezone' => $timezone,
        'startTime' => $startTime,
        'endTime' => $endTime,
        'days' => $req['days']
      ];
      $this->save_days($req['days'] );
      $response = new \WP_REST_Response( $data );
      $response->set_status( 200 );
      return $response;
  }

  public function save_schedule_permission() {
      // return current_user_can( 'publish_posts' );
      return true;
  }

  public function save_days ($seoKeywords) 
  {
    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_schedule_days'; // Add prefix if necessary
    // Delete all rows from the table
    $wpdb->query("TRUNCATE TABLE $table_name");
    
    foreach ($seoKeywords as $data) {
      $tmp = array(
          'day' => $data,
      );
      $wpdb->insert( $table_name, $tmp );
    }
  }

  // public function remove_settings( $req ) 
  // {
  //     update_option( 'blink_alt_text_openai_key', '' );
  //     $response = new \WP_REST_Response ( 'remove from db success' );
  //     $response->set_status( 200 );
  //     return $response;
  // }

  public function remove_settings_permission() 
  {
      return true;
  }
}
