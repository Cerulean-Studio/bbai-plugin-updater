<?php

namespace BLINK_ALT_TEXT;

class Uninstall
{
  public static function uninstall()
  {
    delete_option('blink_alt_text_license_activated');
    delete_option('blink_alt_text_license_key');
    delete_option('blink_alt_text_instance_id');
    delete_option('blink_alt_text_openai_key');
    delete_option('blink_alt_text_ai_model');
    delete_option('blink_alt_text_output_language');
    delete_option('blink_alt_text_generator');
    delete_option('blink_alt_text_on_upload');
    delete_option('blink_alt_text_timer');
    delete_option('blink_alt_text_automation');
    delete_option('blink_alt_text_generation_day');
    delete_option('blink_alt_text_automation_individual_title');
    delete_option('blink_alt_text_automation_individual_caption');
    delete_option('blink_alt_text_automation_individual_slug');
    delete_option('blink_alt_text_automation_individual_alt_text');
    delete_option('blink_alt_text_automation_individual_file_name');
    delete_option('blink_alt_text_automation_individual_description');
    delete_option('blink_alt_text_automation_individual_decorative');
    delete_option('blink_alt_text_ai_model_alt_text');
    delete_option('blink_alt_text_ai_model_caption');
    delete_option('blink_alt_text_ai_model_description');
    delete_option('blink_alt_text_ai_model_file_name');
    delete_option('blink_alt_text_ai_model_title');
    delete_option('blink_alt_text_ai_model_slug');
    
    // options on activator-plugin
    delete_option('blink_alt_text_tone');
    delete_option('blink_alt_text_crop_image');
    delete_option('blink_alt_text_resize_image');
    delete_option('blink_alt_text_include_credits');
    delete_option('blink_alt_text_include_image_credits');
    delete_option('blink_alt_text_include_tldr');
    delete_option('blink_alt_text_enable_comment');
    delete_option('blink_alt_text_generated_today');
    delete_option('blink_alt_text_generated_this_month');
    delete_option('blink_alt_text_last_generation_day');
    // prompts
    delete_option('blink_alt_text_website_topic');
    delete_option('blink_alt_text_tone_voice');
    delete_option('blink_alt_text_prompt_seo');
    delete_option('blink_alt_text_audience_desc');
    delete_option('blink_alt_text_generation_limit');
    delete_option('blink_alt_text_cost_limit');
    delete_option('blink_alt_text_limit_timing_cost');
    // schedule
    delete_option('blink_alt_text_schedule_active');
    delete_option('blink_alt_text_timezone');
    delete_option('blink_alt_text_start_time');
    delete_option('blink_alt_text_end_time');
    // analyze
    delete_option('blink_alt_text_analyze_fields');
    // utilities
    delete_option('blink_alt_text_auto_update_contents');
    delete_option('blink_alt_text_sanitize_file_name');
    

    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_schedule_days';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
    
    $table_name = $wpdb->prefix . 'blink_alt_text_post_history';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");

    $table_name = $wpdb->prefix . 'blink_alt_text_rss_list';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");

    $table_name = $wpdb->prefix . 'blink_alt_text_keyword_list';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");

    $table_name = $wpdb->prefix . 'blink_alt_text_queue';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");

    $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
    
  }
}