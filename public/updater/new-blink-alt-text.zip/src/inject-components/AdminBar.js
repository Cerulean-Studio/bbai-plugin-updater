import React, { useEffect, useState } from 'react';
import LoadingModal from '../components/LoadingModal';
import axios from 'axios';
import config from '../config';
import { ConfirmationModal, NotificationModal } from '../components';
import { set } from 'react-hook-form';

function AdminBar() {
  // state
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [buttonClicked, setButtonClicked] = useState('');
  const [openConfirmationLoading, setOpenConfirmationLoading] = useState(false);
  const [loadingQueue, setLoadingQueue] = useState(true);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });

  const [isOpen, setIsOpen] = useState(false);

  // methods
  const handleConfirmGenerate = () => {
    setOpenConfirmation(false);
    updateData();
  };
  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };
  const updateData = (button = buttonClicked) => {
    const menuBar = document.querySelector('#bat_parrent_menu_bar');
    const mediaData = JSON.parse(menuBar.dataset.toUpdate);
    // Convert object to array
    const mediaUpdatesQueue = Object.values(mediaData);
    // return;
    setLoadingQueue(true);
    setOpenConfirmationLoading(true);
    // Filter and map the queue
    let filteredQueue = mediaUpdatesQueue;
    if (button === 'fix_all_images_alt_text') {
      filteredQueue = mediaUpdatesQueue
        .filter((item) => item.altText) // Keep only items with altText
        .map((item) => ({
          // Keep only needed properties
          post_id: item.post_id,
          altText: true,
        }));
    } else if (button === 'fix_all_critical_attributes') {
      filteredQueue = mediaUpdatesQueue
        .filter((item) => item.altText || item.fileName) // Keep only items with altText
        .map((item) => ({
          // Keep only needed properties
          post_id: item.post_id,
          altText: item.altText,
          fileName: item.fileName,
        }));
    }

    if (filteredQueue.length === 0) {
      setLoadingQueue(false);
      setOpenConfirmationLoading(false);
      setModalConfig({
        type: 'error',
        title: 'No Data to Update',
        description: 'There are no media items to update.',
        btnText: 'Continue',
      });
      setIsOpen(true);
      return;
    }

    const payload = {
      mediaUpdatesQueue: filteredQueue,
    };
    axios
      .post(`${config.API_URL}/bulk-generate-on-page`, payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setLoadingQueue(false);
        setOpenConfirmationLoading(false);
        if (response.status === 200 || response.status === 201) {
          setModalConfig({
            type: 'success',
            title: 'Data Updated',
            description: 'Refresh the page to see changes',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
        // setPageLoading(false);
      })
      .catch(function (error) {
        setLoadingQueue(false);
        setOpenConfirmationLoading(false);
          setModalConfig({
            type: 'error',
            title: 'Update Interrupted',
            description: error.response?.data?.value,
            btnText: 'Continue',
          });
          setIsOpen(true);
      });
  };

  const checkEmpty = (button) => {
    const menuBar = document.querySelector('#bat_parrent_menu_bar');
    const mediaData = JSON.parse(menuBar.dataset.toUpdate);
    // Convert object to array
    const mediaUpdatesQueue = Object.values(mediaData);
    // for every button clicked, check if that particular function need to show modal
    if (button === 'fix_all_images_alt_text') {
      let showModal = false;
      // iterate thru the mediaUpdatesQueue and check if generateAltTextModalShow is true
      for (let i = 0; i < mediaUpdatesQueue.length; i++) {
        if (mediaUpdatesQueue[i].generateAltTextModalShow) {
          showModal = true;
        }
      }
      // if showModal is true, open confirmation modal
      if (showModal) {
        setOpenConfirmation(true);
      } else {
        // if showModal is false, proceed to updateData without opening confirmation modal
        updateData('fix_all_images_alt_text');
      }
    } else if (button === 'fix_all_images_attributes') {
      let showModal = false;
      for (let i = 0; i < mediaUpdatesQueue.length; i++) {
        if (mediaUpdatesQueue[i].generateAllAttributesModalShow) {
          showModal = true;
        }
      }
      if (showModal) {
        setOpenConfirmation(true);
      } else {
        updateData('fix_all_images_attributes');
      }
    } else if(button === 'fix_all_critical_attributes') {
      let showModal = false;
      for (let i = 0; i < mediaUpdatesQueue.length; i++) {
        if (mediaUpdatesQueue[i].generateCriticalModalShow) {
          showModal = true;
        }
      }
      if (showModal) {
        setOpenConfirmation(true);
      } else {
        updateData('fix_all_critical_attributes');
      }
    }
  };
  // created
  useEffect(() => {
    document.querySelectorAll('#wp-admin-bar-fix_all_images_alt_text').forEach(function (element) {
      element.addEventListener('click', function (event) {
        event.preventDefault();
        // setOpenConfirmation(true);
        setButtonClicked('fix_all_images_alt_text');
        checkEmpty('fix_all_images_alt_text');
      });
    });

    document.querySelectorAll('#wp-admin-bar-fix_all_critical_attributes').forEach(function (element) {
      element.addEventListener('click', function (event) {
        event.preventDefault();
        // setOpenConfirmation(true);
        setButtonClicked('fix_all_critical_attributes');
        checkEmpty('fix_all_critical_attributes');
      });
    });

    document.querySelectorAll('#wp-admin-bar-fix_all_images_attributes').forEach(function (element) {
      element.addEventListener('click', function (event) {
        event.preventDefault();
        // setOpenConfirmation(true);
        setButtonClicked('fix_all_images_attributes');
        checkEmpty('fix_all_images_attributes');
      });
    });
  }, []);

  return (
    <>
      <LoadingModal
        isOpen={openConfirmationLoading}
        title={'Generating In Progress'}
        description={
          'Please stay on this page while generation is in progress. Leaving or refreshing the page may interrupt the process.'
        }
        btnTextTrue={'Continue'}
        handleClickFalse={() => {
          setOpenConfirmationLoading(false);
        }}
        handleClose={() => {
          setOpenConfirmationLoading(false);
        }}
        handleCancel={() => {
          cancelQueue();
        }}
        loading={loadingQueue}
        cancelable={false}
      />
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <ConfirmationModal
        isOpen={openConfirmation}
        title={'Confirm System-Wide Generation'}
        description={
          <div className="bbai-text-left">
            You are about to generate new attributes for all media items. This action will:
            <br />
            <br />
            {/* <div className="bbai-text-left"> */}
            • Update selected attributes across your entire media library
            <br />
            • Replace existing values for the selected attributes
            <br />• Cannot be reverted once started
            {/* </div> */}
            <br />
            <br />
            Are you sure you want to proceed with this system-wide update?
          </div>
        }
        btnTextTrue={'Generate'}
        handleClickTrue={handleConfirmGenerate}
        btnTextFalse={'Cancel'}
        handleClickFalse={() => {
          setOpenConfirmation(false);
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      />
    </>
  );
}

export default AdminBar;
