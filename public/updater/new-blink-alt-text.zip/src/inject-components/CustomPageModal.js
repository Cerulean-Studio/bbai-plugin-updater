import React, { useEffect } from 'react';
import config from '../config';
// import { useNavigate } from 'react-router-dom';

function CustomPageModal() {
  // const navigate = useNavigate();

  const goToPage = () => {
    const targetUrl = `${config.BASE_URL}?page=blink-alt-text#/generator`;
    window.location.href = targetUrl;
  };

  return (
    <span className="bbai-text-[#6B7280] bbai-font-semibold">
      Note: <br />
      This plugin doesn’t work with this system. To adjust images, please use the plugin directly. Go to{' '}
      <span className='bbai-underline bbai-font-medium bbai-text-[#8950FC] bbai-cursor-pointer' onClick={() => goToPage()}>Blink Alt Text</span>
    </span>
  );
}

export default CustomPageModal;
