import React, { useState } from 'react';
import { Button } from '../components';
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react';

function GenerateInBulkCustom({openConfirmationModal}) {
  // state
  const [filter, setFilter] = useState({
    altText: false,
    title: false,
    fileName: false,
    caption: false,
    description: false,
    slug: false,
  });
  //const
  const filterList = [
    { name: 'altText', label: 'Alt Text' },
    { name: 'title', label: 'Title' },
    { name: 'fileName', label: 'Filename' },
    { name: 'caption', label: 'Caption' },
    { name: 'description', label: 'Description' },
    { name: 'slug', label: 'Slug' },
  ];
  //methods
  const updateFilter = (name, data) => {
    let tmp = { ...filter };
    tmp[name] = data;
    setFilter(tmp);
  };
  return (
    <Menu as="div" className="bbai-relative bbai-inline-block bbai-text-left">
      <div>
        <MenuButton className="bbai-inline-flex bbai-w-full bbai-justify-center bbai-items-center bbai-gap-x-1.5 bbai-rounded-md bbai-bg-[#8856F6] bbai-px-3 bbai-py-2 bbai-text-sm bbai-font-semibold bbai-text-white bbai-border-0">
          <svg width="14" height="12" viewBox="0 0 14 12" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M7.00065 11.25C6.81176 11.25 6.62843 11.2083 6.45065 11.125C6.27287 11.0417 6.11732 10.9222 5.98398 10.7667L0.883984 4.66667C0.783984 4.54444 0.708984 4.41111 0.658984 4.26667C0.608984 4.12222 0.583984 3.97222 0.583984 3.81667C0.583984 3.71667 0.592318 3.61389 0.608984 3.50833C0.625651 3.40278 0.661762 3.30556 0.717318 3.21667L1.96732 0.733333C2.08954 0.511111 2.25343 0.333333 2.45898 0.2C2.66454 0.0666667 2.8951 0 3.15065 0H10.8507C11.1062 0 11.3368 0.0666667 11.5423 0.2C11.7479 0.333333 11.9118 0.511111 12.034 0.733333L13.284 3.21667C13.3395 3.30556 13.3757 3.40278 13.3923 3.50833C13.409 3.61389 13.4173 3.71667 13.4173 3.81667C13.4173 3.97222 13.3923 4.12222 13.3423 4.26667C13.2923 4.41111 13.2173 4.54444 13.1173 4.66667L8.01732 10.7667C7.88398 10.9222 7.72843 11.0417 7.55065 11.125C7.37287 11.2083 7.18954 11.25 7.00065 11.25ZM5.41732 3.33333H8.58398L7.58398 1.33333H6.41732L5.41732 3.33333ZM6.33398 9.11667V4.66667H2.63398L6.33398 9.11667ZM7.66732 9.11667L11.3673 4.66667H7.66732V9.11667ZM10.0673 3.33333H11.834L10.834 1.33333H9.06732L10.0673 3.33333ZM2.16732 3.33333H3.93398L4.93398 1.33333H3.16732L2.16732 3.33333Z"
              fill="white"
            />
          </svg>
          Generate in Bulk
        </MenuButton>
      </div>

      <MenuItems
        transition
        className="bbai-absolute bbai-right-0 bbai-mt-2 bbai-w-56 bbai-origin-top-right bbai-rounded-md bbai-bg-white bbai-shadow-lg bbai-ring-1 bbai-ring-black bbai-ring-opacity-5 bbai-transition bbai-focus:outline-none data-[closed]:bbai-scale-95 data-[closed]:bbai-transform data-[closed]:bbai-opacity-0 data-[enter]:bbai-duration-100 data-[leave]:bbai-duration-75 data-[enter]:bbai-ease-out data-[leave]:bbai-ease-in"
      >
        <div className="bbai-p-3">
          {filterList.map((data, idx) => (
            <MenuItem>
              <div onClick={(e) => e.preventDefault()} className="bbai-flex bbai-items-center">
                <input
                  onClick={(e) => {
                    e.stopPropagation();
                    updateFilter(data.name, e.target.checked);
                  }}
                  id={`checkbox-default-${idx}`}
                  type="checkbox"
                  checked={filter[data['name']]}
                  class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                />
                <div className="bbai-block bbai-px-4 bbai-py-2 bbai-text-sm bbai-text-gray-700 data-[focus]:bbai-bg-gray-100 data-[focus]:bbai-text-gray-900">
                  {data.label}
                </div>
              </div>
            </MenuItem>
          ))}
          <Button customStyle='bbai-mb-2 bbai-float-right' size="sm" onClick={() => openConfirmationModal('individual',filter)}>
            <svg
              className="bbai-mr-2"
              width="17"
              height="16"
              viewBox="0 0 17 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M2.19922 14L8.86589 7.33333M12.1992 4L10.5326 5.66667"
                stroke="white"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M6.53255 1.33301L7.16275 3.03613L8.86589 3.66634L7.16275 4.29655L6.53255 5.99967L5.90234 4.29655L4.19922 3.66634L5.90234 3.03613L6.53255 1.33301Z"
                stroke="white"
                stroke-linejoin="round"
              />
              <path
                d="M12.8665 6.66699L13.2267 7.64019L14.1999 8.00033L13.2267 8.36046L12.8665 9.33366L12.5064 8.36046L11.5332 8.00033L12.5064 7.64019L12.8665 6.66699Z"
                stroke="white"
                stroke-linejoin="round"
              />
            </svg>
            Generate
          </Button>
        </div>
      </MenuItems>
    </Menu>
  );
}

export default GenerateInBulkCustom;
