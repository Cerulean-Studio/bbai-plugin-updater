import React, { useEffect, useState, useRef } from 'react';
import TextInputEditPage from './TextInputEditPage';
import config from '../config';
import axios from 'axios';
import WandInject from './WandInject';
import { renderWithRedux } from '..';
import { fecthLicense } from '../redux/actions/licenseAction';
import { useSelector } from 'react-redux';
import { createRoot } from 'react-dom/client';
import { Loader, NotificationModal } from '../components';

export default function CustomSectionEditPage() {
  const params = new URLSearchParams(window.location.search);
  const post = params.get('post'); // Get the value of the 'post' parameter
  const license = useSelector((state) => state.license.license);

  const [form, setForm] = useState({
    altText: '',
    fileName: '',
    caption: '',
    description: '',
    title: '',
    slug: '',
    decorative: false,
    path: '',
    post_id: '',
    altTextAi: false,
    captionAi: false,
    descriptionAi: false,
    fileNameAi: false,
    titleAi: false,
    slugAi: false,
  });
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [pageLoading, setPageLoading] = useState(false);

  // using ref to sync the form state with the button

  const formRef = useRef(form);

  // Sync the ref with the form state
  useEffect(() => {
    formRef.current = form;
  }, [form]);

  useEffect(() => {
    setPageLoading(true);
    fecthLicense();
    removeElement('p.attachment-alt-text');
    removeElement('p#alt-text-description');
    axios
      .get(`${config.API_URL}/posts-byid`, {
        params: { postId: post },
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        let tmp = response.data.data[0];
        console.log(tmp);
        // setDecorative(tmp.decorative);
        // updateForm(tmp.decorative, 'decorative');
        // setFileName(tmp.fileName);
        // updateForm(tmp.fileName, 'fileName');
        // updateForm(tmp.metaData?.file, 'path');
        // updateForm(tmp.post_id, 'post_id');

        setForm((prevForm) => ({
          ...prevForm,
          decorative: tmp.decorative,
          fileName: tmp.fileName,
          path: tmp.metaData?.file,
          post_id: tmp.post_id,
          altText: tmp.altText,
          altTextAi: tmp.altTextAi,
          captionAi: tmp.captionAi,
          descriptionAi: tmp.descriptionAi,
          fileNameAi: tmp.fileNameAi,
          titleAi: tmp.titleAi,
          slugAi: tmp.slugAi,
          url: tmp.url,
        }));
        injectWand('textarea#attachment_caption', 'caption', tmp.captionAi, tmp.url);
        injectWand('textarea#attachment_content', 'description', tmp.descriptionAi, tmp.url);
        injectWand('input#title', 'title', tmp.titleAi, tmp.url);
        injectWand('input#post_name', 'slug', tmp.slugAi, tmp.url);
        setPageLoading(false);
      });
  }, []);

  // methods
  const triggerModal = (type, title, description) => {
    setModalConfig({ type, title, description, btnText: 'Continue' });
    setIsOpen(true);
  };
  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };
  const submitForm = (e) => {
    e.preventDefault();
    // setPageLoading(true);
    const currentForm = formRef.current; // Get the current form state from the ref
    // console.log(currentForm);
    // return;
    axios
      .post(`${config.API_URL}/save-post`, currentForm, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setModalConfig({
            type: 'success',
            title: response.data.title,
            description: response.data.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
        setPageLoading(false);
      })
      .catch(function (error) {
        setModalConfig({
          type: 'error',
          title: error.response.data.error,
          description: error.response.data.message,
          btnText: 'Continue',
        });
        setIsOpen(true);
        setPageLoading(false);
      });
  };

  const updateCheckbox = (name, value) => {
    setForm((prevForm) => ({ ...prevForm, [`${name}Ai`]: value }));
    // axios.post(`${config.API_URL}/save-inject-checkbox`, {
    //   key: name,
    //   value: value,
    //   post_id: post,
    // });
  };

  const generateAll = () => {
    if (license?.license) {
      processCheckboxes();
    } else {
      setModalConfig({
        type: 'error',
        title: 'Activate License',
        description: 'You have to activate your license to use this feature',
        btnText: 'Continue',
      });
      setIsOpen(true);
    }
  };

  const processCheckboxes = async () => {
    setPageLoading(true);
    const falseCheckboxes = Object.fromEntries(
      Object.entries(form).filter(([key, value]) => value === false && key !== 'decorative')
    );
    let remainingCheckboxes = { ...falseCheckboxes };
    for (const property in remainingCheckboxes) {
      let apiError = false;
      let fieldName = property.replace('Ai', '');
      console.log('Execute for: ', fieldName);
      try {
        const response = await axios.post(
          `${config.API_URL}/chat-completions-generate`,
          { fieldName, post_image: form?.url },
          {
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': config.NONCE,
            },
          }
        );
        if (response.status === 200 || response.status === 201) {
          const resData = response.data.choices[0].message.content;
          setForm((prevForm) => ({ ...prevForm, [fieldName]: resData, [property]: true }));
          if (fieldName !== 'altText' || fieldName !== 'fileName') {
            updateExistingInputValue(fieldName, resData);
          }
          // Process the response here
          console.log(`Processed ${fieldName}:`, resData);
        }
      } catch (error) {
        // if (error.response) {
        //   apiError = true;
        //   setModalConfig({
        //     type: 'error',
        //     title: error.response.data.error.type,
        //     description: error.response.data.error.message,
        //     btnText: 'Continue',
        //   });
        //   setIsOpen(true);
        // }
        if (error.response.status === 429 || error.response.status === 403) {
          apiError = true;
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: error.response.data?.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          apiError = true;
          // in this else, it handles all openai api's error response
          setModalConfig({
            type: 'error',
            title: error.response.data.error.code,
            description: error.response.data.error.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      }
      if (apiError) {
        console.log('process stopped because error');
        break;
      }
    }

    console.log('All checkboxes processed');
    setPageLoading(false);
  };

  const updateExistingInputValue = (name, value) => {
    let selector;
    switch (name) {
      case 'caption':
        selector = 'textarea#attachment_caption';
        break;
      case 'description':
        selector = 'textarea#attachment_content';
        break;
      case 'title':
        selector = 'input#title';
        break;
      case 'slug':
        selector = 'input#post_name';
        break;
      default:
        selector = null;
        break;
    }
    // updating value for existing wordpress input
    const element = document.querySelector(selector);
    if (element) {
      element.value = value;
    }
    const checkbox = document.querySelector(`#checkbox-${name}`);
    if (checkbox) {
      checkbox.checked = true;
    }
  };

  // new update button
  const updateButton = document.querySelector('input#publish');
  if (updateButton) {
    const container = document.createElement('div');
    container.style.display = 'inline-block';
    updateButton.parentNode.replaceChild(container, updateButton);
    const root = createRoot(container);
    root.render(
      <button onClick={(e) => submitForm(e)} className="button button-primary button-large">
        Update
      </button>
    );
  }

  const TrackedWandInject = ({ input, name, checkboxValue, url }) => {
    const trackedWandUpdateForm = (value) => {
      setForm((prevForm) => ({ ...prevForm, [name]: value }));
    };
    trackedWandUpdateForm(input.value);
    useEffect(() => {
      const handleChange = () => trackedWandUpdateForm(input.value);
      input.addEventListener('input', handleChange);
      return () => input.removeEventListener('input', handleChange);
    }, [input]);

    const updateCheckbox = (value) => {
      setForm((prevForm) => ({ ...prevForm, [`${name}Ai`]: value }));
    };
    return (
      <WandInject
        url={url}
        checkboxValue={checkboxValue}
        updateCheckbox={updateCheckbox}
        updateForm={trackedWandUpdateForm}
        pageLoading={pageLoading}
        setPageLoading={setPageLoading}
        triggerModal={triggerModal}
        input={input}
        name={name}
        value={form[name]}
      />
    );
  };

  const injectWand = (selector, name, checkboxValue, url) => {
    const element = document.querySelector(selector);
    if (element) {
      const wrapperDiv = document.createElement('div');
      wrapperDiv.className = 'bbai-relative';
      element.parentNode.insertBefore(wrapperDiv, element);
      wrapperDiv.appendChild(element);

      const newDiv = document.createElement('div');
      wrapperDiv.appendChild(newDiv);
      renderWithRedux(
        <TrackedWandInject url={url} input={element} name={name} checkboxValue={checkboxValue} />,
        newDiv
      );
    }
  };

  const removeElement = (selector) => {
    const element = document.querySelector(selector);
    if (element) {
      element.remove();
    }
  };

  return (
    <div>
      <div
        className="bbai-bg-[#8856F6] bbai-w-fit bbai-text-white bbai-px-5 bbai-py-2 bbai-text-center bbai-mb-3 bbai-rounded-md bbai-cursor-pointer bbai-flex bbai-items-center bbai-gap-2"
        style={{ boxSizing: 'border-box' }}
        onClick={() => {
          generateAll();
        }}
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <g mask="url(#mask0_2136_37365)">
            <path
              d="M7.99967 13.25C7.81079 13.25 7.62745 13.2083 7.44967 13.125C7.2719 13.0417 7.11634 12.9222 6.98301 12.7667L1.88301 6.66667C1.78301 6.54444 1.70801 6.41111 1.65801 6.26667C1.60801 6.12222 1.58301 5.97222 1.58301 5.81667C1.58301 5.71667 1.59134 5.61389 1.60801 5.50833C1.62467 5.40278 1.66079 5.30556 1.71634 5.21667L2.96634 2.73333C3.08856 2.51111 3.25245 2.33333 3.45801 2.2C3.66356 2.06667 3.89412 2 4.14967 2H11.8497C12.1052 2 12.3358 2.06667 12.5413 2.2C12.7469 2.33333 12.9108 2.51111 13.033 2.73333L14.283 5.21667C14.3386 5.30556 14.3747 5.40278 14.3913 5.50833C14.408 5.61389 14.4163 5.71667 14.4163 5.81667C14.4163 5.97222 14.3913 6.12222 14.3413 6.26667C14.2913 6.41111 14.2163 6.54444 14.1163 6.66667L9.01634 12.7667C8.88301 12.9222 8.72745 13.0417 8.54967 13.125C8.3719 13.2083 8.18856 13.25 7.99967 13.25ZM6.41634 5.33333H9.58301L8.58301 3.33333H7.41634L6.41634 5.33333ZM7.33301 11.1167V6.66667H3.63301L7.33301 11.1167ZM8.66634 11.1167L12.3663 6.66667H8.66634V11.1167ZM11.0663 5.33333H12.833L11.833 3.33333H10.0663L11.0663 5.33333ZM3.16634 5.33333H4.93301L5.93301 3.33333H4.16634L3.16634 5.33333Z"
              fill="white"
            />
          </g>
        </svg>
        <span>Generate All Image Information</span>
      </div>
      <div
        id="decorative"
        className="bbai-flex bbai-flex-col lg:bbai-flex-row bbai-w-full bbai-mb-[10px] bbai-relative bbai-items-center"
      >
        <span className="bbai-pr-[1%] bbai-box-border">Decorative</span>
        <label className="bbai-relative bbai-flex bbai-items-center bbai-cursor-pointer">
          <input
            onChange={(e) => {
              console.log(form);
              setForm((prevForm) => ({ ...prevForm, decorative: e.target.checked }));
            }}
            checked={form.decorative}
            type="checkbox"
            id="decorative"
            name="decorative"
            className="bbai-sr-only bbai-peer"
          />
          <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
        </label>
      </div>
      <TextInputEditPage
        url={form?.url}
        license={license}
        name="fileName"
        label="File Name"
        type="text"
        updateForm={(value, name) => setForm({ ...form, [name]: value })}
        initialValue={form.fileName}
        updateCheckbox={updateCheckbox}
        checkboxValue={form.fileNameAi}
      />
      <TextInputEditPage
        url={form?.url}
        license={license}
        name="altText"
        label="Alternative Text"
        type="area"
        updateForm={(value, name) => setForm({ ...form, [name]: value })}
        initialValue={form.altText}
        updateCheckbox={updateCheckbox}
        checkboxValue={form.altTextAi}
      />
      <div className="bbai-text-[13px] bbai-mb-3">
        <a
          tabindex={-1}
          href="https://www.w3.org/WAI/tutorials/images/decision-tree/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn how to describe the purpose of the image
        </a>
        . Leave empty if the image is purely decorative.
      </div>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      {pageLoading && <Loader />}
    </div>
  );
}
