import React, { useEffect, useState } from 'react';
import { renderWithRedux } from '..';
import AdminBar from '../inject-components/AdminBar';
import { data } from 'autoprefixer';
import axios from 'axios';
import config from '../config';
import LoadingModal from '../components/LoadingModal';

export default function injectAdminBar() {
  const batAdminBar = document.querySelector('#wp-admin-bar-bat_output_languages');
  if (batAdminBar) {
    const container = document.createElement('li');
    // batAdminBar.appendChild(container);
    container.classList.add('menupop');
    container.classList.add('custom-item-class');
    container.id = 'wp-admin-bar-bat_output_languages';
    batAdminBar.insertAdjacentElement('afterend', container);
    renderWithRedux(<AdminBar/>, container);
  }
}
