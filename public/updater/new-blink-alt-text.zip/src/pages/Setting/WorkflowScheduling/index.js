import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Button, NotificationModal, Select, TextInput } from '../../../components';
import { fetchSchedule, saveSchedule } from '../../../redux/actions/scheduleAction';
import { useSelector } from 'react-redux';
export default function WorkflowScheduling() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  // redux
  const schedule = useSelector((state) => state.schedule.schedule);
  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [automaticSwitch, setAutomaticSwitch] = useState(false);
  const [days, setDays] = useState([]);
  // const data
  const timeZoneOptions = [
    { label: 'Choose a timezone', value: '' },
    { label: 'Asia/Jakarta', value: '7' },
    { label: 'Asia/Tokyo', value: '9' },
  ];
  const dayList = [
    { label: 'S', value: 'Sunday' },
    { label: 'M', value: 'Monday' },
    { label: 'T', value: 'Tuesday' },
    { label: 'W', value: 'Wednesday' },
    { label: 'T', value: 'Thursday' },
    { label: 'F', value: 'Friday' },
    { label: 'S', value: 'Saturday' },
  ];
  // created
  useEffect(() => {
    fetchSchedule();
  }, []);
  // useEffect
  useEffect(() => {
    reset(schedule);
    setDays(schedule.days || []);
  }, [schedule, reset]);
  // methods
  const onSubmit = (data) => {
    if (data.endTime > data.startTime) {
      setSubmitLoading(true);
      let { endTime, startTime, timezone, scheduleActive } = data;
      let tmp = {
        endTime,
        startTime,
        timezone,
        scheduleActive,
        days: days || schedule.days,
      };
      saveSchedule(tmp).then((res) => {
        if (res.status === 200) {
          setSubmitLoading(false);
          setModalConfig({
            type: 'success',
            title: 'Schedule Saved',
            description: 'Succesfully updated Schedule!',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
      });
    } else {
      console.log('must be greater');
    }
  };
  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };
  const updateDays = (day) => {
    if (days.includes(day)) {
      setDays((prev) => prev.filter((d) => d !== day));
    } else {
      setDays((prev) => [...prev, day]);
    }
  };
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Workflow Scheduling</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6">
        <div id="automatic" className="bbai-w-fit">
          <div className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
            Automatic
          </div>
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('scheduleActive')}
              type="checkbox"
              id="scheduleActive"
              name="scheduleActive"
              className="bbai-sr-only bbai-peer"
              onClick={() => setAutomaticSwitch(!automaticSwitch)}
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">Enable</span>
          </label>
        </div>
        {/* {automaticSwitch && ( */}
        <div className="bbai-flex bbai-flex-wrap bbai-gap-4">
          <div className="bbai-w-2/4">
            <label className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
              Automatic
            </label>
            <div
              className={`bbai-border bbai-flex bbai-justify-evenly bbai-border-gray-300 bbai-text-gray-600 bbai-text-base bbai-rounded-lg bbai bbai-py-6 bbai-px-2 focus:bbai-outline-none`}
            >
              {dayList.map((day) => (
                <div
                  onClick={() => updateDays(day?.value)}
                  className={`bbai-rounded-full bbai-cursor-pointer bbai-w-12 bbai-h-12 bbai-bg-gray-200 bbai-flex bbai-items-center bbai-justify-center bbai-text-2xl bbai-font-medium ${
                    days.includes(day?.value) ? 'bbai-bg-[#DCD7FE] bbai-text-[#6C2BD9]' : 'bbai-text-black'
                  }`}
                >
                  {day?.label}
                </div>
              ))}
            </div>
          </div>
          <div className="bbai-flex-1">
            <Select
              id="timezone"
              name="timezone"
              label="Timezone"
              placeholder="Select a timezone.."
              required={false}
              register={register}
              errors={errors}
              options={timeZoneOptions}
              customStyle="bbai-w-full bbai-max-w-full"
            />
          </div>
          <div className="bbai-w-2/4">
            <TextInput
              id="startTime"
              name="startTime"
              label="Start Time"
              placeholder="Start time.."
              required={true}
              register={register}
              errors={errors}
              type="time"
              customStyle="bbai-w-full"
            />
          </div>
          <div className="bbai-flex-1">
            <TextInput
              id="endTime"
              name="endTime"
              label="End Time"
              placeholder="End time.."
              required={true}
              register={register}
              errors={errors}
              type="time"
              customStyle="bbai-w-full"
            />
          </div>
        </div>
        {/* )} */}

        <Button size="sm" type="submit" customStyle="bbai-mt-5" loading={submitLoading}>
          Save Changes
        </Button>
      </form>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
    </div>
  );
}
