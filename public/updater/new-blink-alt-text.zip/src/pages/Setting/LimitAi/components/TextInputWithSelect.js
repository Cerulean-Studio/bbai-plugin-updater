import React, { useEffect } from 'react';

const TextInputWithSelect = ({
  id = '',
  label = '',
  name = '',
  placeholder = '',
  type = 'text',
  required = false,
  customStyle = '',
  register,
  errors,
  tooltipInfo,
  selectName,
  option,
  ...props
}) => {

  
  return (
    <div className="relative">
      {label && (
        <label
          htmlFor={id}
          className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900"
        >
          {label}
          {/* {required && (
            <span className="ml-1">
              <svg width="7" height="7" class="ml-1" viewBox="0 0 7 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M3.11222 6.04545L3.20668 3.94744L1.43679 5.08594L0.894886 4.14134L2.77415 3.18182L0.894886 2.2223L1.43679 1.2777L3.20668 2.41619L3.11222 0.318182H4.19105L4.09659 2.41619L5.86648 1.2777L6.40838 2.2223L4.52912 3.18182L6.40838 4.14134L5.86648 5.08594L4.09659 3.94744L4.19105 6.04545H3.11222Z"
                  fill="#EF4444"
                ></path>
              </svg>
            </span>
          )} */}
          {tooltipInfo && (
            <span className="bbai-ml-2">
              <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M8 16.5C6.41775 16.5 4.87103 16.0308 3.55544 15.1518C2.23985 14.2727 1.21447 13.0233 0.608967 11.5615C0.00346627 10.0997 -0.15496 8.49113 0.153721 6.93928C0.462403 5.38743 1.22433 3.96197 2.34315 2.84315C3.46197 1.72433 4.88743 0.962403 6.43928 0.653721C7.99113 0.34504 9.59966 0.503466 11.0615 1.10897C12.5233 1.71447 13.7727 2.73985 14.6518 4.05544C15.5308 5.37103 16 6.91775 16 8.5C15.9977 10.621 15.1541 12.6545 13.6543 14.1543C12.1545 15.6541 10.121 16.4977 8 16.5ZM8 2.1C6.7342 2.1 5.49683 2.47536 4.44435 3.1786C3.39188 3.88184 2.57157 4.88138 2.08717 6.05083C1.60277 7.22028 1.47603 8.5071 1.72298 9.74858C1.96992 10.9901 2.57946 12.1304 3.47452 13.0255C4.36958 13.9205 5.50995 14.5301 6.75142 14.777C7.9929 15.024 9.27973 14.8972 10.4492 14.4128C11.6186 13.9284 12.6182 13.1081 13.3214 12.0556C14.0246 11.0032 14.4 9.7658 14.4 8.5C14.3981 6.8032 13.7232 5.17644 12.5234 3.97662C11.3236 2.7768 9.6968 2.10191 8 2.1Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M8 12.5C7.78783 12.5 7.58435 12.4157 7.43432 12.2657C7.28429 12.1157 7.2 11.9122 7.2 11.7V8.5H6.4C6.18783 8.5 5.98435 8.41572 5.83432 8.26569C5.68429 8.11566 5.6 7.91218 5.6 7.7C5.6 7.48783 5.68429 7.28435 5.83432 7.13432C5.98435 6.98429 6.18783 6.9 6.4 6.9H8C8.21217 6.9 8.41566 6.98429 8.56569 7.13432C8.71572 7.28435 8.8 7.48783 8.8 7.7V11.7C8.8 11.9122 8.71572 12.1157 8.56569 12.2657C8.41566 12.4157 8.21217 12.5 8 12.5Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M9.6 12.5H6.4C6.18783 12.5 5.98435 12.4157 5.83432 12.2657C5.68429 12.1157 5.6 11.9122 5.6 11.7C5.6 11.4878 5.68429 11.2843 5.83432 11.1343C5.98435 10.9843 6.18783 10.9 6.4 10.9H9.6C9.81217 10.9 10.0157 10.9843 10.1657 11.1343C10.3157 11.2843 10.4 11.4878 10.4 11.7C10.4 11.9122 10.3157 12.1157 10.1657 12.2657C10.0157 12.4157 9.81217 12.5 9.6 12.5Z"
                  fill="#B5B5C3"
                />
                <path
                  d="M7.6 6.1C8.26274 6.1 8.8 5.56274 8.8 4.9C8.8 4.23726 8.26274 3.7 7.6 3.7C6.93726 3.7 6.4 4.23726 6.4 4.9C6.4 5.56274 6.93726 6.1 7.6 6.1Z"
                  fill="#B5B5C3"
                />
              </svg>
            </span>
          )}
        </label>
      )}
      <div className="bbai-flex">
        <input
          type={type}
          id={id}
          name={name}
          placeholder={placeholder}
          required={required}
          step=".01"
          className={`bbai-block bbai-w-10/12 bbai-rounded-l-lg bbai-rounded-r-none bbai-px-4 bbai-py-2 bbai-text-base bbai-font-normal bbai-leading-relaxed bbai-bg-[#F9FAFB] bbai-text-gray-900 bbai-placeholder-gray-400 bbai-border bbai-border-[#D1D5DB] bbai-shadow-xs bbai-focus:outline-none ${customStyle}`}
          {...register(name, { required })}
          {...props}
        />
        <select
          className="bbai-rounded-r-lg bbai-rounded-l-none bbai-w-2/12 bbai-bg-gray-200 bbai-border bbai-border-gray-300 bbai-p-2"
          id="limitTiming"
          {...register(selectName)}
        >
          {option.map((data, idx)=> (
            <option key={idx} value={data.value}>{data.label}</option>
          ))}
        </select>
      </div>
      {errors[name] && <p className="bbai-mt-2 bbai-text-xs bbai-text-red-500">This field is required</p>}
    </div>
  );
};

export default TextInputWithSelect;
