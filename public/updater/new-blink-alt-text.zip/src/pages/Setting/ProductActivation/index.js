import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { TextInput, Button, NotificationModal, Loader, ConfirmationModal } from '../../../components';
import { removeLicense, saveLicense } from '../../../redux/actions/licenseAction';
import { useSelector } from 'react-redux';
import Thumbnail from '../../../../assets/images/thumbnail.png';
import axios from 'axios';
import qs from 'qs';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const license = useSelector((state) => state.license.license);
  const loading = useSelector((state) => state.license.isLoading);

  const [submitLoading, setSubmitLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);

  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Product Activated',
    description: 'Succesfully add valid product license!',
    btnText: 'Continue',
  });

  // useEffect(() => {
  //   fecthLicense();
  // }, []);

  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };

  const censor = (text) => {
    const textCenter = text.substring(4, text.length - 4);
    const censored = textCenter.replace(/./g, '*');
    return text.replace(textCenter, censored);
  };

  const onSubmit = (data) => {
    setSubmitLoading(true);
    const license = data.license;
    const host = window.location.host;

    // Create form data as an object
    const formData = {
      license_key: license,
      instance_name: host,
    };

    axios
      .post(`https://api.lemonsqueezy.com/v1/licenses/activate`, qs.stringify(formData), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json',
        },
      })
      .then((response) => {
        const data = response.data;
        console.log('RESPONSE LEMONSQUEZZY:', data);
        if (data.activated == true) {
          saveLicense(data).then((res) => {
            if (res.status === 200) {
              setSubmitLoading(false);
              setModalConfig({
                type: 'success',
                title: 'Product Activated',
                description: 'Successfully added valid product license!',
                btnText: 'Continue',
              });
              setIsOpen(true);
            }
          });
        }
      })
      .catch((error) => {
        console.error('error', error);
        setSubmitLoading(false);
        setModalConfig({
          type: 'error',
          title: 'Activation Failed',
          description: 'Invalid license key. Please try again.',
          btnText: 'Close',
        });
        setIsOpen(true);
      });
  };

  const handleDeactivate = () => {
    console.log('DEACTIVATING LICENSE');
    setOpenConfirmation(false);
    setSubmitLoading(true);

    const formData = {
      license_key: license?.key,
      instance_id: license?.id,
    };

    axios
      .post(`https://api.lemonsqueezy.com/v1/licenses/deactivate`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Accept: 'application/json',
        },
      })
      .then((response) => {
        const data = response.data;
        if (data.deactivated == true) {
          removeLicense().then((res) => {
            if (res.status === 200) {
              setSubmitLoading(false);
              setModalConfig({
                type: 'success',
                title: 'License Deactivated',
                description: 'Succesfully deactivate license.',
                btnText: 'Continue',
              });
              setIsOpen(true);
            }
          });
        }
      })
      .catch((error) => {
        console.error('error', error);
        setSubmitLoading(false);
        setModalConfig({
          type: 'error',
          title: 'Error',
          description: error.response.data.error,
          btnText: 'Close',
        });
        setIsOpen(true);
      });
  };

  if (loading) {
    return <Loader />;
  }
  return (
    <>
      <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-1/2 bbai-h-full bbai-gap-6 bbai-px-4 ">
        {!license?.license ? (
          <>
            <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Product Activation</h1>
            <form autoComplete='off' onSubmit={handleSubmit(onSubmit)} className="bbai-w-full">
              <TextInput
                id="license"
                name="license"
                label="License Key"
                placeholder="License key.."
                required={true}
                register={register}
                errors={errors}
                customStyle="max-w-md"
              />

              <Button type="submit" customStyle="bbai-mt-5" loading={submitLoading}>
                Submit
              </Button>
            </form>
          </>
        ) : (
          <>
            <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Product Activated</h1>
            <div className="bbai-w-full">
              <div className="bbai-relative">
                <label className="bbai-flex bbai-items-center bbai-mb-4 bbai-text-sm bbai-font-medium bbai-text-gray-900">
                  License Key
                  <span className="bbai-ml-1">
                    <svg
                      width="7"
                      height="7"
                      class="ml-1"
                      viewBox="0 0 7 7"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M3.11222 6.04545L3.20668 3.94744L1.43679 5.08594L0.894886 4.14134L2.77415 3.18182L0.894886 2.2223L1.43679 1.2777L3.20668 2.41619L3.11222 0.318182H4.19105L4.09659 2.41619L5.86648 1.2777L6.40838 2.2223L4.52912 3.18182L6.40838 4.14134L5.86648 5.08594L4.09659 3.94744L4.19105 6.04545H3.11222Z"
                        fill="#EF4444"
                      ></path>
                    </svg>
                  </span>
                </label>
                <p className="bbai-text-base bbai-font-medium bbai-text-gray-500">{censor(license?.key)}</p>
              </div>

              <Button
                customStyle="bbai-mt-5"
                color="bbai-bg-red-100"
                hoverColor="hover:bbai-bg-red-200"
                textColor="bbai-text-red-500"
                loading={submitLoading}
                onClick={() => {
                  setOpenConfirmation(true);
                }}
              >
                Deactivate
              </Button>
            </div>
          </>
        )}
      </div>
      <img src={Thumbnail} alt="Logo" className="bbai-w-1/3 bbai-rounded-xl" />
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />

      <ConfirmationModal
        isOpen={openConfirmation}
        title={'Are you sure you want to deactivate this license?'}
        description={"If you deactivate the license, you won't be able to utilize the Blink Alt Text function."}
        btnTextTrue={'Deactivate'}
        handleClickTrue={handleDeactivate}
        btnTextFalse={'Cancel'}
        handleClickFalse={() => {
          setOpenConfirmation(false);
          console.log('Cancel Deactivation');
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      />
    </>
  );
}
