import { GET_LIMIT_AI, SAVE_LIMIT_AI } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchLimitAi = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/limit_ai`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_LIMIT_AI, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};


export const saveLimitAi = async (data) => {
  try {
    const formData = new FormData();
    formData.append('limitAi', data.limitAi);
    formData.append('generationLimit', data.generationLimit);
    formData.append('limitTiming', data.limitTiming);
    formData.append('costLimit', data.costLimit.replace(',', '.'));
    formData.append('limitTimingCost', data.limitTimingCost);
    const response = await axios.post(`${config.API_URL}/limit_ai`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_LIMIT_AI, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};