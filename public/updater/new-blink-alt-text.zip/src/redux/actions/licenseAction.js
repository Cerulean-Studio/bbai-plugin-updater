import { GET_LICENSE } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fecthLicense = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/licenses`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('license redux', response.data);
    dispatch({ type: GET_LICENSE, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const saveLicense = async (data) => {
  try {
    const body = {
      license_key: data.license_key.key,
      instance_id: data.instance.id,
    };
    const response = await axios.post(`${config.API_URL}/activated-license`, body, {
      headers: {
        Accept: 'application/json',
      },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const removeLicense = async (data) => {
  try {
    const response = await axios.post(`${config.API_URL}/deactivated-license`, {
      headers: {
        Accept: 'application/json',
      },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
