import { GET_LICENSE } from '../actions/types';

const initialState = {
  isLoading: true,
  license: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_LICENSE:
      return {
        ...state,
        license: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
