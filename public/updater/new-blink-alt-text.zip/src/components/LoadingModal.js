import React from 'react';
import { Description, Dialog, DialogPanel, DialogTitle, DialogBackdrop } from '@headlessui/react';
import Button from './Button';

/**
 * LoadingModal Component
 *
 * A modal used to display a loading state. This modal is non-dismissible by clicking outside, ensuring that users cannot accidentally close the modal while a process is still running.
 * The modal can only be closed by triggering a specific action, such as canceling the ongoing process or completing it. This behavior is important to prevent interruption during critical operations.
 *
 * Props:
 * - `isOpen` (boolean): Controls the visibility of the modal. If true, the modal is displayed.
 * - `handleCancel` (function): A callback function that gets triggered when the modal is closed (typically used to cancel the ongoing process).
 * - `description` (string): The loading message to display inside the modal (optional, default is "Loading...").
 *
 * Notes:
 * - The modal cannot be dismissed by clicking outside of it. It will only close when the `handleCancel` function is called, which could be used to cancel the process.
 * - Ensure the `handleCancel` function properly handles the cleanup or cancellation of the action that triggered the modal.
 */

const LoadingModal = ({ title, description, cancelable = true, btnTextTrue, handleClose, isOpen, loading, handleCancel }) => {
  return (
    <Dialog
      open={isOpen}
      onClose={() => {}}
      transition
      className="bbai-relative bbai-z-[999] bbai-transition bbai-duration-200 bbai-ease-out data-[closed]:bbai-opacity-0"
    >
      {/* The backdrop, rendered as a fixed sibling to the panel container */}
      <DialogBackdrop className="bbai-fixed bbai-inset-0 bbai-bg-black/30" />

      {/* Full-screen container to center the panel */}
      <div className="bbai-fixed bbai-inset-0 bbai-flex bbai-items-center bbai-justify-center bbai-w-screen bbai-p-4">
        {/* The actual dialog panel  */}
        <DialogPanel
          onClick={(e) => e.stopPropagation()}
          className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-between bbai-w-full bbai-max-w-sm bbai-p-6 bbai-space-y-6 bbai-bg-white bbai-rounded-lg bbai-min-h-64"
        >
          <div className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-center bbai-space-y-3">
            <span
              class="bbai-animate-spin bbai-border-solid bbai-border-gray-400 bbai-inline-block bbai-w-8 bbai-h-8 bbai-border-[3px] bbai-border-current bbai-border-t-transparent bbai-rounded-full bbai-mr-4"
              role="status"
              aria-label="loading"
            ></span>

            <DialogTitle className="bbai-text-xl bbai-font-bold bbai-text-center bbai-text-slate-900">
              {title}
            </DialogTitle>
            <Description className="bbai-text-base bbai-text-center">{description}</Description>
            {loading && <div className="bbai-animate-pulse">Loading ...</div>}
          </div>
          <div className="bbai-flex bbai-items-center bbai-justify-between bbai-w-full bbai-gap-4">
            {loading || cancelable &&  (
              <Button
                type="button"
                onClick={handleCancel}
                customStyle={`bbai-w-full ${loading ? 'bbai-bg-orange-400' : ''}`}
              >
                Cancel
              </Button>
            )}

            <Button
              disabled={loading}
              type="button"
              onClick={handleClose}
              customStyle={`bbai-w-full ${loading ? 'bbai-bg-blue-400' : ''}`}
            >
              {btnTextTrue}
            </Button>
          </div>
        </DialogPanel>
      </div>
    </Dialog>
  );
};

export default LoadingModal;
