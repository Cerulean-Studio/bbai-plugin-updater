import { useEffect } from 'react';
import { render } from '@wordpress/element';

const MyCustomComponent = () => {
  useEffect(() => {
    // Target the "Alternative Text" label and inject "A" after it
    const altTextLabel = document.querySelector('label[for="attachment-details-two-column-alt-text"]');
    if (altTextLabel && !document.querySelector('.my-custom-string')) {
      const customString = document.createElement('span');
      customString.className = 'my-custom-string';
      customString.textContent = 'A';
      altTextLabel.appendChild(customString);
    }
  }, []);

  return null;
};

// Inject the component when the modal is opened
document.addEventListener('DOMContentLoaded', function () {
  const originalOpen = wp.media.view.Modal.prototype.open;
  wp.media.view.Modal.prototype.open = function () {
    originalOpen.apply(this, arguments);

    setTimeout(() => {
      render(<MyCustomComponent />, document.querySelector('.media-modal-content'));
    }, 100);
  };
});
