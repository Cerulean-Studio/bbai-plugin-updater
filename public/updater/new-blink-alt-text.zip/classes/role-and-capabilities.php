<?php

namespace BLINK_ALT_TEXT;

class RoleAndCapabilities
{
    public function add($capability, $roles = [])
    {
        $system_roles = $this->get_system_role();
        foreach ($system_roles as $roleCode => $roleName) {
            $role = get_role($roleCode);
            if (in_array($roleCode, $roles)) {
                error_log($roleCode . ' Granted for ' . $capability);
                $role->add_cap($capability, true);
            } else {
                error_log($roleCode . ' Not Granted for ' . $capability);
                $role->add_cap($capability, false);
            }
        }
    }

    public function get_system_role()
    {
        global $wp_roles;
        $roles = $wp_roles->roles;
        error_log('Roles: ' . json_encode($roles));
        $role_names = array_map(function ($role) {
            return $role['name'];
        }, $roles);
        return $role_names;
    }

    function get_roles_with_capability($capability) {
        if (!function_exists('get_editable_roles')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }
    
        $roles_with_capability = [];
        $editable_roles = get_editable_roles();
    
        foreach ($editable_roles as $role_name => $role_info) {
            if (isset($role_info['capabilities'][$capability]) && $role_info['capabilities'][$capability] === true) {
                $roles_with_capability[] = $role_name;
            }
        }
    
        return $roles_with_capability;
    }

    function user_capable($capability) {
        $blink_alt_text_feature_restriction = get_option('blink_alt_text_feature_restriction');
        if ($blink_alt_text_feature_restriction == 'false') {
            return true;
        }
        return current_user_can($capability);
    }
}
