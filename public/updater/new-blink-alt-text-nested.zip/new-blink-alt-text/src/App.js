import { Routes, Route, useLocation } from 'react-router-dom';
import React, { useEffect } from 'react';
import routes from './routes';
import '../node_modules/pagedone/src/css/pagedone.css';
import { useSelector } from 'react-redux';
import { fecthLicense } from './redux/actions/licenseAction';
import { fetchCurrentPermission } from './redux/actions/permissionAction';
import { Loader } from './components';
import NotFound from './components/NotFound';

const App = () => {
  const location = useLocation();

  const license = useSelector((state) => state.license.license);
  const permission = useSelector((state) => state.permission.permission);
  const loading = useSelector((state) => state.permission.isLoading);
  // created
  useEffect(() => {
    fecthLicense();
    fetchCurrentPermission();
  }, []);
  // useeffect
  useEffect(() => {
    const currentUrl = location.pathname + location.hash;
    const menuItems = document.querySelectorAll('ul.wp-submenu a');
    console.log('CURRENT URL: ', currentUrl);
    menuItems.forEach((menuItem) => {
      if (menuItem.href.includes(currentUrl)) {
        console.log('ADDED CURRENT');
        menuItem.classList.add('font-bold');
        menuItem.style.color = 'white';
      } else {
        menuItem.classList.remove('font-bold');
        menuItem.style.color = '';
        console.log('REMOVE CURRENT');
      }
    });
    document.addEventListener('DOMContentLoaded', () => {
      const root = document.querySelector('span.setting[data-setting="title"]');
      console.log(root);
      if (root) {
        console.log(root);
        // ReactDOM.render(<MyComponent />, root);
      }
    });
  }, [location]);

  // methods
  const planFilter = (routes) => {
    if (!license?.license) {
      routes = routes.filter((data) => !data.pro);
    }
    return routes;
  };

  const roleFilter = (routes) => {
    if (!permission?.setting) {
      routes = routes.filter((data) => data.path !== '/settings');
    }
    return routes;
  };
  if (loading) {
    return <Loader />;
  }
  return (
    <div className="App">
      <Routes>
        {roleFilter(routes).map((route, index) => (
          <Route key={index} path={route.path} element={<route.element />}>
            {planFilter(route.child).map((child, index) => (
              <Route path={child.path} element={<child.element />} />
            ))}
          </Route>
        ))}
        {/* catch any missing route entered by user */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
};

export default App;
