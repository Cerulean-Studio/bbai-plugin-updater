import React, { useEffect, useState, useRef } from 'react';
import { CircularProgressbar } from 'react-circular-progressbar';
import { useSelector } from 'react-redux';
import { fecthLicense } from '../redux/actions/licenseAction';
import ProgressBar from '../components/ProgressBar';
import { Button, ConfirmationModal, Loader, NotificationModal } from '../components';
import ProgressBarBulk from '../components/ProgressBarBulk';
import axios from 'axios';
import config from '../config';
import GenerateButton from './GenerateButton';
import { renderWithRedux } from '..';
import BlankModal from '../components/BlankModal';
import { calculateCost, calculateTimeSave } from '../global';
import LoadingModal from '../components/LoadingModal';
import TooltipBlank from '../components/TooltipBlank';
import Tooltip from '../components/Tooltip';
import { fetchCurrentPermission } from '../redux/actions/permissionAction';

export default function DiagnoseWidget() {
  const license = useSelector((state) => state.license.license);
  const permission = useSelector((state) => state.permission.permission);

  // STATES

  const [totalImages, setTotalImages] = useState(0);
  const [bulkOngoing, setBulkOngoing] = useState(false);
  const [progressBulk, setProgressBulk] = useState({
    notDone: 0,
    done: 0,
  });

  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [generateButtonLoading, setGenerateButtonLoading] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  // generate bulk states
  const [generateAllCount, setgenerateAllCount] = useState(0);
  const [generateLimit, setGenerateLimit] = useState(0);
  const [generateType, setGenerateType] = useState('all');
  const [generateCost, setGenerateCost] = useState(0);
  const [generateAllDetail, setGenerateAllDetail] = useState([]);
  const [openConfirmationLoading, setOpenConfirmationLoading] = useState(false);
  const [loadingQueue, setLoadingQueue] = useState(true);
  const [scores, setScores] = useState({
    altText: { value: 0, color: 'bbai-bg-[#E2645F]' },
    fileName: { value: 0, color: 'bbai-bg-[#E2645F]' },
    overall: { value: 0, color: 'bbai-bg-[#E2645F]', text: 'Bad' },
  });
  const [timeSave, setTimeSave] = useState(0);
  const [pageLoading, setPageLoading] = useState(false);

  // created
  useEffect(() => {
    fecthLicense();
    fetchCurrentPermission();
    axios
      .get(`${config.API_URL}/get-widget-data`, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        let data = response.data;
        setTotalImages(data.totalImages);
        let altTextColor =
          data.altTextPercentage <= 30
            ? 'bbai-bg-[#E2645F]'
            : data.altTextPercentage <= 75
            ? 'bbai-bg-[#E19F5F]'
            : 'bbai-bg-green-500';
        let fileNameColor =
          data.fileNamePercentage <= 30
            ? 'bbai-bg-[#E2645F]'
            : data.fileNamePercentage <= 75
            ? 'bbai-bg-[#E19F5F]'
            : 'bbai-bg-green-500';
        // let overallTmp = ((data.altTextPercentage + data.fileNamePercentage) / 2).toFixed(2);
        let overallTmp = Math.round((data.altTextPercentage + data.fileNamePercentage) / 2);
        let overallText = overallTmp <= 30 ? 'Bad' : overallTmp <= 75 ? 'Good' : 'Excellent';
        let overallColor =
          overallTmp <= 30 ? 'bbai-bg-[#E2645F]' : overallTmp <= 75 ? 'bbai-bg-[#E19F5F]' : 'bbai-bg-green-500';
        setScores({
          altText: { value: data.altTextPercentage, color: altTextColor },
          fileName: { value: data.fileNamePercentage, color: fileNameColor },
          overall: { value: overallTmp, text: overallText, color: overallColor },
        });
      });
    axios.get(`${config.API_URL}/status-on-going-bulk-generate`, {}).then((response) => {
      setBulkOngoing(response.data.status);
      if (response.data.status == true) {
        axios.get(`${config.API_URL}/status-bulk-generate`, {}).then((response) => {
          setProgressBulk(response.data);
          if (response.data.notDone === 0) {
            clearInterval(window.intervalProgress);
            setBulkOngoing(false);
            setModalConfig({
              type: 'success',
              title: 'Bulk Generate Completed',
              description: 'Succesfully completed bulk generate! refresh the page to see the result.',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
      }
    });
    axios.get(`${config.API_URL}/get-failed-notify`, {}).then((response) => {
      if (response.data.status == true) {
        setModalConfig({
          type: 'error',
          title: 'Bulk Generate Interupted',
          description: response.data.message,
          btnText: 'Continue',
        });
        setIsOpen(true);
        axios.post(`${config.API_URL}/turn-off-failed-notify`);
      }
    });
    axios.post(`${config.API_URL}/generate-all-count`, { modeBulk: 'all' }).then((response) => {
      let timeSave = calculateTimeSave(response.data);
      setTimeSave(timeSave);
    });
    // renderGenerateButton();
  }, []);

  useEffect(() => {
    if (generateType == 'all') {
      setGenerateCost('Calculating ... ');
      let cost = calculateCost(generateAllDetail.length, generateAllDetail);
      setGenerateCost(cost);
    } else {
      setGenerateCost('Calculating ... ');
      let cost = calculateCost(generateLimit, generateAllDetail);
      setGenerateCost(cost);
    }
  }, [generateAllCount, generateLimit, generateType]);

  // using ref to sync the form state with the button

  const bulkOngoingRef = useRef(bulkOngoing);

  // watch

  useEffect(() => {
    bulkOngoingRef.current = bulkOngoing;
  }, [bulkOngoing]);

  useEffect(() => {
    if (bulkOngoing) {
      window.intervalProgress = setInterval(() => {
        axios.get(`${config.API_URL}/status-bulk-generate`, {}).then((response) => {
          setProgressBulk(response.data);
          if (response.data.notDone === 0) {
            clearInterval(window.intervalProgress);
            setBulkOngoing(false);
            setModalConfig({
              type: 'success',
              title: 'Bulk Generate Completed',
              description: 'Succesfully completed bulk generate!',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
      }, 5000);

      return () => clearInterval(window.intervalProgress);
    }
  }, [bulkOngoing]);

  // methods
  const goToPage = () => {
    const targetUrl = `${config.BASE_URL}?page=blink-alt-text#/generator`;
    window.location.href = targetUrl;
  };
  const openConfirmationModal = () => {
    setPageLoading(true);
    axios
      .post(
        `${config.API_URL}/generate-all-count`,
        { modeBulk: 'all' },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': config.NONCE, // Include the nonce here
          },
        }
      )
      .then((response) => {
        setOpenConfirmation(true);
        setGenerateAllDetail(response.data);
        setgenerateAllCount(response.data.length);
        setPageLoading(false);
      })
      .catch(function (error) {
        console.log(error);
        if (error.response.status === 403) {
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: error.response.data?.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          // in this else, it handles all openai api's error response
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: 'Please try again later',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
        setPageLoading(false);
      });
  };
  const cancelBulkGenerate = () => {
    axios.post(`${config.API_URL}/stop-bulk-generate`, {}).then((response) => {
      console.log(response.data);
      setBulkOngoing(false);
    });
  };

  const handleModalClick = () => {
    setIsOpen(false);
  };

  const generateAllImageInformation = () => {
    if (generateButtonLoading) return;
    setOpenConfirmation(false);
    if (!license?.license) {
      setModalConfig({
        type: 'error',
        title: 'No License',
        description: 'Please enter your license key to use this feature.',
        btnText: 'Continue',
      });
      setIsOpen(true);
    } else {
      setGenerateButtonLoading(true);
      setLoadingQueue(true);
      setOpenConfirmationLoading(true);
      axios
        .post(
          `${config.API_URL}/bulk-generate`,
          { generateType, generateLimit, modeBulk: 'all' },
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        )
        .then((response) => {
          if (response.data.length >= 1) {
            setBulkOngoing(true);
            setProgressBulk({
              notDone: response.data.length,
              done: 0,
            });
            setLoadingQueue(false);
            axios
              .post(`${config.API_URL}/trigger-start-bulk-generate`)
              .then((response) => {})
              .catch((error) => {
                console.log(error.response.data.message);
                if (error.response.data.message) {
                  setModalConfig({
                    type: 'error',
                    title: 'Bulk Generate Interupted',
                    description: error.response.data.message,
                    btnText: 'Continue',
                  });
                  setIsOpen(true);
                  setOpenConfirmationLoading(false);
                  setLoadingQueue(false);
                  // send another api to turn off notify
                  // means user wont receive it again on next page load
                  axios.post(`${config.API_URL}/turn-off-failed-notify`);
                }
              });
          } else {
            setModalConfig({
              type: 'success',
              title: 'No Unoptimized Image',
              description: 'All images already optimized.',
              btnText: 'Continue',
            });
            setIsOpen(true);
            setOpenConfirmationLoading(false);
            setLoadingQueue(false);
          }
          setGenerateButtonLoading(false);
        })
        .catch(function (error) {
          console.log(error);
          setGenerateButtonLoading(false);
          if (error.response.status == 500) {
            console.log();
            setOpenConfirmationLoading(false);
            setModalConfig({
              type: 'error',
              title: 'Request Timeout',
              description:
                'You have inserted too many items in the queue, causing a timeout. Please reduce the number of items and try again.',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
    }
  };

  const cancelQueue = () => {
    // if (controllerCancelBulk) {
    //   controllerCancelBulk.abort(); // Abort the request
    //   setControllerCancelBulk(null); // Reset the controller after cancellation
    // }
    axios.post(`${config.API_URL}/stop-queue-bulk-generate`, {}).then((response) => {
      setOpenConfirmationLoading(false);
    });
  };

  // const renderGenerateButton = () => {
  //   setTimeout(() => {
  //     const bulkSelectButton = document.querySelector('span.spinner');
  //     if (bulkSelectButton) {
  //       const container = document.createElement('div');
  //       container.style.display = 'inline-block';
  //       container.style.verticalAlign = 'middle';
  //       bulkSelectButton.insertAdjacentElement('afterend', container);
  //       renderWithRedux(
  //         <GenerateButton bulkOngoing={bulkOngoingRef} generateAllImageInformation={generateAllImageInformation} />,
  //         container
  //       );
  //     }
  //   }, 200);
  // };

  return (
    <>
      <div className="bbai-box-border bbai-w-full bbai-p-2 bbai-bg-white bbai-rounded">
        <div className="widget-header bbai-flex bbai-items-center bbai-gap-3 bbai-mb-6">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clip-path="url(#clip0_2137_69075)">
              <path
                d="M14.3281 16.8851C14.3281 20.0186 16.8678 22.5567 20.0013 22.5567C23.1349 22.5567 25.673 20.0186 25.673 16.8851H14.3281ZM35.1719 0.212891H4.82756C2.22027 0.212891 0.105469 2.32769 0.105469 4.93498V35.2793C0.105469 37.8866 2.22027 39.9998 4.82756 39.9998H35.1719C37.7792 39.9998 39.8924 37.8866 39.8924 35.2793V4.93498C39.8924 2.32769 37.7792 0.212891 35.1719 0.212891ZM20.0013 29.054C13.2787 29.054 7.82916 23.6061 7.82916 16.8851H14.3281C14.3281 13.7515 16.8678 11.2134 20.0013 11.2134C23.1349 11.2134 25.673 13.7515 25.673 16.8851H32.1703C32.1703 23.6061 26.7223 29.054 20.0013 29.054ZM20.0013 22.5567C23.1349 22.5567 25.673 20.0186 25.673 16.8851H14.3281C14.3281 20.0186 16.8678 22.5567 20.0013 22.5567Z"
                fill="#1E2126"
              />
            </g>
            <defs>
              <clipPath id="clip0_2137_69075">
                <rect width="40" height="40" fill="white" />
              </clipPath>
            </defs>
          </svg>
          <div>
            <div className="bbai-font-bold bbai-text-base">Blink Alt Text</div>
            <div className="bbai-text-xs">Contextually relevant alt text generation in a blink</div>
          </div>
        </div>
        <div className="bbai-flex bbai-mb-5">
          <div className="bbai-flex bbai-w-4/12">
            <CircularProgressbar
              value={scores.overall.value}
              text={`${scores.overall.value}%`}
              className="bbai-w-3/4"
              styles={{
                path: {
                  stroke: `#8856F6`,
                },
                trail: {
                  stroke: '#E5E7EB',
                },
                text: {
                  fontSize: '25px',
                  fontWeight: 'bold',
                  color: '#8856F6',
                },
              }}
            />
          </div>
          <div className="bbai-w-8/12 bbai-flex bbai-flex-col bbai-gap-2">
            <div className=" bbai-border-solid bbai-border-0 bbai-flex bbai-justify-evenly">
              <div>
                <div className="bbai-text-xs bbai-text-[#1E2126]">Total Images</div>
                <div className="bbai-text-xl bbai-font-semibold bbai-text-center bbai-text-[#1E2126]">
                  {totalImages}
                </div>
              </div>
              <div>
                <div className="bbai-text-xs bbai-text-[#1E2126]">Time Save w Bulk</div>
                <div className="bbai-text-xl bbai-font-semibold bbai-text-center bbai-text-[#1E2126]">{timeSave}</div>
              </div>
            </div>
            <div className=" bbai-flex bbai-justify-center bbai-flex-col ">
              <ProgressBar title={'Alt Text Quality'} progress={scores.altText.value} color={scores.altText.color} />
            </div>
            <div className=" bbai-flex bbai-justify-center bbai-flex-col ">
              <ProgressBar title={'File Name Quality'} progress={scores.fileName.value} color={scores.fileName.color} />
            </div>
          </div>
        </div>
        <div className=" bbai-flex bbai-justify-center bbai-flex-col">
          {permission.bulkGeneration && (
            <>
              {!bulkOngoing ? (
                <Button size="sm" onClick={() => openConfirmationModal()}>
                  <svg
                    className="bbai-mr-2"
                    width="17"
                    height="16"
                    viewBox="0 0 17 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2.19922 14L8.86589 7.33333M12.1992 4L10.5326 5.66667"
                      stroke="white"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M6.53255 1.33301L7.16275 3.03613L8.86589 3.66634L7.16275 4.29655L6.53255 5.99967L5.90234 4.29655L4.19922 3.66634L5.90234 3.03613L6.53255 1.33301Z"
                      stroke="white"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M12.8665 6.66699L13.2267 7.64019L14.1999 8.00033L13.2267 8.36046L12.8665 9.33366L12.5064 8.36046L11.5332 8.00033L12.5064 7.64019L12.8665 6.66699Z"
                      stroke="white"
                      stroke-linejoin="round"
                    />
                  </svg>
                  Bulk Generate Alt Text
                </Button>
              ) : (
                <ProgressBarBulk
                  cancelBulkGenerate={cancelBulkGenerate}
                  progressBulk={progressBulk}
                  color="bbai-bg-primary"
                />
              )}
            </>
          )}

          {license?.license ? (
            <Button
              onClick={() => goToPage()}
              textColor="bbai-text-[#8950FC]"
              hoverColor="hover:bbai-bg-transparent"
              size="sm"
              customStyle="bbai-mt-5 bbai-bg-transparent bbai-border bbai-border-[#8950FC] bbai-border-[1px]"
            >
              Custom Table View
            </Button>
          ) : (
            <></>
          )}
        </div>
      </div>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <BlankModal
        isOpen={openConfirmation}
        handleClickFalse={() => {
          setOpenConfirmation(false);
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      >
        <div className="bbai-text-xl bbai-font-bold bbai-text-center bbai-text-slate-900">Bulk Generate</div>
        <div className="bbai-text-sm">
          <div className="bbai-w-full">Unoptimized Images:</div>
          <div className="bbai-font-bold bbai-w-full">{generateAllCount} Images</div>
        </div>
        <div className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6">
          <div className="bbai-relative">
            <div>
              <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Queue Images</label>
              <div className="bbai-flex bbai-gap-6 bbai-mt-3">
                <div className="bbai-flex bbai-items-center">
                  <input
                    type="radio"
                    id="queueImages"
                    name="queueImages"
                    onClick={() => setGenerateType('all')}
                    checked={generateType === 'all'}
                  />
                  <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">All Images</label>
                  <Tooltip
                    customStyle={'bbai-w-40 bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3'}
                    tooltipText={'Generate all unoptimized pictures'}
                  />
                </div>
                <div className="bbai-flex bbai-items-center">
                  <input
                    type="radio"
                    id="queueImages2"
                    name="queueImages"
                    onClick={() => setGenerateType('partial')}
                    checked={generateType === 'partial'}
                  />
                  <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Limit Images</label>
                  <Tooltip
                    customStyle={'bbai-w-40 bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3'}
                    tooltipText={'Generate a limited set of unoptimized pictures (e.g.,10)'}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {generateType == 'partial' ? (
          <>
            <div className="bbai-relative">
              <label
                id="generateLimit"
                className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900"
              >
                Generate Limit
              </label>
              <input
                onChange={(e) => setGenerateLimit(e.target.value)}
                value={generateLimit}
                min={0}
                type="number"
                id="generateLimit"
                name="generateLimit"
                className={`bbai-block bbai-w-full bbai-px-4 bbai-py-2 bbai-text-base bbai-font-normal bbai-leading-relaxed bbai-text-gray-900 bbai-placeholder-gray-400 bbai-border bbai-border-gray-300 bbai-rounded-lg bbai-shadow-xs bbai-focus:outline-none`}
              />
            </div>
          </>
        ) : (
          <></>
        )}
        <div>
          <div>Estimate Cost:</div>
          <div className="bbai-font-bold">
            ${Math.ceil((generateCost + Number.EPSILON) * 100) / 100}
            <TooltipBlank>
              <div className="bbai-w-80 -bbai-ml-40 bbai-rounded bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3">
                This is an estimated cost provided for guidance. For precise details on cost calculations, please visit
                the{' '}
                <a
                  className="bbai-text-white bbai-font-bold"
                  href="https://openai.com/api/pricing/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  OpenAI
                </a>{' '}
                documentation for the latest information.
              </div>
            </TooltipBlank>
          </div>
        </div>

        <div className="bbai-flex bbai-items-center bbai-justify-between bbai-w-full bbai-gap-4">
          <Button
            type="button"
            onClick={() => setOpenConfirmation(false)}
            customStyle="bbai-w-full bbai-border bbai-border-[#D1D5DB]"
            textColor="bbai-text-[#9CA3AF]"
            color={''}
            hoverColor={'hover:bbai-bg-slate-100'}
          >
            Cancel
          </Button>
          <Button type="button" onClick={generateAllImageInformation} customStyle="bbai-w-full">
            Generate
          </Button>
        </div>
      </BlankModal>

      <LoadingModal
        isOpen={openConfirmationLoading}
        title={'Media Queue in Progress'}
        description={
          "Your media is in line for generation! We're preparing your content and will have it ready soon, thanks for your patience!"
        }
        btnTextTrue={'Continue'}
        handleClickFalse={() => {
          setOpenConfirmationLoading(false);
          console.log('Cancel Deactivation');
        }}
        handleClose={() => {
          setOpenConfirmationLoading(false);
        }}
        handleCancel={() => {
          cancelQueue();
        }}
        loading={loadingQueue}
      />
      {pageLoading && <Loader />}
    </>
  );
}
