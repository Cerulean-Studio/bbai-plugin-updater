import React from 'react';

export default function InfoCircle({ title, color, tooltipText, customStyle, customChild = false, children, customTooltipStyle }) {
  return (
    <div className={`${customStyle} bbai-flex lg:bbai-justify-end bbai-gap-3 bbai-relative bbai-z-10`}>
      <div>{title}</div>
      <div className={`bbai-w-4 bbai-h-4 ${color} bbai-rounded-full tooltip`}>
        {customChild ? (
          <div className={`tooltiptext ${customTooltipStyle}`}>{children}</div>
        ) : (
          <div className={`tooltiptext ${customTooltipStyle}`}>{tooltipText}</div>
        )}
      </div>
    </div>
  );
}
