import React, { useEffect } from 'react';
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react';
import { useSelector } from 'react-redux';
import { Button } from '../components';

export default function GenerateButton({ generateAllImageInformation, bulkOngoing }) {
  // this is because of the inject behavior, even tho on its parrent already have license
  // when generateAllImageInformation executed from this button, it will use the license from first render
  // so i retreive the license again from redux in this component and throw with together with the function
  const license = useSelector((state) => state.license.license);
  return (
    !bulkOngoing?.current ? (
      <Button size="sm" onClick={() => generateAllImageInformation(license)}>
      <svg
        className="bbai-mr-2"
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g mask="url(#mask0_2263_47974)">
          <path
            d="M9.99935 16.5625C9.76324 16.5625 9.53407 16.5104 9.31185 16.4062C9.08963 16.3021 8.89518 16.1528 8.72852 15.9583L2.35352 8.33333C2.22852 8.18056 2.13477 8.01389 2.07227 7.83333C2.00977 7.65278 1.97852 7.46528 1.97852 7.27083C1.97852 7.14583 1.98893 7.01736 2.00977 6.88542C2.0306 6.75347 2.07574 6.63194 2.14518 6.52083L3.70768 3.41667C3.86046 3.13889 4.06532 2.91667 4.32227 2.75C4.57921 2.58333 4.8674 2.5 5.18685 2.5H14.8118C15.1313 2.5 15.4195 2.58333 15.6764 2.75C15.9334 2.91667 16.1382 3.13889 16.291 3.41667L17.8535 6.52083C17.923 6.63194 17.9681 6.75347 17.9889 6.88542C18.0098 7.01736 18.0202 7.14583 18.0202 7.27083C18.0202 7.46528 17.9889 7.65278 17.9264 7.83333C17.8639 8.01389 17.7702 8.18056 17.6452 8.33333L11.2702 15.9583C11.1035 16.1528 10.9091 16.3021 10.6868 16.4062C10.4646 16.5104 10.2355 16.5625 9.99935 16.5625ZM8.02018 6.66667H11.9785L10.7285 4.16667H9.27018L8.02018 6.66667ZM9.16602 13.8958V8.33333H4.54102L9.16602 13.8958ZM10.8327 13.8958L15.4577 8.33333H10.8327V13.8958ZM13.8327 6.66667H16.041L14.791 4.16667H12.5827L13.8327 6.66667ZM3.95768 6.66667H6.16602L7.41602 4.16667H5.20768L3.95768 6.66667Z"
            fill="#EDEBFE"
          />
        </g>
      </svg>
        Generate in Bulk
      </Button>
    ) : (
      <></>
    )
  );
}
