import React from 'react';
import { Description, Dialog, DialogPanel, DialogTitle, DialogBackdrop } from '@headlessui/react';
import Button from './Button';
import CheckIcon from '../../assets/images/check.svg';
import ErrorIcon from '../../assets/images/error.svg';

const NotificationModal = ({ title, description, btnText, type, handleClick, handleClose, isOpen }) => {
  return (
    <Dialog
      open={isOpen}
      onClose={handleClose}
      transition
      className="bbai-relative bbai-z-[170000] bbai-transition bbai-duration-200 bbai-ease-out data-[closed]:bbai-opacity-0"
    >
      {/* The backdrop, rendered as a fixed sibling to the panel container */}
      <DialogBackdrop className="bbai-fixed bbai-inset-0 bbai-bg-black/30" />

      {/* Full-screen container to center the panel */}
      <div className="bbai-fixed bbai-inset-0 bbai-flex bbai-items-center bbai-justify-center bbai-w-screen bbai-p-4">
        {/* The actual dialog panel */}
        <DialogPanel className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-between bbai-w-full bbai-max-w-sm bbai-p-6 bbai-space-y-6 bbai-bg-white bbai-rounded-lg bbai-min-h-64">
          <div className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-center bbai-space-y-3">
            <img src={type == 'success' ? CheckIcon : ErrorIcon} className="bbai-w-14" alt="check-icon" />
            <DialogTitle className="bbai-text-xl bbai-font-bold bbai-text-slate-900">{title}</DialogTitle>
            <Description className="bbai-text-base bbai-text-center">{description}</Description>
          </div>
          <Button
            type="button"
            onClick={handleClick}
            customStyle="bbai-w-full"
            color={type == 'error' ? 'bbai-bg-red-800' : 'bbai-bg-primary'}
            hoverColor={type == 'error' ? 'hover:bbai-bg-red-900' : 'hover:bbai-bg-[#6e40ca]'}
          >
            {btnText}
          </Button>
        </DialogPanel>
      </div>
    </Dialog>
  );
};

export default NotificationModal;
