import React from 'react';

function Toast({ title = '', text = '', show, closeShow }) {
  return (
    <>
      {show && (
        <div
          class="bbai-flex bbai-w-4/12 bbai-py-5 bbai-px-6 bbai-bg-[#FDF2F2] bbai-rounded-md bbai-border bbai-border-gray-200 bbai-shadow-sm bbai-mb-4 bbai-gap-4 bbai-fixed bbai-right-4 bbai-bottom-4"
          role="alert"
        >
          <div class="bbai-inline-flex bbai-space-x-3">
            <div class="bbai-block">
              <h5 class="bbai-text-gray-900 bbai-mb-1 bbai-font-bold bbai-flex bbai-gap-2">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_2133_26359)">
                    <path
                      d="M8 0C6.41775 0 4.87103 0.469192 3.55544 1.34824C2.23985 2.22729 1.21447 3.47672 0.608967 4.93853C0.00346627 6.40034 -0.15496 8.00887 0.153721 9.56072C0.462403 11.1126 1.22433 12.538 2.34315 13.6569C3.46197 14.7757 4.88743 15.5376 6.43928 15.8463C7.99113 16.155 9.59966 15.9965 11.0615 15.391C12.5233 14.7855 13.7727 13.7602 14.6518 12.4446C15.5308 11.129 16 9.58225 16 8C15.9977 5.87898 15.1541 3.8455 13.6543 2.34572C12.1545 0.845932 10.121 0.00232928 8 0ZM10.9656 9.8344C11.042 9.90819 11.103 9.99647 11.1449 10.0941C11.1868 10.1917 11.2089 10.2967 11.2098 10.4029C11.2107 10.5091 11.1905 10.6144 11.1503 10.7128C11.11 10.8111 11.0506 10.9004 10.9755 10.9755C10.9004 11.0506 10.8111 11.11 10.7128 11.1503C10.6144 11.1905 10.5091 11.2107 10.4029 11.2098C10.2967 11.2089 10.1917 11.1868 10.0941 11.1449C9.99648 11.103 9.9082 11.042 9.8344 10.9656L8 9.1312L6.1656 10.9656C6.01472 11.1113 5.81264 11.192 5.60288 11.1901C5.39312 11.1883 5.19247 11.1042 5.04415 10.9559C4.89582 10.8075 4.81169 10.6069 4.80986 10.3971C4.80804 10.1874 4.88868 9.98528 5.0344 9.8344L6.8688 8L5.0344 6.1656C4.88868 6.01472 4.80804 5.81263 4.80986 5.60288C4.81169 5.39312 4.89582 5.19247 5.04415 5.04414C5.19247 4.89582 5.39312 4.81168 5.60288 4.80986C5.81264 4.80804 6.01472 4.88867 6.1656 5.0344L8 6.8688L9.8344 5.0344C9.98528 4.88867 10.1874 4.80804 10.3971 4.80986C10.6069 4.81168 10.8075 4.89582 10.9559 5.04414C11.1042 5.19247 11.1883 5.39312 11.1901 5.60288C11.192 5.81263 11.1113 6.01472 10.9656 6.1656L9.1312 8L10.9656 9.8344Z"
                      fill="#9B1C1C"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_2133_26359">
                      <rect width="16" height="16" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
                {title}
              </h5>
              <p class="bbai-text-sm bbai-font-medium bbai-text-gray-600">{text}</p>
            </div>
          </div>
          <button
            type="button"
            class="bbai-inline-flex bbai-flex-shrink-0 bbai-justify-center bbai-text-gray-400 bbai-transition-all bbai-duration-150 bbai-absolute bbai-right-2 bbai-top-2"
            data-dismiss="alert"
            onClick={() => closeShow(false)}
          >
            <span class="bbai-sr-only">Close</span>
            <svg class="bbai-w-6 bbai-h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M7 17L17 7M17 17L7 7"
                stroke="currentColor"
                stroke-width="1.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </button>
        </div>
      )}
    </>
  );
}

export default Toast;
