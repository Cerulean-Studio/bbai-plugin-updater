import React, { useState } from 'react';

export default function FileInput({
  id = '',
  label = '',
  name = '',
  placeholder = '',
  required = false,
  customStyle = '',
  register,
  errors,
  tooltipInfo,
  updateBase64,
  ...props
}) {
  // states
  const [base64, setBase64] = useState(null);
  // methods
  const onChangeInput = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onloadend = () => {
        setBase64(reader.result);
        updateBase64(reader.result);
      };
    }
  };
  return (
    <div className={`${customStyle}`}>
      <div className="bbai-font-medium bbai-text-sm bbai-mb-2 bbai-text-[#111928]">Image Upload</div>
      <div className="bbai-w-full bbai-p-9 bbai-bg-gray-50 bbai-rounded-2xl bbai-border bbai-border-gray-300 bbai-gap-3 bbai-grid bbai-border-dashed">
        {base64 ? (
          <>
            <div className="bbai-flex bbai-flex-col bbai-items-center bbai-gap-2 bbai-w-full bbai-h-auto">
              <div className="bbai-max-w-64 bbai-max-h-64 bbai-relative">
                <svg
                  onClick={() => {
                    setBase64(null);
                    updateBase64(null);
                  }}
                  className="bbai-absolute bbai-right-3 bbai-top-3 bbai-cursor-pointer"
                  width="20"
                  height="20"
                  viewBox="0 0 10 10"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <g clipPath="url(#clip0_2767_9494)">
                    <path
                      d="M5.90741 5L9.30409 1.60332C9.36538 1.54412 9.41427 1.47331 9.4479 1.39502C9.48153 1.31672 9.49924 1.23252 9.49998 1.14731C9.50072 1.0621 9.48448 0.977595 9.45221 0.898729C9.41995 0.819863 9.3723 0.748212 9.31204 0.687958C9.25179 0.627705 9.18014 0.580054 9.10127 0.547787C9.0224 0.515521 8.9379 0.499284 8.85269 0.500024C8.76748 0.500765 8.68328 0.518468 8.60498 0.5521C8.52669 0.585733 8.45588 0.634621 8.39668 0.695913L5 4.09259L1.60332 0.695913C1.48229 0.579017 1.32019 0.514333 1.15193 0.515796C0.983666 0.517258 0.822712 0.584748 0.70373 0.70373C0.584748 0.822712 0.517258 0.983666 0.515796 1.15193C0.514333 1.32019 0.579017 1.48229 0.695913 1.60332L4.09259 5L0.695913 8.39668C0.634621 8.45588 0.585733 8.52669 0.5521 8.60498C0.518468 8.68328 0.500765 8.76748 0.500024 8.85269C0.499284 8.9379 0.515521 9.0224 0.547787 9.10127C0.580054 9.18014 0.627705 9.25179 0.687958 9.31204C0.748212 9.3723 0.819863 9.41995 0.898729 9.45221C0.977595 9.48448 1.0621 9.50072 1.14731 9.49998C1.23252 9.49924 1.31672 9.48153 1.39502 9.4479C1.47331 9.41427 1.54412 9.36538 1.60332 9.30409L5 5.90741L8.39668 9.30409C8.51771 9.42098 8.67981 9.48567 8.84807 9.4842C9.01633 9.48274 9.17729 9.41525 9.29627 9.29627C9.41525 9.17729 9.48274 9.01633 9.4842 8.84807C9.48567 8.67981 9.42098 8.51771 9.30409 8.39668L5.90741 5Z"
                      fill="#6B7280"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_2767_9494">
                      <rect width="10" height="10" fill="white" />
                    </clipPath>
                  </defs>
                </svg>

                <img alt="Preview Sandbox" src={base64} />
              </div>
              <label className="bbai-cursor-pointer">
                <input {...props} onChange={(e) => onChangeInput(e)} type="file" hidden />
                <h2 className="bbai-text-center bbai-text-gray-400 bbai-text-sm bbai-leading-4">
                  <span className="bbai-text bbai-font-bold">Click to update &nbsp;</span>
                </h2>
              </label>
            </div>
          </>
        ) : (
          <>
            <label className="bbai-cursor-pointer">
              <input {...props} onChange={(e) => onChangeInput(e)} type="file" hidden />
              <div className="bbai-flex bbai-flex-col bbai-items-center bbai-gap-2">
                <svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M20.5908 13.4495H14.909V14.0323C14.9058 14.6477 14.7426 15.2512 14.4362 15.7804H20.5908V20.4423H2.40896V15.7804H8.5635C8.25708 15.2512 8.0939 14.6477 8.09078 14.0323V13.4495H2.40896C1.80619 13.4495 1.22812 13.6951 0.801897 14.1322C0.375678 14.5694 0.13623 15.1623 0.13623 15.7804V20.4423C0.13623 21.0605 0.375678 21.6533 0.801897 22.0905C1.22812 22.5276 1.80619 22.7732 2.40896 22.7732H20.5908C21.1935 22.7732 21.7716 22.5276 22.1978 22.0905C22.6241 21.6533 22.8635 21.0605 22.8635 20.4423V15.7804C22.8635 15.1623 22.6241 14.5694 22.1978 14.1322C21.7716 13.6951 21.1935 13.4495 20.5908 13.4495Z"
                    fill="#9CA3AF"
                  />
                  <path
                    d="M7.75782 6.69806L10.3635 4.02568V14.0323C10.3635 14.3414 10.4832 14.6378 10.6963 14.8564C10.9094 15.0749 11.1985 15.1977 11.4999 15.1977C11.8012 15.1977 12.0903 15.0749 12.3034 14.8564C12.5165 14.6378 12.6362 14.3414 12.6362 14.0323V4.02568L15.2419 6.69806C15.4562 6.91036 15.7433 7.02783 16.0412 7.02518C16.3392 7.02252 16.6242 6.89995 16.8349 6.68387C17.0456 6.46778 17.1651 6.17547 17.1677 5.86889C17.1703 5.56231 17.0557 5.26792 16.8435 5.05258L12.8019 0.884123C12.5887 0.663418 12.2999 0.539795 11.9999 0.539795C11.7 0.539795 11.4112 0.663418 11.1979 0.884123L7.15639 5.05258C6.94412 5.26792 6.82955 5.56231 6.83212 5.86889C6.83469 6.17547 6.95421 6.46778 7.16492 6.68387C7.37562 6.89995 7.66065 7.02252 7.9586 7.02518C8.25654 7.02783 8.54368 6.91036 8.75796 6.69806H7.75782Z"
                    fill="#9CA3AF"
                  />
                </svg>
                <div className="bbai-font-semibold bbai-text-gray-400 bbai-text-sm">Click to upload image</div>
                <h2 className="bbai-text-center bbai-text-gray-400 bbai-text-sm bbai-leading-4">
                  <span className="bbai-text bbai-font-bold">JPG</span>,{' '}
                  <span className="bbai-text bbai-font-bold">PNG</span> or{' '}
                  <span className="bbai-text bbai-font-bold">SVG</span>
                  <br />
                  (max, 800x400px)
                </h2>
              </div>
            </label>
          </>
        )}
      </div>
    </div>
  );
}
