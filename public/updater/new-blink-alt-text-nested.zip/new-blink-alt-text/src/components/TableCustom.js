import React from 'react';
import Tooltip from './Tooltip';

function TableCustom({ columns = [], evenSize = false, headerAlign = 'bbai-text-left', children }) {
  const columnWidth = evenSize ? `${100 / columns.length}%` : '';
  return (
    <div class="bbai-flex bbai-flex-col">
      <div class="bbai-overflow-x-auto">
        <div class="bbai-min-w-full bbai-inline-block bbai-align-middle">
          <div class="bbai-overflow-hidden bbai-border bbai-rounded-lg bbai-border-gray-300">
            <table class="bbai-min-w-full bbai-rounded-xl">
              <thead>
                <tr class="bbai-bg-gray-50">
                  {columns.map((column, index) => (
                    <th
                      scope="col"
                      style={{ width: columnWidth }}
                      class={`bbai-p-5 ${headerAlign} bbai-text-sm bbai-leading-6 bbai-font-semibold bbai-text-gray-900 bbai-capitalize bbai-relative`}
                    >
                      <div className="">
                        <div>{column.label}</div>
                        {column.tooltip && (
                          <div className="bbai-absolute bbai-right-2 bbai-top-1/2 bbai--translate-y-1/2">
                            <Tooltip
                              tooltipPosition="bottom"
                              customStyle={`bbai-w-40 bbai-text-xs bbai-bg-[#4B5563] bbai-py-1 bbai-px-3 
                                ${index === columns.length - 1 ? 'bbai-right-[-10%]' : ''}`}
                              tooltipText={column.tooltip}
                            />
                          </div>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody class="bbai-divide-y bbai-divide-gray-300">{children}</tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TableCustom;
