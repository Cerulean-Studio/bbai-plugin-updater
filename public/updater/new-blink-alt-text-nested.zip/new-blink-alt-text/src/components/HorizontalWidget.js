import React, { useState, useEffect } from 'react';
import { CircularProgressbar } from 'react-circular-progressbar';
import ProgressBar from './ProgressBar';
import Button from './Button';
import ProgressBarBulk from './ProgressBarBulk';
import axios from 'axios';
import config from '../config';

export default function HorizontalWidget({
  license,
  bulkOngoing = false,
  progressBulk = { notDone: 0, done: 0 },
  cancelBulkGenerate,
  generateAllImageInformation,
  triggerUpdateData,
  permission,
}) {
  // states
  const [totalImages, setTotalImages] = useState(0);
  const [scores, setScores] = useState({
    altText: { value: 0, color: 'bbai-bg-[#E2645F]' },
    fileName: { value: 0, color: 'bbai-bg-[#E2645F]' },
    overall: { value: 0, color: 'bbai-bg-[#E2645F]', text: 'Bad' },
  });

  // useeffects
  useEffect(() => {
    updateData();
  }, [triggerUpdateData]);

  // methods
  const updateData = () => {
    axios
      .get(`${config.API_URL}/get-widget-data`, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        let data = response.data;
        setTotalImages(data.totalImages);
        let altTextColor =
          data.altTextPercentage <= 30
            ? 'bbai-bg-[#E2645F]'
            : data.altTextPercentage <= 75
            ? 'bbai-bg-[#E19F5F]'
            : 'bbai-bg-green-500';
        let fileNameColor =
          data.fileNamePercentage <= 30
            ? 'bbai-bg-[#E2645F]'
            : data.fileNamePercentage <= 75
            ? 'bbai-bg-[#E19F5F]'
            : 'bbai-bg-green-500';
        // let overallTmp = ((data.altTextPercentage + data.fileNamePercentage) / 2).toFixed(2);
        let overallTmp = Math.round((data.altTextPercentage + data.fileNamePercentage) / 2);
        let overallText = overallTmp <= 30 ? 'Bad' : overallTmp <= 75 ? 'Good' : 'Excellent';
        let overallColor =
          overallTmp <= 30 ? 'bbai-bg-[#E2645F]' : overallTmp <= 75 ? 'bbai-bg-[#E19F5F]' : 'bbai-bg-green-500';
        setScores({
          altText: { value: data.altTextPercentage, color: altTextColor },
          fileName: { value: data.fileNamePercentage, color: fileNameColor },
          overall: { value: overallTmp, text: overallText, color: overallColor },
        });
      });
  };

  return (
    <>
      {!license?.license ? (
        <>
          <div className=" bbai-my-4 bbai-w-full bbai-h-24 bbai-flex bbai-justify-center bbai-p-3 bbai-items-center bbai-bg-white bbai-rounded">
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-1 bbai-pr-4 bbai-border-r bbai-border-[#D9DADC]">
              <CircularProgressbar
                value={scores.overall.value}
                text={`${scores.overall.value}%`}
                className="bbai-w-2/4"
                styles={{
                  path: {
                    stroke: `#8856F6`,
                  },
                  trail: {
                    stroke: '#E5E7EB',
                  },
                  text: {
                    fontSize: '25px',
                    fontWeight: 'bold',
                    color: '#8856F6',
                  },
                }}
              />

              <div className="bbai-flex-1 bbai-flex bbai-flex-col bbai-justify-center">
                <div className="bbai-text-[#9CA3AF] bbai-text-xs">State</div>
                <div className="bbai-text-[#8856F6] bbai-text-xl bbai-font-semibold">{scores.overall.text}</div>
              </div>
            </div>
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-px-4 bbai-border-r bbai-border-[#D9DADC]">
              <ProgressBar title={'Alt Text Quality'} progress={scores.altText.value} color={scores.altText.color} />
            </div>
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-px-4 bbai-border-r bbai-border-[#D9DADC]">
              <ProgressBar title={'File Name Quality'} progress={scores.fileName.value} color={scores.fileName.color} />
            </div>
            {permission.bulkGeneration && (
              <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-pl-4">
                <Button size="sm" onClick={() => generateAllImageInformation()}>
                  <svg
                    className="bbai-mr-2"
                    width="17"
                    height="16"
                    viewBox="0 0 17 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M2.19922 14L8.86589 7.33333M12.1992 4L10.5326 5.66667"
                      stroke="white"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M6.53255 1.33301L7.16275 3.03613L8.86589 3.66634L7.16275 4.29655L6.53255 5.99967L5.90234 4.29655L4.19922 3.66634L5.90234 3.03613L6.53255 1.33301Z"
                      stroke="white"
                      stroke-linejoin="round"
                    />
                    <path
                      d="M12.8665 6.66699L13.2267 7.64019L14.1999 8.00033L13.2267 8.36046L12.8665 9.33366L12.5064 8.36046L11.5332 8.00033L12.5064 7.64019L12.8665 6.66699Z"
                      stroke="white"
                      stroke-linejoin="round"
                    />
                  </svg>
                  Fix All Images Alt Text
                </Button>
              </div>
            )}
          </div>
        </>
      ) : (
        <>
          <div className=" bbai-my-4 bbai-w-full bbai-h-24 bbai-flex bbai-justify-center bbai-p-3 bbai-items-center bbai-bg-white bbai-rounded">
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-1 bbai-pr-4 bbai-border-r bbai-border-[#D9DADC]">
              <CircularProgressbar
                value={scores.overall.value}
                text={`${scores.overall.value}%`}
                className="bbai-w-2/4"
                styles={{
                  path: {
                    stroke: `#8856F6`,
                  },
                  trail: {
                    stroke: '#E5E7EB',
                  },
                  text: {
                    fontSize: '25px',
                    fontWeight: 'bold',
                    color: '#8856F6',
                  },
                }}
              />

              <div className="bbai-flex-1 bbai-flex bbai-flex-col bbai-justify-center">
                <div className="bbai-text-[#9CA3AF] bbai-text-xs">State</div>
                <div className="bbai-text-[#8856F6] bbai-text-xl bbai-font-semibold">{scores.overall.text}</div>
              </div>
            </div>
            <div className="bbai-text-center bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-px-4 bbai-border-r bbai-border-[#D9DADC]">
              <div className="bbai-text-xs bbai-text-[#1E2126]">Total Images</div>
              <div className="bbai-text-xl bbai-font-semibold bbai-text-[#1E2126]">{totalImages}</div>
            </div>
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-px-4 bbai-border-r bbai-border-[#D9DADC]">
              <ProgressBar title={'Alt Text Quality'} progress={scores.altText.value} color={scores.altText.color} />
            </div>
            <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-px-4">
              <ProgressBar title={'File Name Quality'} progress={scores.fileName.value} color={scores.fileName.color} />
            </div>
            {permission.bulkGeneration && (
              <div className=" bbai-h-full bbai-flex bbai-justify-center bbai-flex-col bbai-flex-1 bbai-pl-4">
                {!bulkOngoing ? (
                  <Button size="sm" onClick={() => generateAllImageInformation()}>
                    <svg
                      className="bbai-mr-2"
                      width="17"
                      height="16"
                      viewBox="0 0 17 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M2.19922 14L8.86589 7.33333M12.1992 4L10.5326 5.66667"
                        stroke="white"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M6.53255 1.33301L7.16275 3.03613L8.86589 3.66634L7.16275 4.29655L6.53255 5.99967L5.90234 4.29655L4.19922 3.66634L5.90234 3.03613L6.53255 1.33301Z"
                        stroke="white"
                        stroke-linejoin="round"
                      />
                      <path
                        d="M12.8665 6.66699L13.2267 7.64019L14.1999 8.00033L13.2267 8.36046L12.8665 9.33366L12.5064 8.36046L11.5332 8.00033L12.5064 7.64019L12.8665 6.66699Z"
                        stroke="white"
                        stroke-linejoin="round"
                      />
                    </svg>
                    Fix All Images Alt Text
                  </Button>
                ) : (
                  <ProgressBarBulk
                    cancelBulkGenerate={cancelBulkGenerate}
                    progressBulk={progressBulk}
                    color="bbai-bg-primary"
                  />
                )}
              </div>
            )}
          </div>
        </>
      )}
    </>
  );
}
