import React from 'react';
import Tooltip from './Tooltip';

const Select = ({
  id = '',
  label = '',
  name = '',
  placeholder = '',
  required = false,
  customStyle = '',
  register,
  errors,
  options,
  tooltipInfo,
  tooltipText,
  ...props
}) => {
  return (
    <div className="bbai-relative">
      {label && (
        <label htmlFor={id} className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
          {label}
          {tooltipInfo && (
            <>
              <Tooltip tooltipText={tooltipText}/>
            </>
          )}
        </label>
      )}
      <select
        {...register(name, { required })}
        id="countries"
        class={`bbai-h-12 bbai-border bbai-border-gray-300 bbai-text-gray-600 bbai-text-base bbai-rounded-lg bbai-block bbai-py-2.5 bbai-px-4 focus:bbai-outline-none ${customStyle}`}
      >
        {options.map((data, idx) => (
          <option key={idx} value={data.value}>
            {data.label}
          </option>
        ))}
      </select>
      {errors[name] && <p className="bbai-mt-2 bbai-text-xs bbai-text-red-500">This field is required</p>}
    </div>
  );
};

export default Select;
