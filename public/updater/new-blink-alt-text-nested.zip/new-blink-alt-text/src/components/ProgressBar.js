import React from 'react';

export default function ProgressBar({ progress, color, title }) {
  return (
    <>
      <div className='bbai-flex bbai-justify-between bbai-mb-2'>
        <div>
            {title}
        </div>
        <div>
            {progress}%
        </div>
      </div>
      <div class="bbai-w-full bbai-bg-gray-100 bbai-rounded-3xl bbai-h-1.5 ">
        <div class={`${color} bbai-h-1.5 bbai-rounded-3xl`} style={{width: `${progress}%`}}></div>
      </div>
    </>
  );
}
