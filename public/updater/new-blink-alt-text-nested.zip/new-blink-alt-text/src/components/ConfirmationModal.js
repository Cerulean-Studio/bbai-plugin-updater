import React from 'react';
import { Description, Dialog, DialogPanel, DialogTitle, DialogBackdrop } from '@headlessui/react';
import Button from './Button';
import ConfirmationIcon from '../../assets/images/confirmation.svg';

const ConfirmationModal = ({
  title,
  description,
  btnTextTrue,
  btnTextFalse,
  handleClickTrue,
  handleClickFalse,
  handleClose,
  isOpen,
}) => {
  return (
    <Dialog
      open={isOpen}
      onClose={handleClose}
      transition
      className="bbai-relative bbai-z-[999] bbai-transition bbai-duration-200 bbai-ease-out data-[closed]:bbai-opacity-0"
    >
      {/* The backdrop, rendered as a fixed sibling to the panel container */}
      <DialogBackdrop className="bbai-fixed bbai-inset-0 bbai-bg-black/30" />

      {/* Full-screen container to center the panel */}
      <div className="bbai-fixed bbai-inset-0 bbai-flex bbai-items-center bbai-justify-center bbai-w-screen bbai-p-4">
        {/* The actual dialog panel  */}
        <DialogPanel className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-between bbai-w-full bbai-max-w-sm bbai-p-6 bbai-space-y-6 bbai-bg-white bbai-rounded-lg bbai-min-h-64">
          <div className="bbai-flex bbai-flex-col bbai-items-center bbai-justify-center bbai-space-y-3">
            <img src={ConfirmationIcon} className="bbai-w-14" alt="confirmation-icon" />
            <DialogTitle className="bbai-text-xl bbai-font-bold bbai-text-center bbai-text-slate-900">{title}</DialogTitle>
            <Description className="bbai-text-base bbai-text-center">{description}</Description>
          </div>
          <div className="bbai-flex bbai-items-center bbai-justify-between bbai-w-full bbai-gap-4">
            <Button
              type="button"
              onClick={handleClickFalse}
              customStyle="bbai-w-full bbai-border bbai-border-[#D1D5DB]"
              textColor="bbai-text-[#9CA3AF]"
              color={''}
              hoverColor={'hover:bbai-bg-slate-100'}
            >
              {btnTextFalse}
            </Button>
            <Button type="button" onClick={handleClickTrue} customStyle="bbai-w-full">
              {btnTextTrue}
            </Button>
          </div>
        </DialogPanel>
      </div>
    </Dialog>
  );
};

export default ConfirmationModal;
