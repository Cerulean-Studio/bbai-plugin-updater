import React from 'react';

export default function Pagination({ className, currentPage, lastPage, pageClick }) {
  return (
    <div
      className={`${className} bbai-h-9 bbai-flex bbai-border bbai-border-[#D1D5DB] bbai-rounded-md bbai-w-fit bbai-text-sm bbai-font-medium bbai-text-[#6B7280]`}
    >
      <div
        onClick={() => currentPage > 1? pageClick(currentPage - 1):''}
        className="bbai-p-2 bbai-justify-center bbai-min-w-9 bbai-text-center bbai-cursor-pointer bbai-flex bbai-items-center bbai-border bbai-border-[#D1D5DB]"
      >
        <svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M4.98974 11.3996C4.72508 11.3995 4.47128 11.2859 4.28416 11.0836L0.292199 6.76886C0.105104 6.56658 0 6.29226 0 6.00624C0 5.72021 0.105104 5.4459 0.292199 5.24361L4.28416 0.928916C4.37623 0.825892 4.48635 0.743716 4.60811 0.687184C4.72987 0.630651 4.86082 0.600895 4.99334 0.59965C5.12585 0.598406 5.25726 0.625698 5.37991 0.679934C5.50256 0.734171 5.61399 0.814266 5.70769 0.915546C5.8014 1.01683 5.8755 1.13726 5.92568 1.26983C5.97586 1.40239 6.00111 1.54443 5.99996 1.68766C5.99881 1.83088 5.97128 1.97243 5.91898 2.10403C5.86667 2.23563 5.79064 2.35466 5.69532 2.45416L2.40894 6.00624L5.69532 9.55831C5.83485 9.70917 5.92987 9.90135 5.96836 10.1106C6.00685 10.3198 5.98709 10.5366 5.91157 10.7337C5.83605 10.9308 5.70817 11.0992 5.54409 11.2177C5.38001 11.3363 5.1871 11.3996 4.98974 11.3996Z"
            fill="#6B7280"
          />
        </svg>
      </div>
      {/* {currentPage > 2 && (
        <>
          <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">1</div>
          <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">2</div>
          <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">...</div>
        </>
      )}
      <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">1</div>
      <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">2</div>
      <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">3</div>
      <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">...</div>
      <div className="bbai-p-2 bbai-min-w-9 bbai-text-center bbai-border-x bbai-border-[#D1D5DB]">100</div> */}
      {[...Array.from(Array(lastPage).keys())].map((num) => (
        <div
          onClick={() => currentPage != (num+1) ? pageClick(num + 1):''}
          key={num}
          className={`bbai-p-2 bbai-min-w-9 bbai-text-center bbai-cursor-pointer bbai-border-x bbai-border-[#D1D5DB] ${
            currentPage == num + 1 ? 'bbai-text-[#7E3AF2] bbai-bg-[#EDEBFE]' : ''
          }`}
        >
          {num + 1}
        </div>
      ))}
      <div
        onClick={() => currentPage < lastPage ? pageClick(currentPage + 1):''}
        className="bbai-p-2 bbai-justify-center bbai-min-w-9 bbai-text-center bbai-cursor-pointer bbai-flex bbai-items-center bbai-border-x bbai-border-[#D1D5DB]"
      >
        <svg width="6" height="12" viewBox="0 0 6 12" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M1.01026 11.3996C0.812902 11.3996 0.619993 11.3363 0.455913 11.2177C0.291833 11.0992 0.16395 10.9308 0.0884323 10.7337C0.0129142 10.5366 -0.00684831 10.3198 0.0316418 10.1106C0.0701319 9.90135 0.165147 9.70917 0.304676 9.55831L3.59106 6.00624L0.304676 2.45416C0.209357 2.35466 0.133328 2.23563 0.0810238 2.10403C0.0287201 1.97243 0.00118918 1.83088 3.76799e-05 1.68766C-0.00111382 1.54443 0.0241378 1.40239 0.0743177 1.26983C0.124498 1.13726 0.198602 1.01683 0.292306 0.915546C0.38601 0.814266 0.497437 0.734171 0.620087 0.679934C0.742736 0.625698 0.874151 0.598406 1.00666 0.59965C1.13918 0.600895 1.27013 0.630651 1.39189 0.687184C1.51365 0.743716 1.62377 0.825892 1.71584 0.928916L5.7078 5.24361C5.8949 5.4459 6 5.72021 6 6.00624C6 6.29226 5.8949 6.56658 5.7078 6.76886L1.71584 11.0836C1.52872 11.2859 1.27492 11.3995 1.01026 11.3996Z"
            fill="#6B7280"
          />
        </svg>
      </div>
    </div>
  );
}
