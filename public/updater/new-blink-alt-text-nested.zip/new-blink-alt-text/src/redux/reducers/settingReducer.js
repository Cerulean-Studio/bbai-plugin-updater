import { GET_SETTINGS, SAVE_SETTINGS } from '../actions/types';

const initialState = {
  isLoading: true,
  settings: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_SETTINGS:
      return {
        ...state,
        settings: action.payload,
        isLoading: false,
      };
    case SAVE_SETTINGS:
      return {
        ...state,
        settings: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
