import { GET_PROMPT, SAVE_PROMPT } from '../actions/types';

const initialState = {
  isLoading: true,
  prompt: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_PROMPT:
      return {
        ...state,
        prompt: action.payload,
        isLoading: false,
      };
    case SAVE_PROMPT:
      return {
        ...state,
        prompt: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
