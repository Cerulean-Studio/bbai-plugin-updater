import { GET_POSTS } from '../actions/types';

const initialState = {
  isLoading: true,
  posts: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_POSTS:
      return {
        ...state,
        posts: action.payload,
        isLoading: false,
      };

    default:
      return state;
  }
}
