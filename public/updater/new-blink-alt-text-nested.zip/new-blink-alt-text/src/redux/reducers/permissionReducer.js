import {  GET_USER_PERMISSION } from '../actions/types';

const initialState = {
  isLoading: true,
  permission: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case GET_USER_PERMISSION:
      return {
        ...state,
        isLoading: false,
        permission: action.payload,
      };
    default:
      return state;
  }
}
