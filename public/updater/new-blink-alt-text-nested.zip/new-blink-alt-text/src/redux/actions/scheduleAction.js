import { GET_SCHEDULE, SAVE_SCHEDULE } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;

export const fetchSchedule = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/schedule`, {
      headers: {
        Accept: 'application/json',
      },
    });
    // console.log('settings redux', response.data);
    dispatch({ type: GET_SCHEDULE, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const saveSchedule = async (data) => {
  try {
    const formData = new FormData();
    formData.append('scheduleActive', data.scheduleActive);
    formData.append('timezone', data.timezone);
    formData.append('startTime', data.startTime);
    formData.append('endTime', data.endTime);
    for (let i = 0; i < data.days.length; i++) {
      formData.append('days[]', data.days[i]);
    }
    const response = await axios.post(`${config.API_URL}/schedule`, formData, {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    dispatch({ type: SAVE_SCHEDULE, payload: response.data });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};

export const removeSettings = async (data) => {
  try {
    const response = await axios.post(`${config.API_URL}/deactivated-settings`, {
      headers: {
        Accept: 'application/json',
      },
    });
    return response;
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
