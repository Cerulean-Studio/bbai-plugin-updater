import { GET_LANGUAGES } from "./types";
import config from "../../config";
import axios from "axios";
import { store } from "../store";

const { dispatch } = store;

export const fecthLanguages = async () => {
	try {
		const response = await axios.get(`${config.API_URL}/languages`, {
			headers: {
				'Accept': 'application/json',
			},
		});
		// console.log('languages redux', response.data);
		dispatch({ type: GET_LANGUAGES, payload: response.data });
	} catch (error) {
		console.error("Error fetching data:", error);
	}
};

