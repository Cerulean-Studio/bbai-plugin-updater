import { GET_USER_PERMISSION } from './types';
import config from '../../config';
import axios from 'axios';
import { store } from '../store';

const { dispatch } = store;


export const fetchCurrentPermission = async () => {
  try {
    const response = await axios.get(`${config.API_URL}/current_user_permission`, {
      headers: {
        Accept: 'application/json',
        'X-WP-Nonce': config.NONCE,
      },
    });
    dispatch({ type: GET_USER_PERMISSION, payload: response.data });
  } catch (error) {
    console.error('Error fetching data:', error);
  }
};
