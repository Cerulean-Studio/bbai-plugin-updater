import React, { useState, useEffect, useMemo, useLayoutEffect } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import axios from 'axios';
import config from './config';
import Loader from './components/Loader';

const PrivateRoutes = () => {
  const [license, setLicense] = useState(null);
  const [loading, setLoading] = useState(true);

  const fectLicenses = async () => {
    try {
      const response = await axios.get(`${config.API_URL}/licenses`);
      setLicense(response.data);
      setLoading(false);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fectLicenses();
    console.log('license', license);
  }, []);

  if (loading) {
    return <Loader />;
  }

  return license?.license ? <Outlet /> : <Navigate to="/" />;
};

export default PrivateRoutes;
