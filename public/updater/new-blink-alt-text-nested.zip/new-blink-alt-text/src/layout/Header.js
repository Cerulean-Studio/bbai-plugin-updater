import banner from '../../assets/images/banner.png';

const Header = () => {
  return (
    <div className="bbai-h-24 bbai-mr-5 bbai-bg-[#1E2126] bbai-mt-5 bbai-rounded-lg bbai-overflow-hidden bbai-flex bbai-justify-between">
      <img src={banner} alt="Logo" className="bbai-h-full" />
      <div className="bbai-flex bbai-items-center bbai-justify-between bbai-pr-5 bbai-space-x-3">
        <a
          href="https://blinkbytes.ai/"
          className="bbai-p-5 bbai-text-sm bbai-text-white hover:bbai-text-white focus:bbai-text-white"
          target="_blank"
        >
          Documentation
        </a>
        <a
          href="https://blinkbytes.ai/"
          className="bbai-p-5 bbai-text-sm bbai-text-white hover:bbai-text-white focus:bbai-text-white"
          target="_blank"
        >
          Visit Website
        </a>
      </div>
    </div>
  );
};

export default Header;
