export let menuList = [
  { name: 'License Key', link: '/settings', dotColor: 'bbai-bg-red-500', pro: false },
  { name: 'AI Models', link: '/settings/ai-models', dotColor: 'bbai-bg-green-500', pro: true },
  { name: 'Prompt Settings', link: '/settings/prompt-settings', dotColor: 'bbai-bg-yellow-500', pro: true },
  // { name: 'Workflow scheduling', link: '/settings/workflow-scheduling', dotColor: 'bbai-bg-yellow-500', pro: true },
  { name: 'Limit AI Tokens', link: '/settings/limit-ai', dotColor: 'bbai-bg-yellow-500', pro: true },
  { name: 'Role-based Restrictions', link: '/settings/role-restrict', dotColor: 'bbai-bg-yellow-500', pro: true },
  { name: 'Seo and Utilities', link: '/settings/utilities', dotColor: 'bbai-bg-yellow-500', pro: true },
];
