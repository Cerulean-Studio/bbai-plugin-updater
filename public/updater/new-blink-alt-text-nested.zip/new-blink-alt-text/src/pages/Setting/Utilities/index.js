import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button, NotificationModal, Loader } from '../../../components';
import { useSelector } from 'react-redux';
import { fetchUtilities, saveUtilities } from '../../../redux/actions/utilitiesAction';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  // redux

  const utilities = useSelector((state) => state.utilities.utilities);
  const loading = useSelector((state) => state.utilities.isLoading);
  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Limit Updated',
    description: 'Succesfully updated API limit!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);

  // created
  useEffect(() => {
    fetchUtilities();
  }, []);

  // useEffects

  useEffect(() => {
    // wp option always return it's value with string, html input checkbox wont recognize the string 'false' as a falsy so i have to convert it to boolean false here
    let tmp = { ...utilities };
    console.log(tmp);
    // if (tmp.regenerateAltText == 'true') {
    //   tmp.regenerateAltText = true;
    // } else {
    //   tmp.regenerateAltText = false;
    // }
    tmp.regenerateAltText = tmp.regenerateAltText === 'true';
    tmp.sanitizeFileName = tmp.sanitizeFileName === 'true';
    // only wpattachmentpagesenabled is conditioned like this because we need to convert it to the native wordpress value
    tmp.wpAttachmentPagesEnabled = tmp.wpAttachmentPagesEnabled == 1;
    reset(tmp);
    console.log(tmp);
  }, [utilities, reset]);

  // methods

  const onSubmit = (data) => {
    // console.log(data)
    // return;
    saveUtilities(data).then((res) => {
      if (res.status === 200) {
        setSubmitLoading(false);
        setModalConfig({
          type: 'success',
          title: 'Limit Updated',
          description: 'Succesfully updated API limit!',
          btnText: 'Continue',
        });
        setIsOpen(true);
      }
    });
  };

  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };

  if (loading) {
    return <Loader />;
  }
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">SEO and Utilities</h1>
      <form autoComplete="off" onSubmit={handleSubmit(onSubmit)} className="bbai-w-full bbai-flex bbai-flex-col">
        <div id="regenerateAltText" className="bbai-w-fit">
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('regenerateAltText')}
              type="checkbox"
              id="regenerateAltText"
              name="regenerateAltText"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">
              Auto Regenerate Alt Text on Posts
            </span>
          </label>
        </div>
        <div id="sanitizeFileName" className="bbai-w-fit">
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('sanitizeFileName')}
              type="checkbox"
              id="sanitizeFileName"
              name="sanitizeFileName"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">Sanitize Filename</span>
          </label>
        </div>
        <div id="wpAttachmentPagesEnabled" className="bbai-w-fit">
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-5 bbai-cursor-pointer">
            <input
              {...register('wpAttachmentPagesEnabled')}
              type="checkbox"
              id="wpAttachmentPagesEnabled"
              name="wpAttachmentPagesEnabled"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">
              Disable the default image page
            </span>
          </label>
        </div>
        <Button size="sm" type="submit" customStyle="bbai-mt-2 bbai-w-4/12" loading={submitLoading}>
          Save Changes
        </Button>
      </form>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
    </div>
  );
}
