import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { TextInput, Button, Select, TextArea, Loader, NotificationModal, InputMultiple } from '../../../components';
import { savePrompt, fetchPrompt } from '../../../redux/actions/promptAction';
import { fetchSettings } from '../../../redux/actions/settingAction';
import { useSelector } from 'react-redux';
import { systemContent } from './data';
import axios from 'axios';
import config from '../../../config';
import FileInput from '../../../components/FileInput';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  // redux

  const prompt = useSelector((state) => state.prompt.prompt);
  const settings = useSelector((state) => state.setting.settings);
  const loading = useSelector((state) => state.prompt.isLoading);
  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [testApiLoading, setTestApiLoading] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [resultApi, setResultApi] = useState('');
  const [seoKeywords, setSeoKeywords] = useState(prompt.seoKeywords);
  const [base64SandBox, setBase64SandBox] = useState(null);
  const [prompOutputScore, setPrompOutputScore] = useState({ text: '', color: 'bbai-bg-transparent' });

  // Const Data
  const toneVoiceOptions = [
    { label: '', value: '' },
    { label: 'Informal Tone', value: 'Informal Tone' },
    { label: 'Professional Tone', value: 'Professional Tone' },
    { label: 'Casual Tone', value: 'Casual Tone' },
    { label: 'Authoritative Tone', value: 'Authoritative Tone' },
    { label: 'Friendly Tone', value: 'Friendly Tone' },
    { label: 'Persuasive Tone', value: 'Persuasive Tone' },
    { label: 'Sarcastic Tone', value: 'Sarcastic Tone' },
    { label: 'Humorous Tone', value: 'Humorous Tone' },
    { label: 'Inspirational Tone', value: 'Inspirational Tone' },
    { label: 'Empathetic Tone', value: 'Empathetic Tone' },
    { label: 'Serious Tone', value: 'Serious Tone' },
    { label: 'Optimistic Tone', value: 'Optimistic Tone' },
    { label: 'Cautious Tone', value: 'Cautious Tone' },
    { label: 'Excited Tone', value: 'Excited Tone' },
    { label: 'Confident Tone', value: 'Confident Tone' },
    { label: 'Doubtful Tone', value: 'Doubtful Tone' },
    { label: 'Respectful Tone', value: 'Respectful Tone' },
    { label: 'Conversational Tone', value: 'Conversational Tone' },
    { label: 'Direct Tone', value: 'Direct Tone' },
  ];

  // created

  useEffect(() => {
    fetchPrompt();
    fetchSettings();
  }, []);

  // useEffects

  useEffect(() => {
    reset(prompt);
  }, [prompt, reset]);

  // methods
  const handleGenerate = async () => {
    // check api key is set not or no
    if (settings.apiKey) {
      if (base64SandBox) {
        setTestApiLoading(true);
        try {
          axios
            .post(
              `${config.API_URL}/chat-completions`,
              {
                base64SandBox: base64SandBox,
                fieldName: 'altText',
              },
              {
                headers: {
                  'Content-Type': 'application/json',
                },
              }
            )
            .then((response) => {
              setTestApiLoading(false);
              if (response.status === 200 || response.status === 201) {
                const data = response.data.choices[0].message.content;
                setResultApi(data);
                setPrompOutputScore({ text: 'Calculating ...', color: 'bbai-bg-[#DEF7EC]' });
                axios
                  .post(
                    `${config.API_URL}/chat-completions`,
                    {
                      base64SandBox: base64SandBox,
                      fieldName: 'assesment',
                      altText: data,
                    },
                    {
                      headers: {
                        'Content-Type': 'application/json',
                      },
                    }
                  )
                  .then((response) => {
                    setTestApiLoading(false);
                    if (response.status === 200 || response.status === 201) {
                      const data = response.data.choices[0].message.content;
                      console.log(data);
                      if (data == 1) {
                        setPrompOutputScore({ text: 'Not Supported', color: 'bbai-bg-[#FDE8E8]' });
                      } else if (data == 2) {
                        setPrompOutputScore({ text: 'Mediocre', color: 'bbai-bg-[#FDF6B2]' });
                      } else if (data == 3) {
                        setPrompOutputScore({ text: 'Good', color: 'bbai-bg-[#DEF7EC]' });
                      } else {
                        setPrompOutputScore({ text: 'Unknown', color: 'bbai-bg-[#FDE8E8]' });
                      }
                    }
                  })
                  .catch(function (error) {
                    setTestApiLoading(false);
                    if (error.response.status === 429) {
                      setModalConfig({
                        type: 'error',
                        title: error.response.data.error,
                        description: error.response.data.message,
                        btnText: 'Continue',
                      });
                      setIsOpen(true);
                    } else {
                      // in this else, it handles all openai api's error response
                      setModalConfig({
                        type: 'error',
                        title: error.response.data.error.type,
                        description: error.response.data.error.message,
                        btnText: 'Continue',
                      });
                      setIsOpen(true);
                    }
                  });
              }
            })
            .catch(function (error) {
              setTestApiLoading(false);
              if (error.response.status === 429) {
                setModalConfig({
                  type: 'error',
                  title: error.response.data.error,
                  description: error.response.data.message,
                  btnText: 'Continue',
                });
                setIsOpen(true);
              } else {
                // in this else, it handles all openai api's error response
                setModalConfig({
                  type: 'error',
                  title: error.response.data.error.type,
                  description: error.response.data.error.message,
                  btnText: 'Continue',
                });
                setIsOpen(true);
              }
            });
        } catch (error) {
          console.error('Error fetching data:', error);
          setTestApiLoading(false);
        }
      } else {
        setModalConfig({
          type: 'error',
          title: 'Choose a Picture',
          description: 'You have to choose a picture before testing the API',
          btnText: 'Continue',
        });
        setIsOpen(true);
      }
    } else {
      setModalConfig({
        type: 'error',
        title: 'Provide API Key',
        description: 'You have to provide API Key on AI Models page before using sandbox',
        btnText: 'Continue',
      });
      setIsOpen(true);
    }
  };
  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };
  const onSubmit = (data) => {
    setSubmitLoading(true);
    let { audienceDesc, toneVoice, websiteTopic } = data;
    let tmp = {
      // if seoKeywords is not edited at all and useEffect[] not trigerred,
      // state seoKeywords will be undefined so i make a condition here to get prompt.seoKeywords
      // when state seoKeywords is undefined
      seoKeywords: seoKeywords || prompt.seoKeywords,
      audienceDesc,
      toneVoice,
      websiteTopic,
    };
    savePrompt(tmp).then((res) => {
      if (res.status === 200) {
        setSubmitLoading(false);
        setModalConfig({
          type: 'success',
          title: 'Prompt Saved',
          description: 'Succesfully updated Prompt!',
          btnText: 'Continue',
        });
        setIsOpen(true);
      }
    });
  };
  if (loading) {
    return <Loader />;
  }
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Prompt Setting</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6">
        <TextInput
          id="websiteTopic"
          name="websiteTopic"
          label="Website Topic"
          placeholder="Write text here.."
          required={false}
          register={register}
          errors={errors}
          customStyle="bbai-w-full bbai-max-w-full"
        />
        <Select
          id="toneVoice"
          name="toneVoice"
          label="Tone of Voice"
          placeholder="Select a language.."
          required={false}
          register={register}
          errors={errors}
          customStyle="bbai-w-full bbai-max-w-full"
          options={toneVoiceOptions}
        />
        <InputMultiple
          id="seoKeywords"
          name="seoKeywords"
          label="SEO Topic"
          required={false}
          register={register}
          errors={errors}
          customStyle="bbai-w-full bbai-max-w-full"
          initialValue={prompt.seoKeywords}
          onChange={setSeoKeywords}
        />
        <TextArea
          id="audienceDesc"
          name="audienceDesc"
          label="Audience Description"
          placeholder="Write text here.."
          required={false}
          register={register}
          errors={errors}
          customStyle="bbai-w-full bbai-max-w-full"
        />
        <div className="bbai-flex bbai-justify-end bbai-gap-2">
          <Button
            textColor="bbai-text-[#8950FC]"
            hoverColor="hover:bbai-bg-transparent"
            size="sm"
            customStyle="bbai-mt-5 bbai-bg-transparent bbai-border bbai-border-[#8950FC]"
          >
            Generate All
            <svg
              className="bbai-ml-2"
              width="16"
              height="17"
              viewBox="0 0 16 17"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M2 14.5L8.66667 7.83333M12 4.5L10.3333 6.16667"
                stroke="#8856F6"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M6.33333 1.83301L6.96353 3.53613L8.66667 4.16634L6.96353 4.79655L6.33333 6.49967L5.70312 4.79655L4 4.16634L5.70312 3.53613L6.33333 1.83301Z"
                stroke="#8856F6"
                stroke-linejoin="round"
              />
              <path
                d="M12.6668 7.16699L13.027 8.14019L14.0002 8.50033L13.027 8.86046L12.6668 9.83366L12.3067 8.86046L11.3335 8.50033L12.3067 8.14019L12.6668 7.16699Z"
                stroke="#8856F6"
                stroke-linejoin="round"
              />
            </svg>
          </Button>
          <Button size="sm" type="submit" customStyle="bbai-mt-5" loading={submitLoading}>
            Save Changes
          </Button>
        </div>
      </form>
      <div id="sandbox" className="w-full">
        <div className="bbai-font-semibold bbai-text-xl">Sandbox</div>
        <div className="bbai-text-xs ">
          Upload an image to test and fine-tune your settings. The output quality is automatically assessed using AI,
          but you can check the generated content and decide if it suits your needs.
        </div>
        <div className="bbai-w-full bbai-flex bbai-flex-wrap bbai-mt-11 bbai-justify-between bbai-gap-5 md:bbai-gap-0">
          <FileInput
            accept=".png,.jpeg,.gif,.webp,.jpg"
            updateBase64={(base64) => setBase64SandBox(base64)}
            customStyle="bbai-w-full md:bbai-w-[45%]"
          />
          <div className="bbai-flex bbai-flex-col bbai-w-full md:bbai-w-[45%]">
            <div className="bbai-font-medium bbai-text-sm bbai-mb-2 bbai-text-[#111928] bbai-flex bbai-items-center bbai-gap-2">
              <div>Prompt Output</div>
              {/* <div className="bbai-rounded-full bbai-px-2 bbai-py-1 bbai-bg-[#DEF7EC] bbai-font-bold bbai-text-[9px] bbai-text-[#03543F]">
                Good
              </div>
              <div className="bbai-rounded-full bbai-px-2 bbai-py-1 bbai-bg-[#FDF6B2] bbai-font-bold bbai-text-[9px] bbai-text-[#03543F]">
                Mediocre
              </div>
              <div className="bbai-rounded-full bbai-px-2 bbai-py-1 bbai-bg-[#FDE8E8] bbai-font-bold bbai-text-[9px] bbai-text-[#03543F]">
                Not Supported
              </div> */}
              <div
                className={`bbai-rounded-full bbai-px-2 bbai-py-1 bbai-bg-[#DEF7EC] bbai-font-bold bbai-text-[9px] bbai-text-[#03543F] ${prompOutputScore.color}`}
              >
                {prompOutputScore.text}
              </div>
            </div>
            <div className="bbai-flex-grow bbai-w-auto bbai-bg-[#F9FAFB] bbai-rounded-lg bbai-p-3 bbai-text-[#1F2A37] bbai-text-sm bbai-border bbai-border-[#D1D5DB]">
              {resultApi}
            </div>
          </div>
        </div>
        {/* if base64SandBox is null then disabled, else not disabled */}
        <Button size="sm" onClick={() => handleGenerate()} customStyle="bbai-mt-5" loading={testApiLoading}>
          Test API
        </Button>
      </div>
      <div className="bbai-w-full" id="Testing-Only"></div>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
    </div>
  );
}
