import React, { useEffect, useState } from 'react';
import { set, useForm } from 'react-hook-form';
import { Button, NotificationModal, Loader, ConfirmationModal } from '../../../components';
import { useSelector } from 'react-redux';
import { fetchRoleRestriction, saveRoleRestriction } from '../../../redux/actions/roleRestrictionAction';
import TableCustom from '../../../components/TableCustom';

export default function index() {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    getValues,
  } = useForm();
  // redux

  const permission = useSelector((state) => state.permission.permission);
  const roleRestriction = useSelector((state) => state.roleRestriction.roleRestriction);
  const loading = useSelector((state) => state.roleRestriction.isLoading);

  // States
  const [submitLoading, setSubmitLoading] = useState(false);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Role Restriction Updated',
    description: 'Succesfully updated Role Restriction!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  // const [individualAttribute, setIndividualAttribute] = useState(roleRestriction.individualAttribute);
  // const [bulkGeneration, setBulkGeneration] = useState(roleRestriction.bulkGeneration);
  // const [setting, setSetting] = useState(roleRestriction.setting);
  // const [optionRole, setOptionRole] = useState([{ value: '', label: '' }]);
  const [tableData, setTableData] = useState([]);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [ownChangedRole, setOwnChangedRole] = useState('');

  // Const Data
  const tableColumns = [
    { key: 'role', label: 'Roles' },
    { key: 'bat_individual_generate', label: 'Individual Attribute Generation', tooltip:'You cannot run individual attributes with just one click.' },
    { key: 'bat_bulk_generator', label: 'Bulk Generation', tooltip: 'You cannot run bulk generation just one click.' },
    { key: 'bat_setting', label: 'Settings', tooltip:'You don’t have access to the settings, but all other features are available to you.' },
    { key: 'bat_restricted', label: 'Full Restriction', tooltip: 'If full restriction applied, you cannot access any of the menus.' },
  ];
  // created
  useEffect(() => {
    fetchRoleRestriction();
  }, []);

  // useEffects

  useEffect(() => {
    // wp option always return it's value with string, html input checkbox wont recognize the string 'false' as a falsy so i have to convert it to boolean false here
    let tmp = { ...roleRestriction };
    if (tmp.featureRestriction == 'true') {
      tmp.featureRestriction = true;
    } else {
      tmp.featureRestriction = false;
    }
    // let tmpRole = tmp?.roles;
    // if (tmpRole) {
    //   let roleArray = Object.entries(tmpRole).map(([key, value]) => ({
    //     label: value,
    //     value: key,
    //   }));
    //   setOptionRole([{ label: '', value: '' }, ...roleArray]);
    // }
    // Stringify and then parsing needed to create a deep copy of roleWithCapabilities to avoid mutating the original data
    // original roleWithCapabilities is needed to compare data changes at submit
    setTableData(JSON.parse(JSON.stringify(tmp.roleWithCapabilities || [])));
    reset(tmp);
  }, [roleRestriction, reset]);

  // methods

  const handleCheckboxChange = (index, field) => {
    const newData = [...tableData];
    newData[index][field] = !newData[index][field];
    setTableData(newData);
  };

  const onSubmit = () => {
    setSubmitLoading(true);
    let tmp = {
      roleWithCapabilities: tableData || roleRestriction.tableData,
      'featureRestriction': getValues('featureRestriction'),
    };
    saveRoleRestriction(tmp).then((res) => {
      setSubmitLoading(false);
      if (res.status === 200) {
        setModalConfig({
          type: 'success',
          title: 'Role Restriction Updated',
          description: 'Succesfully updated Role Restriction!',
          btnText: 'Continue',
        });
        setIsOpen(true);
      }
    });
  };

  const validateChanges = (data) => {
    let needConfirm = false;
    for (let i = 0; i < tableData.length; i++) {
      const tableItem = tableData[i];
      const backendItem = roleRestriction.roleWithCapabilities[i];
      const ownRoleIncluded = permission.roles.includes(tableItem.role_key);

      // if (tableItem.bat_individual_attribute !== backendItem.bat_individual_attribute && ownRoleIncluded) {
      //   needConfirm = true;
      //   setOwnChangedRole(tableItem.role_key);
      //   break;
      // }

      // if (tableItem.bat_bulk_generate !== backendItem.bat_bulk_generate && ownRoleIncluded) {
      //   needConfirm = true;
      //   setOwnChangedRole(tableItem.role_key);
      //   break;
      // }

      if (tableItem.bat_setting !== backendItem.bat_setting && ownRoleIncluded) {
        needConfirm = true;
        setOwnChangedRole(tableItem.role_key);
        break;
      }

      if (tableItem.bat_restricted !== backendItem.bat_restricted && ownRoleIncluded) {
        needConfirm = true;
        setOwnChangedRole(tableItem.role_key);
        break;
      }
    }
    if (needConfirm) {
      setOpenConfirmation(true);
    } else {
      onSubmit();
    }
  };

  const handleModalClick = () => {
    if (modalConfig.type === 'success') {
      window.location.reload();
    } else {
      setIsOpen(false);
    }
  };

  if (loading) {
    return <Loader />;
  }
  return (
    <div className="bbai-flex bbai-flex-col bbai-items-start bbai-justify-start bbai-w-full bbai-h-full bbai-gap-6 bbai-px-4">
      <h1 className="bbai-text-2xl bbai-font-semibold bbai-text-gray-800">Role-based restrictions</h1>
      <form
        autoComplete="off"
        onSubmit={handleSubmit(validateChanges)}
        className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6"
      >
        <div id="featureRestriction" className="bbai-w-fit">
          <div className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900">
            Feature restrictions
          </div>
          <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-3 bbai-cursor-pointer">
            <input
              {...register('featureRestriction')}
              type="checkbox"
              id="featureRestriction"
              name="featureRestriction"
              className="bbai-sr-only bbai-peer"
            />
            <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full peer bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
            <span className="bbai-ml-3 bbai-text-sm bbai-font-medium bbai-text-gray-600">Enable</span>
          </label>
          <div className="bbai-text-xs bbai-text-[#6B7280]">
            When enabled, the role listed in each input can access the feature, making it available to them.
          </div>
        </div>

        {/* input field */}
        {/* <div>
          <InputMultiple
            id="individualAttribute"
            name="individualAttribute"
            label="Invidual attribute generation"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.individualAttribute}
            onChange={setIndividualAttribute}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You cannot run individual attributes with a single click.
          </div>
        </div>
        <div>
          <InputMultiple
            id="bulkGeneration"
            name="bulkGeneration"
            label="Bulk Generation"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.bulkGeneration}
            onChange={setBulkGeneration}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You can use features in bulk, but customization options like prompt editing, workflow scheduling, and others
            are not available.
          </div>
        </div>
        <div>
          <InputMultiple
            id="setting"
            name="setting"
            label="Settings"
            type="select"
            required={false}
            register={register}
            errors={errors}
            customStyle="bbai-w-full bbai-max-w-full"
            initialValue={roleRestriction.setting}
            onChange={setSetting}
            options={optionRole}
          />
          <div className="bbai-text-xs bbai-text-[#6B7280] bbai-mt-2">
            You don't have access to the settings, but you can access all other features.
          </div>
        </div> */}

        {/* tables */}
        <TableCustom evenSize={true} headerAlign="bbai-text-center" columns={tableColumns} data={tableData}>
          {tableData.map((row, index) => (
            <tr>
              <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                {row.role_name}
              </td>
              <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-center  bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                <input
                  id="checkbox-default"
                  type="checkbox"
                  checked={row.bat_individual_attribute}
                  disabled={row.role_key == 'administrator' || row.bat_restricted}
                  onChange={() => handleCheckboxChange(index, 'bat_individual_attribute')}
                  class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                />
              </td>
              <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-center  bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                <input
                  id="checkbox-default"
                  type="checkbox"
                  checked={row.bat_bulk_generate}
                  disabled={row.role_key == 'administrator' || row.bat_restricted}
                  onChange={() => handleCheckboxChange(index, 'bat_bulk_generate')}
                  class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                />
              </td>
              <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-center  bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                <input
                  id="checkbox-default"
                  type="checkbox"
                  checked={row.bat_setting}
                  disabled={row.role_key == 'administrator' || row.bat_restricted}
                  onChange={() => handleCheckboxChange(index, 'bat_setting')}
                  class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                />
              </td>
              <td class="bbai-p-5 bbai-whitespace-nowrap bbai-text-center  bbai-text-sm bbai-leading-6 bbai-font-medium bbai-text-gray-900">
                <div className="bbai-flex bbai-justify-center">
                  <label className="bbai-relative bbai-flex bbai-items-center bbai-mb-3 bbai-cursor-pointer">
                    <input
                      type="checkbox"
                      id="fullRestriction"
                      checked={row.bat_restricted}
                      name="fullRestriction"
                      className="bbai-sr-only bbai-peer"
                      disabled={row.role_key == 'administrator'}
                      onChange={() => handleCheckboxChange(index, 'bat_restricted')}
                    />
                    <div className="bbai-w-11 bbai-h-6 bbai-bg-gray-200 hover:bbai-bg-gray-300 peer-focus:bbai-outline-0 bbai-rounded-full peer bbai-transition-all bbai-ease-in-out bbai-duration-500 peer-checked:after:bbai-translate-x-full peer-checked:after:bbai-border-white after:bbai-content-[''] after:bbai-absolute after:bbai-top-[2px] after:bbai-left-[2px] after:bbai-bg-white after:bbai-border-gray-300 after:bbai-border after:bbai-rounded-full after:bbai-h-5 after:bbai-w-5 after:bbai-transition-all peer-checked:bbai-bg-indigo-600 hover:peer-checked:bbai-bg-indigo-700"></div>
                  </label>
                </div>
              </td>
            </tr>
          ))}
        </TableCustom>

        <Button size="sm" type="submit" customStyle="bbai-mt-2 bbai-w-4/12" loading={submitLoading}>
          Save Changes
        </Button>
      </form>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <ConfirmationModal
        isOpen={openConfirmation}
        title={'Confirm Settings Access Removal?'}
        description={`You are about to remove settings access for ${ownChangedRole}, including yourself. To reverse this change, you'll need assistance from an admin or another user with settings access. Are you sure you want to proceed?`}
        btnTextTrue={'Yes, Save'}
        handleClickTrue={onSubmit}
        btnTextFalse={'Cancel'}
        handleClickFalse={() => {
          setOpenConfirmation(false);
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      />
    </div>
  );
}
