import React from 'react';

export default function InfoCircleGenerator({ color, tooltipText, customStyle, customChild = false, children }) {
  return (
    <div className={`bbai-w-3 bbai-h-3 ${color} bbai-rounded-full tooltip`}>
      {customChild ? (
        <div className={`tooltiptext ${customStyle}`}>{children}</div>
      ) : (
        <div className={`tooltiptext ${customStyle}`}>{tooltipText}</div>
      )}
    </div>
  );
}
