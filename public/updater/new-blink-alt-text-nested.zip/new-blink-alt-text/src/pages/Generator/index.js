import React, { useEffect, useState } from 'react';
import ImageDetail from './components/ImageDetail';
import axios from 'axios';
import config from '../../config';
import { Button, ConfirmationModal, Loader, NotificationModal } from '../../components';
import Pagination from '../../components/Pagination';
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/react';
import { useSelector } from 'react-redux';
import HorizontalWidget from '../../components/HorizontalWidget';
import BlankModal from '../../components/BlankModal';
import { calculateCost } from '../../global';
import LoadingModal from '../../components/LoadingModal';
import TooltipBlank from '../../components/TooltipBlank';
import Tooltip from '../../components/Tooltip';

const GeneratorPage = () => {
  const permission = useSelector((state) => state.permission.permission);
  const license = useSelector((state) => state.license.license);
  // states
  const [posts, setPosts] = useState([]);
  const [sentImageId, setSentImageId] = useState(null);
  const [modalConfig, setModalConfig] = useState({
    type: 'success',
    title: 'Prompt Saved',
    description: 'Succesfully updated Prompt!',
    btnText: 'Continue',
  });
  const [isOpen, setIsOpen] = useState(false);
  const [lastPage, setLastPage] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageLoading, setPageLoading] = useState(false);
  const [filter, setFilter] = useState({
    altText: false,
    title: false,
    fileName: false,
    caption: false,
    description: false,
    slug: false,
  });

  const [bulkOngoing, setBulkOngoing] = useState(false);
  const [progressBulk, setProgressBulk] = useState({
    notDone: 0,
    done: 0,
  });
  const filterList = [
    { name: 'altText', label: 'Alt Text' },
    { name: 'title', label: 'Title' },
    { name: 'fileName', label: 'Filename' },
    { name: 'caption', label: 'Caption' },
    { name: 'description', label: 'Description' },
    { name: 'slug', label: 'Slug' },
  ];

  const generateTypeOptions = [
    { label: 'Generate All', value: 'all' },
    { label: 'Generate Partial', value: 'partial' },
  ];

  const [generateButtonLoading, setGenerateButtonLoading] = useState(false);
  const [openConfirmation, setOpenConfirmation] = useState(false);
  const [openConfirmationLoading, setOpenConfirmationLoading] = useState(false);
  const [loadingQueue, setLoadingQueue] = useState(true);
  // generate bulk states
  const [generateAllCount, setgenerateAllCount] = useState(0);
  const [generateLimit, setGenerateLimit] = useState(0);
  const [generateType, setGenerateType] = useState('all');
  const [generateCost, setGenerateCost] = useState(0);
  const [generateAllDetail, setGenerateAllDetail] = useState([]);
  const [triggerUpdateData, setTriggerUpdateData] = useState(false);
  // const [controllerCancelBulk, setControllerCancelBulk] = useState(null);

  // const [filter, setFilter] = useState([
  //   {name:'altText', label:'Alt Text', flag:false},
  //   {name:'title', label:'Title', flag:false},
  //   {name:'fileName', label:'Filename', flag:false},
  //   {name:'caption', label:'Caption', flag:false},
  //   {name:'description', label:'Description', flag:false},
  //   {name:'slug', label:'Slug', flag:false},
  // ])

  // created
  useEffect(() => {
    setPageLoading(true);
    axios
      .get(`${config.API_URL}/posts`, {
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': config.NONCE,
        },
      })
      .then((response) => {
        setPosts(response.data.data);
        setLastPage(response.data.pageNumber);
        setPageLoading(false);
      });
    axios.get(`${config.API_URL}/status-on-going-bulk-generate`, {}).then((response) => {
      setBulkOngoing(response.data.status);
      if (response.data.status == true) {
        axios.get(`${config.API_URL}/status-bulk-generate`, {}).then((response) => {
          setProgressBulk(response.data);
          if (response.data.notDone === 0) {
            clearInterval(window.intervalProgress);
            setBulkOngoing(false);
            setModalConfig({
              type: 'success',
              title: 'Bulk Generate Completed',
              description: 'Succesfully completed bulk generate! refresh the page to see the result.',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
      }
    });
    axios.get(`${config.API_URL}/get-failed-notify`, {}).then((response) => {
      if (response.data.status == true) {
        setModalConfig({
          type: 'error',
          title: 'Bulk Generate Interupted',
          description: response.data.message,
          btnText: 'Continue',
        });
        setIsOpen(true);
        axios.post(`${config.API_URL}/turn-off-failed-notify`);
      }
    });
  }, []);

  useEffect(() => {
    if (bulkOngoing) {
      window.intervalProgress = setInterval(() => {
        axios.get(`${config.API_URL}/status-bulk-generate`, {}).then((response) => {
          setProgressBulk(response.data);
          if (response.data.notDone === 0) {
            clearInterval(window.intervalProgress);
            setBulkOngoing(false);
            setModalConfig({
              type: 'success',
              title: 'Bulk Generate Completed',
              description: 'Succesfully completed bulk generate! refresh the page to see the result.',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
      }, 5000);

      return () => clearInterval(window.intervalProgress);
    }
  }, [bulkOngoing]);

  // watch

  useEffect(() => {
    if (generateType == 'all') {
      setGenerateCost('Calculating ... ');
      let cost = calculateCost(generateAllDetail.length, generateAllDetail);
      setGenerateCost(cost);
    } else {
      setGenerateCost('Calculating ... ');
      let cost = calculateCost(generateLimit, generateAllDetail);
      setGenerateCost(cost);
    }
  }, [generateAllCount, generateLimit, generateType]);

  // methods
  const openConfirmationModal = () => {
    setPageLoading(true);
    axios
      .post(
        `${config.API_URL}/generate-all-count`,
        { modeBulk: 'all' },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': config.NONCE, // Include the nonce here
          },
        }
      )
      .then((response) => {
        setOpenConfirmation(true);
        setGenerateAllDetail(response.data);
        setgenerateAllCount(response.data.length);
        setPageLoading(false);
      })
      .catch(function (error) {
        console.log(error);
        if (error.response.status === 403) {
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: error.response.data?.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
        } else {
          // in this else, it handles all openai api's error response
          setModalConfig({
            type: 'error',
            title: 'Error occured',
            description: 'Please try again later',
            btnText: 'Continue',
          });
          setIsOpen(true);
        }
        setPageLoading(false);
      });
  };
  const cancelBulkGenerate = () => {
    axios.post(`${config.API_URL}/stop-bulk-generate`, {}).then((response) => {
      console.log(response.data);
      setBulkOngoing(false);
    });
  };
  const updateFilter = (name, data) => {
    setPageLoading(true);
    let tmp = { ...filter };
    tmp[name] = data;
    setFilter(tmp);
    const filteredObject = Object.fromEntries(Object.entries(tmp).filter(([key, value]) => value === true));
    axios
      .get(`${config.API_URL}/posts`, {
        params: filteredObject,
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPosts(response.data.data);
        setLastPage(response.data.pageNumber);
        setPageLoading(false);
      });
  };

  const pageClick = (page) => {
    setPageLoading(true);
    const filteredObject = Object.fromEntries(Object.entries(filter).filter(([key, value]) => value === true));
    axios
      .get(`${config.API_URL}/posts`, {
        params: { page: page, ...filteredObject },
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        setPosts(response.data.data);
        setCurrentPage(page);
        setPageLoading(false);
      });
  };
  const handleModalClick = () => {
    setIsOpen(false);
  };

  const submitData = (payload) => {
    setPageLoading(true);
    axios
      .post(`${config.API_URL}/save-post`, payload, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        if (response.status === 200) {
          setModalConfig({
            type: 'success',
            title: response.data.title,
            description: response.data.message,
            btnText: 'Continue',
          });
          setIsOpen(true);
          // give signal to horizontalwidget that there's an update on the data
          setTriggerUpdateData(!triggerUpdateData);
        }
        setPageLoading(false);
      })
      .catch(function (error) {
        setModalConfig({
          type: 'error',
          title: error.response.data.error,
          description: error.response.data.message,
          btnText: 'Continue',
        });
        setIsOpen(true);

        setPageLoading(false);
      });
  };

  const generateAllImageInformation = () => {
    if (generateButtonLoading) return;
    setOpenConfirmation(false);
    if (!license?.license) {
      setModalConfig({
        type: 'error',
        title: 'No License',
        description: 'Please enter your license key to use this feature.',
        btnText: 'Continue',
      });
      setIsOpen(true);
    } else {
      setGenerateButtonLoading(true);
      setOpenConfirmationLoading(true);
      setLoadingQueue(true);
      // Create a new AbortController
      // const abortController = new AbortController();
      // setControllerCancelBulk(abortController);
      axios
        .post(
          `${config.API_URL}/bulk-generate`,
          {
            generateType,
            generateLimit,
            modeBulk: 'all',
          },
          {
            // .get(`${config.API_URL}/status-bulk-generate`, {}, {
            headers: {
              'Content-Type': 'application/json',
            },
            // signal: abortController.signal,
          }
        )
        .then((response) => {
          if (response.data.length >= 1) {
            setBulkOngoing(true);
            setProgressBulk({
              notDone: response.data.length,
              done: 0,
            });
            setLoadingQueue(false);
            axios
              .post(`${config.API_URL}/trigger-start-bulk-generate`)
              .then((response) => {})
              .catch((error) => {
                console.log(error.response.data.message);
                if (error.response.data.message) {
                  setModalConfig({
                    type: 'error',
                    title: 'Bulk Generate Interupted',
                    description: error.response.data.message,
                    btnText: 'Continue',
                  });
                  setIsOpen(true);
                  setOpenConfirmationLoading(false);
                  setLoadingQueue(false);
                  // send another api to turn off notify
                  // means user wont receive it again on next page load
                  axios.post(`${config.API_URL}/turn-off-failed-notify`);
                }
              });
          } else {
            setModalConfig({
              type: 'success',
              title: 'No Unoptimized Image',
              description: 'All images already optimized.',
              btnText: 'Continue',
            });
            setIsOpen(true);
            setOpenConfirmationLoading(false);
            setLoadingQueue(false);
          }
          setGenerateButtonLoading(false);
        })
        .catch(function (error) {
          console.log(error);
          setGenerateButtonLoading(false);
          if (error.response.status == 500) {
            console.log();
            setOpenConfirmationLoading(false);
            setModalConfig({
              type: 'error',
              title: 'Request Timeout',
              description:
                'You have inserted too many items in the queue, causing a timeout. Please reduce the number of items and try again.',
              btnText: 'Continue',
            });
            setIsOpen(true);
          }
        });
    }
  };

  const cancelQueue = () => {
    // if (controllerCancelBulk) {
    //   controllerCancelBulk.abort(); // Abort the request
    //   setControllerCancelBulk(null); // Reset the controller after cancellation
    // }
    axios.post(`${config.API_URL}/stop-queue-bulk-generate`, {}).then((response) => {
      setOpenConfirmationLoading(false);
    });
  };

  return (
    <div className="bbai-mr-5">
      <HorizontalWidget
        cancelBulkGenerate={cancelBulkGenerate}
        progressBulk={progressBulk}
        bulkOngoing={bulkOngoing}
        license={license}
        permission={permission}
        triggerUpdateData={triggerUpdateData}
        generateAllImageInformation={() => openConfirmationModal()}
      />
      <div className="bbai-p-6 bbai-w-full bbai-bg-[#F9FAFB] bbai-rounded-t-lg bbai-border-b bbai-border-b-[#E5E7EB] bbai-flex bbai-justify-between">
        <div className="bbai-flex bbai-items-center bbai-gap-4">
          {/* <div className="bbai-px-4 bbai-py-4 bbai-rounded-lg bbai-font-medium bbai-bg-[#ECE8FF] bbai-text-[#8856F6]">
            Made With Blink
          </div>
          <div className="bbai-px-4 bbai-py-4 bbai-rounded-lg bbai-font-medium bbai-text-[#6B7280]">
            Made Without Blink
          </div> */}
        </div>
        <div className="bbai-flex bbai-items-center bbai-gap-4">
          {permission.bulkGeneration && (
            <Button onClick={() => openConfirmationModal()} size="sm">
              <svg
                className="bbai-mr-2"
                width="20"
                height="20"
                viewBox="0 0 20 20"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g mask="url(#mask0_2263_47974)">
                  <path
                    d="M9.99935 16.5625C9.76324 16.5625 9.53407 16.5104 9.31185 16.4062C9.08963 16.3021 8.89518 16.1528 8.72852 15.9583L2.35352 8.33333C2.22852 8.18056 2.13477 8.01389 2.07227 7.83333C2.00977 7.65278 1.97852 7.46528 1.97852 7.27083C1.97852 7.14583 1.98893 7.01736 2.00977 6.88542C2.0306 6.75347 2.07574 6.63194 2.14518 6.52083L3.70768 3.41667C3.86046 3.13889 4.06532 2.91667 4.32227 2.75C4.57921 2.58333 4.8674 2.5 5.18685 2.5H14.8118C15.1313 2.5 15.4195 2.58333 15.6764 2.75C15.9334 2.91667 16.1382 3.13889 16.291 3.41667L17.8535 6.52083C17.923 6.63194 17.9681 6.75347 17.9889 6.88542C18.0098 7.01736 18.0202 7.14583 18.0202 7.27083C18.0202 7.46528 17.9889 7.65278 17.9264 7.83333C17.8639 8.01389 17.7702 8.18056 17.6452 8.33333L11.2702 15.9583C11.1035 16.1528 10.9091 16.3021 10.6868 16.4062C10.4646 16.5104 10.2355 16.5625 9.99935 16.5625ZM8.02018 6.66667H11.9785L10.7285 4.16667H9.27018L8.02018 6.66667ZM9.16602 13.8958V8.33333H4.54102L9.16602 13.8958ZM10.8327 13.8958L15.4577 8.33333H10.8327V13.8958ZM13.8327 6.66667H16.041L14.791 4.16667H12.5827L13.8327 6.66667ZM3.95768 6.66667H6.16602L7.41602 4.16667H5.20768L3.95768 6.66667Z"
                    fill="#EDEBFE"
                  />
                </g>
              </svg>
              Bulk All Text
            </Button>
          )}

          {/* <Button
            color="bbai-bg-transparent"
            hoverColor="bbai-bg-transparent"
            textColor="bbai-text-[#374151]"
            size="sm"
            customStyle="bbai-border bbai-border-[#D1D5DB]"
          >
            <svg
              className="bbai-mr-3"
              width="18"
              height="16"
              viewBox="0 0 18 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M7.9991 16C7.71577 16 7.47827 15.9042 7.2866 15.7125C7.09494 15.5208 6.9991 15.2833 6.9991 15V9L1.1991 1.6C0.949104 1.26667 0.911604 0.916667 1.0866 0.55C1.2616 0.183333 1.56577 0 1.9991 0H15.9991C16.4324 0 16.7366 0.183333 16.9116 0.55C17.0866 0.916667 17.0491 1.26667 16.7991 1.6L10.9991 9V15C10.9991 15.2833 10.9033 15.5208 10.7116 15.7125C10.5199 15.9042 10.2824 16 9.9991 16H7.9991ZM8.9991 8.3L13.9491 2H4.0491L8.9991 8.3Z"
                fill="#374151"
              />
            </svg>
            Filter by Missing Attribute
          </Button> */}
          {/* filter */}
          <Menu as="div" className="bbai-relative bbai-inline-block bbai-text-left">
            <div>
              <MenuButton className="bbai-inline-flex bbai-w-full bbai-justify-center bbai-gap-x-1.5 bbai-rounded-md bbai-bg-white bbai-px-3 bbai-py-2 bbai-text-sm bbai-font-semibold bbai-text-gray-900 bbai-shadow-sm bbai-ring-1 bbai-ring-inset bbai-ring-gray-300 hover:bbai-bg-gray-50">
                <svg
                  className="bbai-mr-3"
                  width="18"
                  height="16"
                  viewBox="0 0 18 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M7.9991 16C7.71577 16 7.47827 15.9042 7.2866 15.7125C7.09494 15.5208 6.9991 15.2833 6.9991 15V9L1.1991 1.6C0.949104 1.26667 0.911604 0.916667 1.0866 0.55C1.2616 0.183333 1.56577 0 1.9991 0H15.9991C16.4324 0 16.7366 0.183333 16.9116 0.55C17.0866 0.916667 17.0491 1.26667 16.7991 1.6L10.9991 9V15C10.9991 15.2833 10.9033 15.5208 10.7116 15.7125C10.5199 15.9042 10.2824 16 9.9991 16H7.9991ZM8.9991 8.3L13.9491 2H4.0491L8.9991 8.3Z"
                    fill="#374151"
                  />
                </svg>
                Filter by Unoptimized Attribute
              </MenuButton>
            </div>

            <MenuItems
              transition
              className="bbai-absolute bbai-right-0 bbai-z-10 bbai-mt-2 bbai-w-56 bbai-origin-top-right bbai-rounded-md bbai-bg-white bbai-shadow-lg bbai-ring-1 bbai-ring-black bbai-ring-opacity-5 bbai-transition bbai-focus:outline-none data-[closed]:bbai-scale-95 data-[closed]:bbai-transform data-[closed]:bbai-opacity-0 data-[enter]:bbai-duration-100 data-[leave]:bbai-duration-75 data-[enter]:bbai-ease-out data-[leave]:bbai-ease-in"
            >
              <div className="bbai-p-3">
                <div className="bbai-text-[#9CA3AF] bbai-text-xs">Detail</div>
                {filterList.map((data, idx) => (
                  <MenuItem>
                    <div onClick={(e) => e.preventDefault()} className="bbai-flex bbai-items-center">
                      <input
                        onClick={(e) => {
                          e.stopPropagation();
                          updateFilter(data.name, e.target.checked);
                        }}
                        id={`checkbox-default-${idx}`}
                        type="checkbox"
                        checked={filter[data['name']]}
                        class="bbai-w-5 bbai-h-5 bbai-appearance-none bbai-border bbai-cursor-pointer bbai-border-gray-300  bbai-rounded-md hover:bbai-border-indigo-500 hover:bbai-bg-indigo-100 checked:bbai-bg-no-repeat checked:bbai-bg-center checked:bbai-border-[#BCF0DA] checked:bbai-bg-indigo-100"
                      />
                      <div className="bbai-block bbai-px-4 bbai-py-2 bbai-text-sm bbai-text-gray-700 data-[focus]:bbai-bg-gray-100 data-[focus]:bbai-text-gray-900">
                        {data.label}
                      </div>
                    </div>
                  </MenuItem>
                ))}
              </div>
            </MenuItems>
          </Menu>
        </div>
      </div>
      <div className="bbai-p-6 bbai-bg-white">
        {posts.map((data, keyIndex) => (
          <ImageDetail
            currentImageId={sentImageId}
            updateImageId={(id) => setSentImageId(id)}
            submitData={submitData}
            keyIndex={keyIndex}
            initialData={data}
            license={license}
            permission={permission}
          />
        ))}
        {/* {posts.map((data, keyIndex)=> (
          <ImageDetail keyIndex={0} initialData={posts[4]} />
        ))} */}
        <div className="bbai-w-full bbai-flex bbai-justify-end">
          {lastPage && (
            <Pagination pageClick={pageClick} lastPage={lastPage} currentPage={currentPage} className="bbai-mt-3" />
          )}
        </div>
      </div>
      <NotificationModal
        {...modalConfig}
        isOpen={isOpen}
        handleClick={handleModalClick}
        handleClose={() => {
          setIsOpen(false);
        }}
      />
      <BlankModal
        isOpen={openConfirmation}
        handleClickFalse={() => {
          setOpenConfirmation(false);
        }}
        handleClose={() => {
          setOpenConfirmation(false);
        }}
      >
        <div className="bbai-text-xl bbai-font-bold bbai-text-center bbai-text-slate-900">Bulk Generate</div>
        <div className="bbai-text-sm">
          <div className="bbai-w-full">Unoptimized Images:</div>
          <div className="bbai-font-bold bbai-w-full">{generateAllCount} Images</div>
        </div>
        <div className="bbai-w-full bbai-flex bbai-flex-col bbai-gap-6">
          <div className="bbai-relative">
            <div>
              <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Queue Images</label>
              <div className="bbai-flex bbai-gap-6 bbai-mt-3">
                <div className="bbai-flex bbai-items-center">
                  <input
                    type="radio"
                    id="queueImages"
                    name="queueImages"
                    onClick={() => setGenerateType('all')}
                    checked={generateType === 'all'}
                  />
                  <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">All Images</label>
                  <Tooltip
                    customStyle={'bbai-w-40 bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3'}
                    tooltipText={'Generate all unoptimized pictures'}
                  />
                </div>
                <div className="bbai-flex bbai-items-center">
                  <input
                    type="radio"
                    id="queueImages2"
                    name="queueImages"
                    onClick={() => setGenerateType('partial')}
                    checked={generateType === 'partial'}
                  />
                  <label className="bbai-text-sm bbai-font-medium bbai-text-gray-900">Limit Images</label>
                  <Tooltip
                    customStyle={'bbai-w-40 bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3'}
                    tooltipText={'Generate a limited set of unoptimized pictures (e.g.,10)'}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {generateType == 'partial' ? (
          <>
            <div className="bbai-relative">
              <label
                id="generateLimit"
                className="bbai-flex bbai-items-center bbai-mb-2 bbai-text-sm bbai-font-medium bbai-text-gray-900"
              >
                Generate Limit
              </label>
              <input
                onChange={(e) => setGenerateLimit(e.target.value)}
                value={generateLimit}
                min={0}
                type="number"
                id="generateLimit"
                name="generateLimit"
                className={`bbai-block bbai-w-full bbai-px-4 bbai-py-2 bbai-text-base bbai-font-normal bbai-leading-relaxed bbai-text-gray-900 bbai-placeholder-gray-400 bbai-border bbai-border-gray-300 bbai-rounded-lg bbai-shadow-xs bbai-focus:outline-none`}
              />
            </div>
          </>
        ) : (
          <></>
        )}
        <div>
          <div>Estimate Cost:</div>
          <div className="bbai-font-bold">
            {/* ${generateCost.toFixed(4)} */}
            {/* round up 2 decimal places */}${Math.ceil((generateCost + Number.EPSILON) * 100) / 100}
            <TooltipBlank>
              <div className="bbai-w-80 -bbai-ml-40 bbai-rounded bbai-bg-[#4B5563] bbai-font-normal bbai-py-1 bbai-px-3">
                This is an estimated cost provided for guidance. For precise details on cost calculations, please visit
                the{' '}
                <a
                  className="bbai-text-white bbai-font-bold"
                  href="https://openai.com/api/pricing/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  OpenAI
                </a>{' '}
                documentation for the latest information.
              </div>
            </TooltipBlank>
          </div>
        </div>

        {/* <div className="bbai-text-gray-500 -bbai-mt-5 bbai-text-xs">
            cost refers to{' '}
            <a href="https://openai.com/api/pricing/" target="_blank" rel="noopener noreferrer">
              OpenAI Pricing List
            </a>
          </div> */}

        <div className="bbai-flex bbai-items-center bbai-justify-between bbai-w-full bbai-gap-4">
          <Button
            type="button"
            onClick={() => setOpenConfirmation(false)}
            customStyle="bbai-w-full bbai-border bbai-border-[#D1D5DB]"
            textColor="bbai-text-[#9CA3AF]"
            color={''}
            hoverColor={'hover:bbai-bg-slate-100'}
          >
            Cancel
          </Button>
          <Button type="button" onClick={generateAllImageInformation} customStyle="bbai-w-full">
            Generate
          </Button>
        </div>
      </BlankModal>
      <LoadingModal
        isOpen={openConfirmationLoading}
        title={'Media Queue in Progress'}
        description={
          "Your media is in line for generation! We're preparing your content and will have it ready soon, thanks for your patience!"
        }
        btnTextTrue={'Continue'}
        handleClickFalse={() => {
          setOpenConfirmationLoading(false);
          console.log('Cancel Deactivation');
        }}
        handleClose={() => {
          setOpenConfirmationLoading(false);
        }}
        handleCancel={() => {
          cancelQueue();
        }}
        loading={loadingQueue}
      />
      {pageLoading && <Loader />}
    </div>
  );
};

export default GeneratorPage;
