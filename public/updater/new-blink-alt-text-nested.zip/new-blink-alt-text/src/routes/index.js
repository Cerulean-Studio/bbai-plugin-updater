import { SettingPage, GeneratorPage, AiModel, PromptSetting, ProductActivation, RoleRestrict, LimitAi, WorkflowScheduling, Utilities } from '../pages';

const routes = [
  {
    path: '/settings',
    element: SettingPage,
    child: [
      {
        path: '',
        element: ProductActivation,
        pro:false
      },
      {
        path: 'ai-models',
        element: AiModel,
        pro:true
      },
      {
        path: 'prompt-settings',
        element: PromptSetting,
        pro:true
      },
      // {
      //   path: 'workflow-scheduling',
      //   element: WorkflowScheduling,
      //   pro:true
      // },
      {
        path: 'role-restrict',
        element: RoleRestrict,
        pro:true
      },
      {
        path: 'limit-ai',
        element: LimitAi,
        pro:true
      },
      {
        path: 'utilities',
        element: Utilities,
        pro:true
      },
    ],
  },
  {
    path: '/generator',
    element: GeneratorPage,
    child: [],
  },
];

export default routes;
