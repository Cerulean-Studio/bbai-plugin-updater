import { renderWithRedux } from '..';
import GenerateInBulkCustom from '../inject-components/GenerateInBulkCustom';
import CustomMediaModal from '../inject-components/CustomMediaModal';
import GenerateButton from '../inject-components/GenerateButton';
import HorizontalWidgetInject from '../inject-components/HorizontalWidgetInject';

export default function injectMediaomponents() {
  if (!wp.media) return;
  const mediaLibraryTitle = document.querySelector('div.wrap hr.wp-header-end');
  if (mediaLibraryTitle) {
    const horizontalWidgetContainer = document.createElement('div');
    mediaLibraryTitle.insertAdjacentElement('afterend', horizontalWidgetContainer);
    renderWithRedux(<HorizontalWidgetInject />, horizontalWidgetContainer);
  }

  const originalOpen = wp.media.view.Modal.prototype.open;
  wp.media.view.Modal.prototype.open = function () {
    originalOpen.apply(this, arguments);
    setTimeout(() => {
      const settingContainer = document.querySelector('div.attachment-info div.settings');
      if (settingContainer) {
        renderWithRedux(<CustomMediaModal />, settingContainer);
      }
    }, 100); // Adjust the timeout if necessary
  };
}
