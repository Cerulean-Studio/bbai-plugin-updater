import React, { useState, useEffect } from 'react';
import { renderWithRedux } from '..';
import CustomSectionEditPage from '../inject-components/CustomSectionEditPage';

export default function injectMediaEditComponents() {
  const isMediaEditPage = document.querySelector('a#sample-permalink');
  if (!isMediaEditPage) return;

  // Decorative
  const decorative = document.querySelector('p.attachment-alt-text');
  if (decorative) {
    const container = document.createElement('div');
    decorative.insertAdjacentElement('beforebegin', container);
    renderWithRedux(<CustomSectionEditPage />, container);
  }

}
