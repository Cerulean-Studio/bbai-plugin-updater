import App from './App';
import { render } from '@wordpress/element';

import './style.css';
import { Provider } from 'react-redux';

import { store } from './redux/store';

import { HashRouter } from 'react-router-dom';

import { createRoot } from 'react-dom/client';
import injectMediaEditComponents from './inject-logic/mediaEditInjections';
import injectMediaComponents from './inject-logic/mediaInjections';
import injectPageComponents from './inject-logic/pageInjections';
import DiagnoseWidget from './inject-components/DiagnoseWidget';
import injectAdminBar from './inject-logic/adminBarInjections';

// Checking if user is on bat admin page
const batAdminApp = document.getElementById('bat-admin-app');

// Checking if user is on dashboard wordpress
const dashboardWordpress = document.getElementById('bat-widget-diagnose');

// Create a wrapper component
const ReduxWrapper = ({ children }) => <Provider store={store}>{children}</Provider>;

// Helper function for rendering with Redux
export const renderWithRedux = (Component, container) => {
  const root = createRoot(container);
  root.render(<ReduxWrapper>{Component}</ReduxWrapper>);
};
 // Injecting admin bar
injectAdminBar();
if (batAdminApp) {
  render(
    <ReduxWrapper store={store}>
      <HashRouter>
        <App />
      </HashRouter>
    </ReduxWrapper>,
    batAdminApp
  );
  console.log('Rendered'); // Add this line
} else if (dashboardWordpress) {
  render(
    <ReduxWrapper store={store}>
      <DiagnoseWidget/>
    </ReduxWrapper>,
    dashboardWordpress
  );
} else {
  document.addEventListener('DOMContentLoaded', function () {
    // injecting media page
    injectMediaComponents();
    // injecting media edit page
    injectMediaEditComponents();
    // injecting page page
    injectPageComponents();
  });
}
