document.addEventListener('DOMContentLoaded', function () {
  const originalOpen = wp.media.view.Modal.prototype.open;
  wp.media.view.Modal.prototype.open = function () {
    originalOpen.apply(this, arguments);

    setTimeout(() => {
      // Find the "Title" label
      const useDateSetting = document.querySelector('span.setting[data-setting="title"]');
      if (useDateSetting) {
        // Create a new div element
        const customDiv = document.createElement('div');
        customDiv.classList.add('w-4', 'h-4', 'bg-red-500', 'rounded-full');

        // Insert the new div after the Alternative Text label
        useDateSetting.appendChild(customDiv);
      }
    }, 100); // Adjust the timeout if necessary
  };
});
