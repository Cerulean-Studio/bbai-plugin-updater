<?php

namespace BLINK_ALT_TEXT;

class RoleAndCapabilities
{
    // adding capabilities to role version 1
    // will receive a capability and array of roles, and grant the capability to the roles
    public function add($capability, $roles = [], $grantAll = false)
    {
        $system_roles = $this->get_system_role();
        foreach ($system_roles as $roleCode => $roleName) {
            $role = get_role($roleCode);
            if ($grantAll) {
                error_log($roleCode . ' Granted for ' . $capability);
                $role->add_cap($capability, true);
            } else {
                if (in_array($roleCode, $roles)) {
                    error_log($roleCode . ' Granted for ' . $capability);
                    $role->add_cap($capability, true);
                } else {
                    error_log($roleCode . ' Not Granted for ' . $capability);
                    $role->add_cap($capability, false);
                }
            }
        }
    }

    // adding capabilities to role version 2
    // will receive array of object which each row will have role key and capabilities
    public function addV2($roles)
    {
        foreach ($roles as $roleData) {
            $role = get_role($roleData->role_key);
            $role->add_cap('bat_individual_attribute', $roleData->bat_individual_attribute);
            $role->add_cap('bat_bulk_generate', $roleData->bat_bulk_generate);
            $role->add_cap('bat_setting', $roleData->bat_setting);
            $role->add_cap('bat_restricted', $roleData->bat_restricted);
        }
    }

    public function get_system_role()
    {
        global $wp_roles;
        $roles = $wp_roles->roles;
        error_log('Roles: ' . json_encode($roles));
        $role_names = array_map(function ($role) {
            return $role['name'];
        }, $roles);
        return $role_names;
    }

    function get_roles_with_capability($capability)
    {
        if (!function_exists('get_editable_roles')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }

        $roles_with_capability = [];
        $editable_roles = get_editable_roles();

        foreach ($editable_roles as $role_name => $role_info) {
            if (isset($role_info['capabilities'][$capability]) && $role_info['capabilities'][$capability] === true) {
                $roles_with_capability[] = $role_name;
            }
        }

        return $roles_with_capability;
    }

    function user_capable($capability)
    {
        $blink_alt_text_feature_restriction = get_option('blink_alt_text_feature_restriction');
        if ($blink_alt_text_feature_restriction == 'false') {
            return true;
        }
        return current_user_can($capability);
    }
    // function user_capable($capability)
    // {
    //     $allowed = false;
    //     $blink_alt_text_feature_restriction = get_option('blink_alt_text_feature_restriction');
    //     // if restriction is false, then all users are allowed
    //     if ($blink_alt_text_feature_restriction == 'false') {
    //         $allowed = true;
    //     }
    //     // if restriction is true, then check if user is allowed
    //     // if whole role doesnt have permission to a certain feature, then all role is allowed
    //     switch ($capability) {
    //         case 'bat_individual_attribute':
    //             $count = get_option('blink_alt_text_individual_attribute_count');
    //             if ($count == 0) {
    //                 $allowed =  true;
    //             } else {
    //                 $allowed = current_user_can($capability);
    //             }
    //             break;
    //         case 'bat_bulk_generate':
    //             $allowed = false;
    //             $count = get_option('blink_alt_text_bulk_generation_count');
    //             if ($count == 0) {
    //                 $allowed =  true;
    //             } else {
    //                 $allowed = current_user_can($capability);
    //             }
    //             break;
    //         case 'bat_setting':
    //             $allowed = false;
    //             $count = get_option('blink_alt_text_setting_count');
    //             if ($count == 0) {
    //                 $allowed =  true;
    //             } else {
    //                 $allowed = current_user_can($capability);
    //             }
    //             break;
    //         default:
    //             $allowed = current_user_can($capability);
    //             break;
    //     }
    //     return $allowed;
    // }

    function get_all_roles_with_capabilities()
    {
        if (!function_exists('get_editable_roles')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
        }
        // Get all editable roles
        $roles = get_editable_roles();

        // Capabilities to check
        $desired_capabilities = [
            'bat_individual_attribute',
            'bat_bulk_generate',
            'bat_setting',
            'bat_restricted',
        ];

        $roles_with_capabilities = [];

        foreach ($roles as $role_key => $role_info) {
            // Initialize the role object
            $role_data = [
                'role_key' => $role_key,
                'role_name' => $role_info['name'], // Display name of the role
            ];
    
            // Add capabilities to the role object
            foreach ($desired_capabilities as $capability) {
                $role_data[$capability] = !empty($role_info['capabilities'][$capability]);
            }
    
            $roles_with_capabilities[] = $role_data;
        }

        return $roles_with_capabilities;
    }
}
