<?php

namespace BLINK_ALT_TEXT;

class Deactivator
{
  public static function deactivate()
  {
    update_option('blink_alt_text_deactivated', true);
    wp_clear_scheduled_hook( 'custom_core_cron_hook' );
  }
}