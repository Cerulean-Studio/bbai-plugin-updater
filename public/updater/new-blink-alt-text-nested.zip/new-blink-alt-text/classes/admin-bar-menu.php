<?php

namespace BLINK_ALT_TEXT;

class AdminBarMenu
{
    public function add_custom_admin_bar_item($wp_admin_bar)
    {

        // Check if the user is viewing a single post or page and is logged in as an admin
        if (!is_user_logged_in() || !current_user_can('bat_individual_attribute') || !(is_single() || is_page())) {
            return;
        }
        $activated = get_option('blink_alt_text_license_activated') == 1 ? true : false;

        global $wpdb;
        // Log the current post or page ID
        $current_post_id = get_the_ID();
        error_log('Current Post/Page ID: ' . $current_post_id);

        // Get the post content
        $post_content = get_post_field('post_content', $current_post_id);

        preg_match_all('/wp-image-([0-9]+)/', $post_content, $matches);

        // Extract image IDs and alt texts
        $image_ids = array_values(array_unique($matches[1]));
        error_log('Image IDs: ' . json_encode($image_ids));
        error_log('Not Unique Image IDs: ' . json_encode($matches[1]));
        $alt_texts = $this->getAltText($post_content);


        // Loop through each image ID and log the ID, filename, and alt text
        //  this is if checking to library right away
        //  foreach ($image_ids as $image_id) {
        //      $filename = wp_basename(get_attached_file($image_id));
        //      $alt_text = get_post_meta($image_id, '_wp_attachment_image_alt', true);

        //      error_log('Attachment ID: ' . $image_id);
        //      error_log('Filename: ' . $filename);
        //      error_log('Alt Text: ' . $alt_text);
        //  }
        $unoptimized_alt_text = 0;
        $unoptimized_file_name = 0;
        $unoptimized_image = 0;
        // this is if check checked on custom table
        $dataToUpdate = array();
        $not_match_count = 0;
        $media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
        $generator_route = new \BLINK_ALT_TEXT\GeneratorRoute();
        foreach ($image_ids as $index => $image_id) {
            // Query the custom table for fileNameAi and altTextAi
            // $result = $wpdb->get_row($wpdb->prepare(
            //     "SELECT fileNameAi, altTextAi, slugAi, captionAi, titleAi, descriptionAi, fileNameStatus, altTextStatus, decorative, altTextBlink FROM $media_detail WHERE post_id = %d",
            //     $image_id
            // ));
            $result = $wpdb->get_row($wpdb->prepare(
                "SELECT p.ID, p.post_title, p.post_name, p.post_excerpt, p.post_content,
                md.fileNameAi, md.altTextAi, md.slugAi, md.captionAi, md.titleAi, md.descriptionAi, md.fileNameStatus, md.altTextStatus, md.decorative, md.altTextBlink
                FROM {$wpdb->posts} p
                LEFT JOIN {$media_detail} md ON p.ID = md.post_id
                WHERE p.post_type = 'attachment'
                AND p.post_status = 'inherit'
                AND ID = %d",
                $image_id
            ));

            error_log('result on getting media_detail' . json_encode($result));
            if ($result) {
                $filename_ai = $result->fileNameAi;
                $alt_text_ai = $result->altTextAi;
                $slug_ai = $result->slugAi;
                $caption_ai = $result->captionAi;
                $title_ai = $result->titleAi;
                $description_ai = $result->descriptionAi;
                $filename_status = $result->fileNameStatus;
                $alt_text_status = $result->altTextStatus;
                $decorative = $result->decorative;
                $unoptimizedAltTextCondition = $alt_text_status < 2 && $decorative == 0;
                if ($filename_status < 2 || $unoptimizedAltTextCondition || $slug_ai == 0 || $caption_ai == 0 || $title_ai == 0 || $description_ai == 0) {
                    $dataToUpdate[$index]['post_id'] = $image_id;
                }
                if ($filename_status < 2 || $unoptimizedAltTextCondition) {
                    $unoptimized_image++;
                }
                if ($filename_status < 2) {
                    $unoptimized_file_name++;
                    $dataToUpdate[$index]['fileName'] = true;
                    $url = wp_get_original_image_url($image_id);
                    $file_name = $generator_route->fileNameExtract($url);
                    if ($file_name != '') {
                        $dataToUpdate[$index]['generateCriticalModalShow'] = true;
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                $altText = $this->conditional_alt_text($result->altTextBlink, $image_id, $decorative);
                if ($unoptimizedAltTextCondition) {
                    $unoptimized_alt_text++;
                    $dataToUpdate[$index]['altText'] = true;
                    // $dataToUpdate[$index]['altTextBlink'] = $result->altTextBlink;
                    if ($altText != '') {
                        $dataToUpdate[$index]['generateAltTextModalShow'] = true;
                        $dataToUpdate[$index]['generateCriticalModalShow'] = true;
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                // check missmatch alttext
                
                foreach ($alt_texts as $index => $alt_text) {
                    if ($alt_text['id'] == $image_id) {
                        if ($alt_text['altText'] != $altText) {
                            $alt_texts[$index]['notMatch'] = true;
                            $not_match_count++;
                        }
                    }
                }

                if ($slug_ai == 0) {
                    $dataToUpdate[$index]['slug'] = true;
                    if ($result->post_name != '') {
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                if ($caption_ai == 0) {
                    $dataToUpdate[$index]['caption'] = true;
                    if ($result->post_excerpt != '') {
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                if ($title_ai == 0) {
                    $dataToUpdate[$index]['title'] = true;
                    if ($result->post_title != '') {
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                if ($description_ai == 0) {
                    $dataToUpdate[$index]['description'] = true;
                    if ($result->post_content != '') {
                        $dataToUpdate[$index]['generateAllAttributesModalShow'] = true;
                    }
                }
                error_log('Alt Text Status: ' . $unoptimizedAltTextCondition);
            } else {
                error_log('No AI data found for Attachment ID: ' . $image_id);
            }
        }
        error_log('Unoptimized Alt Text: ' . $unoptimized_alt_text);
        error_log('Unoptimized File Name: ' . $unoptimized_file_name);
        error_log('Unoptimized Image: ' . $unoptimized_image);
        $dataToUpdate = json_encode($dataToUpdate);

        $iconBlink = '
                <div style="width: 20px; height: 20px; background: white; border-radius: 2.5px; display: flex; align-items: center; justify-content: center;">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="20" height="20" rx="2.5" fill="white"/>
                    <path d="M16.0864 8.4375C16.0864 11.7982 13.3626 14.522 10.0019 14.522C6.64128 14.522 3.91602 11.7982 3.91602 8.4375H7.16603C7.16603 10.0042 8.43524 11.2734 10.0019 11.2734C11.5687 11.2734 12.8379 10.0042 12.8379 8.4375H16.0864Z" fill="#1E2126"/>
                    <path d="M12.8378 8.44528H7.16602C7.16602 6.87858 8.43522 5.60938 10.0019 5.60938C11.5686 5.60938 12.8378 6.87858 12.8378 8.44528Z" fill="#1E2126"/>
                    </svg>
                    </div>
                    <div style="display:flex; align-items:center; justify-content:center; background-color: #F8B4B4; width:20px; height:20px; border-radius:999px; color: #111928; text-align: center;">' . $unoptimized_image . '</div>
                    ';
        $fixAllImagesAltTextSvg = '<svg width="13" height="12" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1.33333 12C1.14444 12 0.986111 11.9361 0.858333 11.8083C0.730556 11.6806 0.666667 11.5222 0.666667 11.3333V9.71667C0.666667 9.53889 0.7 9.36944 0.766667 9.20833C0.833333 9.04722 0.927778 8.90556 1.05 8.78333L9.45 0.4C9.58333 0.266667 9.73333 0.166667 9.9 0.1C10.0667 0.0333333 10.2333 0 10.4 0C10.5778 0 10.7472 0.0333333 10.9083 0.1C11.0694 0.166667 11.2111 0.266667 11.3333 0.4L12.2667 1.33333C12.4 1.45556 12.5 1.59722 12.5667 1.75833C12.6333 1.91944 12.6667 2.08889 12.6667 2.26667C12.6667 2.43333 12.6333 2.6 12.5667 2.76667C12.5 2.93333 12.4 3.08333 12.2667 3.21667L3.88333 11.6167C3.76111 11.7389 3.61944 11.8333 3.45833 11.9C3.29722 11.9667 3.12778 12 2.95 12H1.33333ZM2 10.6667H2.93333L9.48333 4.13333L9.01667 3.65L8.53333 3.18333L2 9.73333V10.6667ZM9.01667 3.65L8.53333 3.18333L9.48333 4.13333L9.01667 3.65ZM7.33333 12C8.15556 12 8.91667 11.7944 9.61667 11.3833C10.3167 10.9722 10.6667 10.4 10.6667 9.66667C10.6667 9.31111 10.5778 9.00278 10.4 8.74167C10.2222 8.48056 9.98889 8.23889 9.7 8.01667C9.54445 7.90556 9.37778 7.85 9.2 7.85C9.02222 7.85 8.87222 7.91667 8.75 8.05C8.62778 8.18333 8.56667 8.34722 8.56667 8.54167C8.56667 8.73611 8.64444 8.88889 8.8 9C8.95556 9.12222 9.08333 9.23333 9.18333 9.33333C9.28333 9.43333 9.33333 9.54445 9.33333 9.66667C9.33333 9.92222 9.13056 10.1528 8.725 10.3583C8.31944 10.5639 7.85556 10.6667 7.33333 10.6667C7.14444 10.6667 6.98611 10.7306 6.85833 10.8583C6.73056 10.9861 6.66667 11.1444 6.66667 11.3333C6.66667 11.5222 6.73056 11.6806 6.85833 11.8083C6.98611 11.9361 7.14444 12 7.33333 12ZM4 2C4 2.15556 3.90278 2.29722 3.70833 2.425C3.51389 2.55278 3.06667 2.77778 2.36667 3.1C1.47778 3.48889 0.861111 3.84167 0.516667 4.15833C0.172222 4.475 0 4.86667 0 5.33333C0 5.62222 0.0666667 5.87778 0.2 6.1C0.333333 6.32222 0.505556 6.51667 0.716667 6.68333C0.861111 6.80556 1.02222 6.85833 1.2 6.84167C1.37778 6.825 1.52778 6.74444 1.65 6.6C1.77222 6.45556 1.82778 6.29444 1.81667 6.11667C1.80556 5.93889 1.72778 5.78889 1.58333 5.66667C1.50556 5.61111 1.44444 5.55556 1.4 5.5C1.35556 5.44444 1.33333 5.38889 1.33333 5.33333C1.33333 5.2 1.43333 5.06667 1.63333 4.93333C1.83333 4.8 2.25556 4.59444 2.9 4.31667C3.87778 3.89444 4.52778 3.51111 4.85 3.16667C5.17222 2.82222 5.33333 2.43333 5.33333 2C5.33333 1.38889 5.08889 0.902778 4.6 0.541667C4.11111 0.180556 3.46667 0 2.66667 0C2.16667 0 1.71944 0.0888889 1.325 0.266667C0.930556 0.444444 0.627778 0.661111 0.416667 0.916667C0.294444 1.06111 0.244444 1.22222 0.266667 1.4C0.288889 1.57778 0.372222 1.72222 0.516667 1.83333C0.661111 1.95556 0.822222 2.00556 1 1.98333C1.17778 1.96111 1.32778 1.88889 1.45 1.76667C1.60556 1.61111 1.77778 1.5 1.96667 1.43333C2.15556 1.36667 2.38889 1.33333 2.66667 1.33333C3.12222 1.33333 3.45833 1.4 3.675 1.53333C3.89167 1.66667 4 1.82222 4 2Z" fill="white"/>
            </svg>
            ';
        $fixAllImagesAttributesSvg = '<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12.0537 0H5.1887C4.5212 0 3.89286 0.2496 3.4212 0.7032L1.06453 2.9656C0.592031 3.4184 0.332031 4.0216 0.332031 4.6632V14.4C0.332031 15.2824 1.05453 16 1.9437 16H12.0545C12.9429 16 13.6654 15.2824 13.6654 14.4V1.6C13.6654 0.7176 12.9429 0 12.0537 0ZM4.4987 1.9312V4H2.3437L4.4987 1.9312ZM11.9987 14.4H1.9987V5.6H4.4987C5.41786 5.6 6.16536 4.8824 6.16536 4V1.6H11.9987V14.4Z" fill="white"/>
            <path d="M4.99703 8.0312L2.79953 12.456C2.6762 12.704 2.6937 12.9952 2.84703 13.2272C2.99953 13.4592 3.2662 13.6 3.5512 13.6H10.2179C10.5112 13.6 10.782 13.4528 10.932 13.212C11.082 12.9712 11.0904 12.672 10.9529 12.424L9.4262 9.6736C9.2812 9.4136 9.00037 9.2512 8.6937 9.2496C8.3462 9.248 8.10453 9.4088 7.95786 9.6672L7.50703 10.4648L6.52203 8.08C6.40037 7.784 6.10703 7.5856 5.77536 7.5752C5.4237 7.5664 5.13953 7.744 4.99703 8.0312Z" fill="white"/>
            <path d="M9.08203 7.2C9.77239 7.2 10.332 6.66274 10.332 6C10.332 5.33726 9.77239 4.8 9.08203 4.8C8.39168 4.8 7.83203 5.33726 7.83203 6C7.83203 6.66274 8.39168 7.2 9.08203 7.2Z" fill="white"/>
            </svg>
            ';
        $fixAllCriticalAttributesSvg = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15.6368 2.45535L13.3744 0.230687C13.0616 -0.0768957 12.556 -0.0768957 12.2432 0.230687L0.3632 11.9125C0.0503999 12.2201 0.0503999 12.7173 0.3632 13.0249L2.6256 15.2495C2.7816 15.4029 2.9864 15.48 3.1912 15.48C3.396 15.48 3.6008 15.4029 3.7568 15.2495L15.6368 3.56768C15.9496 3.26089 15.9496 2.76293 15.6368 2.45535ZM3.1912 13.581L2.06 12.4687L10.0432 4.61866L11.1744 5.73099L3.1912 13.581ZM12.3064 4.61787L11.1752 3.50554L12.8088 1.89919L13.94 3.01152L12.3064 4.61787Z" fill="white"/>
            <path d="M12.8 12.8534H12V12.0667C12 11.6317 11.6424 11.2801 11.2 11.2801C10.7576 11.2801 10.4 11.6317 10.4 12.0667V12.8534H9.6C9.1576 12.8534 8.8 13.205 8.8 13.64C8.8 14.0751 9.1576 14.4267 9.6 14.4267H10.4V15.2133C10.4 15.6484 10.7576 16 11.2 16C11.6424 16 12 15.6484 12 15.2133V14.4267H12.8C13.2424 14.4267 13.6 14.0751 13.6 13.64C13.6 13.205 13.2424 12.8534 12.8 12.8534Z" fill="white"/>
            <path d="M0.8 6.56012H1.6V7.34678C1.6 7.7818 1.9576 8.13344 2.4 8.13344C2.8424 8.13344 3.2 7.7818 3.2 7.34678V6.56012H4C4.4424 6.56012 4.8 6.20849 4.8 5.77347C4.8 5.33845 4.4424 4.98681 4 4.98681H3.2V4.20016C3.2 3.76513 2.8424 3.4135 2.4 3.4135C1.9576 3.4135 1.6 3.76513 1.6 4.20016V4.98681H0.8C0.3576 4.98681 0 5.33845 0 5.77347C0 6.20849 0.3576 6.56012 0.8 6.56012Z" fill="white"/>
            <path d="M13.6 8.92009H12V10.4934H13.6V8.92009Z" fill="white"/>
            <path d="M8.8 0.266873H7.2V1.84019H8.8V0.266873Z" fill="white"/>
            <path d="M6.4 1.84019H4.8V3.4135H6.4V1.84019Z" fill="white"/>
            <path d="M4 0.266873H2.4V1.84019H4V0.266873Z" fill="white"/>
            <path d="M16 6.56012H14.4V8.13344H16V6.56012Z" fill="white"/>
            <path d="M16 10.4934H14.4V12.0667H16V10.4934Z" fill="white"/>
            </svg>
            ';
        // Add a parent item
        $args = array(
            'id'    => 'bat_output_languages',
            'title' => '<div id="bat_parrent_menu_bar" style="padding-top: 6px; display: flex; align-items: center; justify-content: center; gap: 8px;" data-to-update=\'' . $dataToUpdate . '\'>' . $iconBlink . '</div>',
            'href'  => '#',
            'meta'  => array(
                'class' => 'bat_menubar_parrent',
                'title' => 'Custom Item Tooltip',
            )
        );
        $wp_admin_bar->add_node($args);

        error_log('alt_text after checking mismatch' . json_encode($alt_texts));

        // Add a child item
        if ($activated) {
            $child_items = array(
                array(
                    'id'     => 'fix_all_images_alt_text',
                    'title'  => $fixAllImagesAltTextSvg . ' Fix All Images Alt Text',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class',
                        'title' => 'Custom Child Item Tooltip'
                    )
                ),
                array(
                    'id'     => 'fix_all_images_attributes',
                    'title'  => $fixAllImagesAttributesSvg . ' Fix All Images Attributes',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class',
                    )
                ),
                array(
                    'id'     => 'fix_all_critical_attributes',
                    'title'  => $fixAllCriticalAttributesSvg . ' Fix All Critical Attributes',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'html'  => '<div style="border-top: 1px solid #374151; margin: 5px 0;"></div>',
                        'class' => 'custom-child-item-class',
                    )
                ),
                array(
                    'id'     => 'unoptimized_alt_text',
                    'title'  => 'Unoptimized Alt Text (' . $unoptimized_alt_text . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
                array(
                    'id'     => 'unoptimized_file_name',
                    'title'  => 'Unoptimized Filename (' . $unoptimized_file_name . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
                array(
                    'id'     => 'not_match_count',
                    'title'  => 'Custom Alt Text (' . $not_match_count . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
            );
        } else {
            $admin_url = admin_url('admin.php?page=blink-alt-text#/settings');
            $button = '
            <div style="background-color:#7E3AF2; color:white; border-radius:5px; cursor:pointer; display:flex; align-items:center; justify-content:center;">
                <div>Upgrade</div>
            </div>
            ';
            $child_items = array(
                array(
                    'id'     => 'unoptimized_alt_text',
                    'title'  => 'Unoptimized Alt Text (' . $unoptimized_alt_text . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
                array(
                    'id'     => 'unoptimized_file_name',
                    'title'  => 'Unoptimized Filename (' . $unoptimized_file_name . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'html'  => '<div style="border-top: 1px solid #374151; margin: 5px 0;"></div>',
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
                array(
                    'id'     => 'upgrade',
                    'title'  => $button,
                    'parent' => 'bat_output_languages',
                    'href'   => $admin_url,
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item',
                        'html'  => '<div style="margin: 5px 0;"></div>',
                    )
                ),
                array(
                    'id'     => 'not_match_count',
                    'title'  => 'Custom Alt Text (' . $not_match_count . ')',
                    'parent' => 'bat_output_languages',
                    'href'   => '#',
                    'meta'   => array(
                        'class' => 'custom-child-item-class additional-child-item',
                        'title' => 'Additional Child Item'
                    )
                ),
            );
        }
        // Add child items to the admin bar
        foreach ($child_items as $child_args) {
            $wp_admin_bar->add_node($child_args);
        }
    }

    public function getAltText($htmlString)
    {
        // Load the HTML string into DOMDocument
        $dom = new \DOMDocument();
        libxml_use_internal_errors(true); // Suppress errors due to invalid HTML
        $dom->loadHTML($htmlString, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        // Get all <img> elements
        $images = $dom->getElementsByTagName('img');
        $data = array();
        foreach ($images as $img) {
            $class = $img->getAttribute('class');
            if (preg_match('/wp-image-(\d+)/', $class, $matches)) {
                $imageId = $matches[1];
                $altText = $img->getAttribute('alt');
                $data[] = array(
                    'id' => $imageId,
                    'altText' => $altText,
                    'notMatch' => false
                );
            }
        }
        // Save the updated HTML and return it
        return $data;
    }

    public function conditional_alt_text($altTextBlink, $id, $decorative = false)
    {
        $altTextBlink = $altTextBlink;
        $altTextWP = get_post_meta($id, '_wp_attachment_image_alt', true);
        if (!$altTextBlink) {
            // condition 1: alttext blink is null then just use alttext from wp
            $altText = $altTextWP;
        } else if ($altTextBlink != $altTextWP && ($altTextWP != null || $altTextWP != '')) {
            // condition 2 : alttext blink is not same with alttextwp (but alttext wp does exist, might be edited from native page)
            $altText = $altTextWP;
        } else if ($altTextWP != null || $altTextWP != '') {
            // if alttext wp is null, use alttextblink (it might be caused by blink's decorative function)
            $altText = $altTextBlink;
        } else {
            $altText = $altTextBlink;
        }
        if($decorative){
            $altText = '';
        }
        return $altText;
    }
}
