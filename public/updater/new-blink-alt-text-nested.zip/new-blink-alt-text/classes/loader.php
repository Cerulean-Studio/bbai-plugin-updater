<?php

namespace BLINK_ALT_TEXT;

class Loader
{

  public function __construct()
  {
    add_action('admin_menu', array($this, 'bat_init_menu_admin'));
    add_action('admin_bar_menu', array($this, 'add_custom_admin_bar_item'), 999);
    add_action('admin_enqueue_scripts', array($this, 'bat_enqueue_plugin_admin_styles')); //load styles
    add_action('wp_dashboard_setup', array($this, 'my_custom_dashboard_widget')); //custom widget 
    // add_action('admin_enqueue_scripts', array($this, 'my_custom_media_script'));
  }


  public function bat_init_menu_admin()
  {
    global $submenu;

    $slug          = BLINK_ALT_TEXT_SLUG;
    $menu_position = 50;
    $capability_settings    = 'bat_setting';
    $capability    = 'read';
    $logo_icon     = BLINK_ALT_TEXT_URL . 'assets/images/blink-alt-text-logo-white-bg.svg';

    if (!current_user_can('bat_restricted')) {
      add_menu_page(esc_attr__('Blink Alt Text', 'blink-alt-text'), esc_attr__('Blink Alt Text', 'blink-alt-text'), $capability, $slug, [$this, 'bat_render_init_menu_admin'], $logo_icon, $menu_position);
      // if feature restriction is false, settings will show to all users with read capability
      $blink_alt_text_feature_restriction = get_option('blink_alt_text_feature_restriction');
      if ($blink_alt_text_feature_restriction == 'false') {
        if (current_user_can($capability)) {
          $submenu[$slug][] = [esc_attr__('Settings', 'blink-alt-text'), $capability, 'admin.php?page=' . $slug . '#/settings'];
        }
      } else {
        if (current_user_can($capability_settings)) {
          $submenu[$slug][] = [esc_attr__('Settings', 'blink-alt-text'), $capability_settings, 'admin.php?page=' . $slug . '#/settings'];
        }
      }

      $submenu[$slug][] = [esc_attr__('Generator', 'blink-alt-text'), $capability, 'admin.php?page=' . $slug . '#/generator'];
    }
  }

  function my_custom_media_script()
  {
    wp_enqueue_script('my-custom-react-media-script', plugin_dir_url(__FILE__) . 'js/custom-media.js', array('wp-element', 'media-views'), null, true);
  }


  public function bat_render_init_menu_admin()
  {

    // Check if the user has the required capability to access the settings page
    // if (isset($_GET['page']) && $_GET['page'] === BLINK_ALT_TEXT_SLUG . '#/settings' && !current_user_can('bat_setting')) {
    //   wp_die(__('You do not have sufficient permissions to access this page.'));
    // }
    require_once plugin_dir_path(dirname(__FILE__)) . '/templates/app.php';
  }

  public function bat_enqueue_plugin_admin_styles()
  {
    wp_enqueue_style('blink-alt-text-styles',  BLINK_ALT_TEXT_URL . '/assets/css/blink-alt-text.css');
  }

  public function my_custom_dashboard_widget()
  {
    // Register the new dashboard widget
    wp_add_dashboard_widget(
      'blink_alt_text_diagnose', // Widget slug
      'Blink Alt Text Diagnose', // Widget title
      array($this, 'my_custom_widget_content') // Callback function
    );
  }

  public function my_custom_widget_content()
  {
    echo '<div id="bat-widget-diagnose"></div>';
  }

  public function add_custom_admin_bar_item($wp_admin_bar)
  {
    require_once plugin_dir_path(dirname(__FILE__)) . '/classes/admin-bar-menu.php';
    $admin = new AdminBarMenu();

    $admin->add_custom_admin_bar_item($wp_admin_bar);
  }
}
