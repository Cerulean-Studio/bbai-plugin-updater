<?php

namespace BLINK_ALT_TEXT;

class UtilityRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/languages', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_languages' ],
        'permission_callback' => [ $this, 'get_languages_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/tones', [
      'methods' => 'GET',
      'callback' => [ $this, 'get_tones' ],
      'permission_callback' => [ $this, 'get_tones_permission' ]
    ] );
  }

  public function get_languages() 
  {
    $languages = array(
      'Azərbaycanca',
      'Bahasa Indonesia',
      'Bahasa Melayu',
      'Basa Jawa',
      'Bosanski',
      'Català',
      'Čeština',
      'Crnogorski',
      'Cymraeg',
      'Dansk',
      'Deutsch',
      'Eesti',
      'English',
      'Euskara',
      'Føroyskt',
      'Français',
      'Gaeilge',
      'Galego',
      'Hrvatski',
      'Italiano',
      'Latviešu',
      'Lietuvių',
      'Magyar',
      'Malti',
      'Moldovenească',
      'Nederlands',
      'Norsk',
      'Polski',
      'Português',
      'português brasileiro',
      'Română',
      'Shqip',
      'Slovenčina',
      'Slovenščina',
      'Slovenščina',
      'Suomi',
      'Việt Nam',
      'Ελληνικά',
      'Башҡорт',
      'Беларуская',
      'български',
      'Кыргызча',
      'Қазақша',
      'Македонски',
      'Монгол',
      'Русский',
      'Српски',
      'Ўзбек',
      'Українська',
      'ქართული',
      'Հայերեն',
      'اردو',
      'العربية',
      'پښتو',
      'سنڌي',
      'فارسی',
      'अवधी',
      'कश्मीरी',
      'कोंकणी',
      'छत्तीसगढ़ी',
      'डोगरी',
      'नेपाली',
      'भोजपुरी',
      'मराठी',
      'मारवाड़ी',
      'मैथिली',
      'राजस्थानी',
      'संताली',
      'संस्कृतम्',
      'हरियाणवी',
      'हिंदी',
      'বাংলা',
      'ਪੰਜਾਬੀ',
      'ગુજરાતી',
      'ଓଡ଼ିଆ',
      'ಕನ್ನಡ',
      'සිංහල',
      '한국어',
      '中文',
      '中文',
      '吴语',
      '日本語',
      '普通话',
      '粵語',
      '閩南語',
    );
    
    $response = new \WP_REST_Response( $languages );
    $response->set_status( 200 );
      
    return $response;
  }

  public function get_languages_permission() 
  {
    return true;
  }

  public function get_tones( ) 
  {
    $tones = array(
      'Formal Tone',
      'Informal Tone',
      'Professional Tone',
      'Casual Tone',
      'Authoritative Tone',
      'Friendly Tone',
      'Persuasive Tone',
      'Sarcastic Tone',
      'Humorous Tone',
      'Inspirational Tone',
      'Empathetic Tone',
      'Serious Tone',
      'Optimistic Tone',
      'Cautious Tone',
      'Excited Tone',
      'Confident Tone',
      'Doubtful Tone',
      'Respectful Tone',
      'Conversational Tone',
      'Direct Tone'
    );
    $response = new \WP_REST_Response ( $tones );
    $response->set_status( 200 );
    return $response;
  }

  public function get_tones_permission() 
  {
      return true;
  }
}
