<?php

namespace BLINK_ALT_TEXT;

class PromptRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/prompt', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_prompt' ],
        'permission_callback' => [ $this, 'get_prompt_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/prompt', [
        'methods' => 'POST',
        'callback' => [ $this, 'save_prompt' ],
        'permission_callback' => [ $this, 'save_prompt_permission' ]
    ] );

    // register_rest_route( 'blink-alt-text/v1', '/deactivated-prompt', [
    //   'methods' => 'post',
    //   'callback' => [ $this, 'remove_settings' ],
    //   'permission_callback' => [ $this, 'remove_settings_permission' ]
    // ] );
  }

  public function get_prompt() 
  {
    global $wpdb;

    $table_name = $wpdb->prefix . 'blink_alt_text_keyword_list'; // Add prefix if necessary
    $results = $wpdb->get_col( "SELECT keyword FROM $table_name");

    $current_blink_alt_text_website_topic = esc_attr(get_option( 'blink_alt_text_website_topic' ));
    $current_tone_voice = esc_attr(get_option( 'blink_alt_text_tone_voice' ));
    $current_prompt_seo = esc_attr(get_option('blink_alt_text_prompt_seo'));
    $current_blink_alt_text_audience_desc = esc_attr(get_option('blink_alt_text_audience_desc'));
    $data = [
      'websiteTopic' => $current_blink_alt_text_website_topic,
      'toneVoice' => $current_tone_voice,
      'seoKeywords' => $results,
      'audienceDesc' => $current_blink_alt_text_audience_desc
    ];

    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
    return $response;
  }

  public function get_prompt_permission() 
  {
      return true;
  }

  public function save_prompt( $req ) 
  {
      $websiteTopic = sanitize_text_field( $req['websiteTopic'] );
      $toneVoice  = sanitize_text_field( $req['toneVoice'] );
      $audienceDesc = sanitize_text_field( $req['audienceDesc'] );
      update_option( 'blink_alt_text_website_topic', $websiteTopic );
      update_option( 'blink_alt_text_tone_voice', $toneVoice );
      update_option( 'blink_alt_text_audience_desc', $audienceDesc );
      $data = [
        'websiteTopic' => $websiteTopic,
        'toneVoice' => $toneVoice,
        'seoKeywords' => $req['seoKeywords'],
        'audienceDesc' => $audienceDesc
      ];
      $this->save_keywords($req['seoKeywords'] );
      $response = new \WP_REST_Response( $data );
      $response->set_status( 200 );
      return $response;
  }

  public function save_prompt_permission() {
      // return current_user_can( 'publish_posts' );
      return true;
  }

  public function save_keywords ($seoKeywords) 
  {
    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_keyword_list'; // Add prefix if necessary
    $wpdb->query("TRUNCATE TABLE $table_name");
    
    foreach ($seoKeywords as $data) {
      $tmp = array(
          'category' => '-',
          'keyword' => $data,
      );
      $wpdb->insert( $table_name, $tmp );
    }
  }

  // public function remove_settings( $req ) 
  // {
  //     update_option( 'blink_alt_text_openai_key', '' );
  //     $response = new \WP_REST_Response ( 'remove from db success' );
  //     $response->set_status( 200 );
  //     return $response;
  // }

  public function remove_settings_permission() 
  {
      return true;
  }
}
