<?php

namespace BLINK_ALT_TEXT;

class RoleRestrictionRoute
{
  protected $roleAndCapabilities;

  public function __construct()
  {
    $this->roleAndCapabilities = new \BLINK_ALT_TEXT\RoleAndCapabilities;
    add_action('rest_api_init', [$this, 'create_rest_routes']);
  }

  public function create_rest_routes()
  {
    register_rest_route('blink-alt-text/v1', '/role_restriction', [
      'methods' => 'GET',
      'callback' => [$this, 'get_role_restriction'],
      'permission_callback' => [$this, 'get_role_restriction_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/current_user_permission', [
      'methods' => 'GET',
      'callback' => [$this, 'get_current_user_permission'],
      'permission_callback' => [$this, 'get_current_user_permission_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/role_restriction', [
      'methods' => 'POST',
      'callback' => [$this, 'save_role_restriction'],
      'permission_callback' => [$this, 'save_role_restriction_permission']
    ]);
  }

  public function get_role_restriction()
  {
    global $wpdb;

    $current_blink_alt_text_feature_restriction = esc_attr(get_option('blink_alt_text_feature_restriction'));
    // $roles = $this->roleAndCapabilities->get_system_role();
    // $roleWithInvidualAttribute = $this->roleAndCapabilities->get_roles_with_capability('bat_individual_attribute');
    // $roleWithBulkGeneration = $this->roleAndCapabilities->get_roles_with_capability('bat_bulk_generate');
    // $roleWithSetting = $this->roleAndCapabilities->get_roles_with_capability('bat_setting');
    $roleWithCapabilities = $this->roleAndCapabilities->get_all_roles_with_capabilities();
    $data = [
      'featureRestriction' => $current_blink_alt_text_feature_restriction,
      // 'roles' => $roles,
      // 'individualAttribute' => $roleWithInvidualAttribute,
      // 'bulkGeneration' => $roleWithBulkGeneration,
      // 'setting' => $roleWithSetting,
      'roleWithCapabilities' => $roleWithCapabilities
    ];

    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function get_role_restriction_permission()
  {
    return true;
  }

  public function get_current_user_permission()
  {
    $current_user = wp_get_current_user();
    $roles = $current_user->roles;
    $bat_individual_attribute = $this->roleAndCapabilities->user_capable('bat_individual_attribute');
    $bat_bulk_generate = $this->roleAndCapabilities->user_capable('bat_bulk_generate');
    $bat_setting = $this->roleAndCapabilities->user_capable('bat_setting');
    $data = [
      'individualAttribute' => $bat_individual_attribute,
      'bulkGeneration' => $bat_bulk_generate,
      'setting' => $bat_setting,
      'roles' => $roles
    ];
    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function get_current_user_permission_permission()
  {
    return true;
  }

  // public function save_role_restriction($req)
  // {
  //   $featureRestriction = sanitize_text_field($req['featureRestriction']);
  //   $individualAttribute = $req['individualAttribute'] ?? array();
  //   $bulkGeneration = $req['bulkGeneration'] ?? array();
  //   $setting = $req['setting'] ?? array();
  //   $this->roleAndCapabilities->add('bat_individual_attribute', $individualAttribute);
  //   $this->roleAndCapabilities->add('bat_bulk_generate', $bulkGeneration);
  //   $this->roleAndCapabilities->add('bat_setting', $setting);
  //   update_option('blink_alt_text_feature_restriction', $featureRestriction);
  //   update_option('blink_alt_text_individual_attribute_count', count($individualAttribute));
  //   update_option('blink_alt_text_bulk_generation_count', count($bulkGeneration));
  //   update_option('blink_alt_text_setting_count', count($setting));
  //   $data = [
  //     'featureRestriction' => $featureRestriction,
  //     'individualAttribute' => $req['individualAttribute'],
  //     'bulkGeneration' => $req['bulkGeneration'],
  //     'setting' => $req['setting']
  //   ];
  //   $response = new \WP_REST_Response($data);
  //   $response->set_status(200);
  //   return $response;
  // }

  public function save_role_restriction($req)
  {
    $roleWithCapabilities = json_decode($req['roleWithCapabilities']);
    $featureRestriction = sanitize_text_field($req['featureRestriction']);
    $this->roleAndCapabilities->addV2($roleWithCapabilities);
    // $individualAttributeCount = 0;
    // $bulkGenerationCount = 0;
    // $settingCount = 0;
    // foreach ($roleWithCapabilities as $role) {
    //   if ($role->bat_individual_attribute === true) {
    //     $individualAttributeCount++;
    //   }
    //   if ($role->bat_bulk_generate === true) {
    //     $bulkGenerationCount++;
    //   }
    //   if ($role->bat_setting === true) {
    //     $settingCount++;
    //   }
    // }
    update_option('blink_alt_text_feature_restriction', $featureRestriction);
    // update_option('blink_alt_text_individual_attribute_count', $individualAttributeCount);
    // update_option('blink_alt_text_bulk_generation_count', $bulkGenerationCount);
    // update_option('blink_alt_text_setting_count', $settingCount);
    $data = [
      'featureRestriction' => $featureRestriction,
      'individualAttribute' => $roleWithCapabilities,
    ];
    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function save_role_restriction_permission()
  {
    // return current_user_can( 'publish_posts' );
    return true;
  }
}
