<?php

namespace BLINK_ALT_TEXT;

class UtilitiesApiRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/utilities', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_utilities' ],
        'permission_callback' => [ $this, 'get_utilities_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/utilities', [
        'methods' => 'POST',
        'callback' => [ $this, 'save_utilities' ],
        'permission_callback' => [ $this, 'save_utilities_permission' ]
    ] );
  }

  public function get_utilities() 
  {
    $current_blink_alt_text_auto_update_contents = esc_attr(get_option('blink_alt_text_auto_update_contents'));
    $current_blink_alt_text_sanitize_file_name = esc_attr(get_option('blink_alt_text_sanitize_file_name'));
    $current_wp_attachment_pages_enabled = esc_attr(get_option('wp_attachment_pages_enabled'));
    $data = [
      'regenerateAltText' => $current_blink_alt_text_auto_update_contents,
      'sanitizeFileName' => $current_blink_alt_text_sanitize_file_name,
      'wpAttachmentPagesEnabled' => $current_wp_attachment_pages_enabled,
    ];

    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
    return $response;
  }

  public function get_utilities_permission() 
  {
      return true;
  }

  public function save_utilities( $req ) 
  {
      $regenerateAltText = sanitize_text_field( $req['regenerateAltText'] );
      $sanitizeFileName = sanitize_text_field( $req['sanitizeFileName'] );
      $wpAttachmentPagesEnabled = sanitize_text_field( $req['wpAttachmentPagesEnabled'] );
      // only wpattachmentpagesenabled is conditioned like this because we need to convert it to the native wordpress value
      error_log( $wpAttachmentPagesEnabled );
      if( $wpAttachmentPagesEnabled == 'true' ) {
        $wpAttachmentPagesEnabled = 1;
      } else {
        $wpAttachmentPagesEnabled = 0;
      }
      update_option( 'blink_alt_text_auto_update_contents', $regenerateAltText );
      update_option( 'blink_alt_text_sanitize_file_name', $sanitizeFileName );
      update_option( 'wp_attachment_pages_enabled', $wpAttachmentPagesEnabled );
      $data = [
        'regenerateAltText' => $regenerateAltText,
        'sanitizeFileName' => $sanitizeFileName,
        'wpAttachmentPagesEnabled' => $wpAttachmentPagesEnabled,
      ];
      $response = new \WP_REST_Response( $data );
      $response->set_status( 200 );
      return $response;
  }

  public function save_utilities_permission() {
      // return current_user_can( 'publish_posts' );
      return true;
  }

}
