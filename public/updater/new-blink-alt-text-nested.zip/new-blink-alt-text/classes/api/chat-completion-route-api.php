<?php

namespace BLINK_ALT_TEXT;

class ChatCompletionRoute
{

  public function __construct()
  {
    add_action('rest_api_init', [$this, 'create_rest_routes']);
  }

  public function create_rest_routes()
  {
    register_rest_route('blink-alt-text/v1', '/chat-completions', [
      'methods' => 'post',
      'callback' => [$this, 'chat_completions_sandbox'],
      'permission_callback' => [$this, 'chat_completions_sandbox_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/chat-completions-generate', [
      'methods' => 'post',
      'callback' => [$this, 'chat_completions_generator'],
      'permission_callback' => [$this, 'chat_completions_generator_permission']
    ]);
  }
  // apis and permissions
  public function chat_completions_sandbox($req)
  {
    $aiModel = get_option('blink_alt_text_ai_model', 'gpt-4o');
    $websiteTopic = get_option('blink_alt_text_website_topic', '');
    $toneVoice = get_option('blink_alt_text_tone_voice', '');
    $audienceDesc = get_option('blink_alt_text_audience_desc', '');
    $seoKeywordsConcat = $this->prepare_seo_keywords();
    $outputLanguage = get_option('blink_alt_text_output_language', 'English');
    $base64SandBox = $req['base64SandBox'];
    // $base64SandBox = 'https://w7.pngwing.com/pngs/79/518/png-transparent-js-react-js-logo-react-react-native-logos-icon-thumbnail.png';
    $apiKey = get_option('blink_alt_text_openai_key', '');
    $sendApi = $this->send_chat_completions_sandbox($aiModel, $websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $outputLanguage, $base64SandBox, $apiKey, $req['fieldName'], true, $req['altText']);


    $response = new \WP_REST_Response($sendApi['body']);
    $response->set_status($sendApi['code']);
    return $response;
  }

  public function chat_completions_sandbox_permission()
  {
    return true;
  }

  public function chat_completions_generator($req, $bulk_generate = false)
  {
    // updating options if day or months has changed
    // not executed when its a bulk generate
    if (!$bulk_generate) {
      if (get_option('blink_alt_text_generation_day') != date('Y-m-d')) {
        update_option('blink_alt_text_generation_day', date('Y-m-d'));
        update_option('blink_alt_text_generated_today', 0);
      }
      if (get_option('blink_alt_text_generation_month') != date('Y-m')) {
        update_option('blink_alt_text_generation_month', date('Y-m'));
        update_option('blink_alt_text_generated_this_month', 0);
      }
    }

    $blink_alt_text_limit_ai = get_option('blink_alt_text_limit_ai');
    // if limit is true then check, else just hit api
    if ($blink_alt_text_limit_ai == 'true' && !$bulk_generate) {
      if (!$this->check_if_limit_reached()) {
        $payload = $this->prepare_payload_send_chat_completions_generator($req['post_image'], $req['fieldName']);
        $sendApi = $this->send_chat_completions_generator($payload['aiModel'], $payload['websiteTopic'], $payload['toneVoice'], $payload['audienceDesc'], $payload['seoKeywordsConcat'], $payload['outputLanguage'], $payload['base64SandBox'], $payload['apiKey'], $req['fieldName'], $bulk_generate);
        $response = new \WP_REST_Response($sendApi['body']);
        $response->set_status($sendApi['code']);
        return $response;
      } else {
        $data = [
          "error" => "Too Many Requests",
          "message" => "You have exceeded your API rate limit. Please try again tomorrow."
        ];
        $response = new \WP_REST_Response($data);
        $response->set_status(429);
        return $response;
      }
    } else {
      $payload = $this->prepare_payload_send_chat_completions_generator($req['post_image'], $req['fieldName']);
      $sendApi = $this->send_chat_completions_generator($payload['aiModel'], $payload['websiteTopic'], $payload['toneVoice'], $payload['audienceDesc'], $payload['seoKeywordsConcat'], $payload['outputLanguage'], $payload['base64SandBox'], $payload['apiKey'], $req['fieldName'], $bulk_generate);
      // error_log($sendApi);
      $response = new \WP_REST_Response($sendApi['body']);
      $response->set_status($sendApi['code']);
      return $response;
    }
  }

  public function chat_completions_generator_permission()
  {
    $roleAndCapabilities = new RoleAndCapabilities();
    return $roleAndCapabilities->user_capable('bat_individual_attribute');
    // return current_user_can('bat_individual_attribute');
  }

  // methods
  public function prepare_payload_send_chat_completions_generator($post_image, $fieldName)
  {
    // $aiModel = get_option('blink_alt_text_ai_model', 'gpt-4o');
    $aiModel = $this->getAiModel($fieldName);
    $websiteTopic = get_option('blink_alt_text_website_topic', '');
    $toneVoice = get_option('blink_alt_text_tone_voice', '');
    $audienceDesc = get_option('blink_alt_text_audience_desc', '');
    $seoKeywordsConcat = $this->prepare_seo_keywords();
    $outputLanguage = get_option('blink_alt_text_output_language', 'English');
    // $base64SandBox = $post_image;
    $base64SandBox = 'https://w7.pngwing.com/pngs/79/518/png-transparent-js-react-js-logo-react-react-native-logos-icon-thumbnail.png';
    $apiKey = get_option('blink_alt_text_openai_key', '');
    return array(
      'aiModel' => $aiModel,
      'websiteTopic' => $websiteTopic,
      'toneVoice' => $toneVoice,
      'audienceDesc' => $audienceDesc,
      'seoKeywordsConcat' => $seoKeywordsConcat,
      'outputLanguage' => $outputLanguage,
      'base64SandBox' => $base64SandBox,
      'apiKey' => $apiKey,
    );
  }
  public function check_if_limit_reached()
  {
    $limitTiming = get_option('blink_alt_text_limit_timing');
    if ($limitTiming == 'day') {
      return $this->check_if_daily_limit_reached();
    } else {
      return $this->check_if_monthly_limit_reached();
    }
  }

  public function check_if_daily_limit_reached()
  {
    if (get_option('blink_alt_text_generated_today') >= get_option('blink_alt_text_generation_limit')) {
      return true;
    } else {
      return false;
    }
  }
  public function check_if_monthly_limit_reached()
  {
    if (get_option('blink_alt_text_generated_this_month') >= get_option('blink_alt_text_generation_limit')) {
      return true;
    } else {
      return false;
    }
  }

  public function send_chat_completions_sandbox($aiModel, $websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $outputLanguage, $base64SandBox, $apiKey, $fieldName, $bulk_generate, $altText)
  {
    $request_body = [
      'model' => $aiModel,
      'max_tokens' => 300,
      'messages' => [
        [
          'role' => 'system',
          'content' => "",
        ],
        [
          'role' => 'user',
          'content' => [
            [
              'type' => 'text',
              'text' => $this->generate_prompt_sandbox($websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $fieldName, $outputLanguage, $altText),
            ],
            [
              'type' => 'image_url',
              'image_url' => [
                'url' => $base64SandBox,
                'detail' => 'low',
              ],
            ],
          ],
        ],
      ],
    ];
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
      'method' => 'POST',
      'headers' => [
        'Authorization' => 'Bearer ' . $apiKey,
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($request_body),
      'timeout' => 60,
    ]);
    if (is_wp_error($response)) {
      return 'Error: ' . $response->get_error_message();
    }
    $response_body = wp_remote_retrieve_body($response);
    $response_data = json_decode($response_body, true);
    $response_code = wp_remote_retrieve_response_code($response);
    if (($response_code == 200 || $response_code == 201) && !$bulk_generate) {
      $current_value = (int) get_option('blink_alt_text_generated_today');
      $new_value = $current_value + 1;
      update_option('blink_alt_text_generated_today', $new_value);
      $current_value = (int) get_option('blink_alt_text_generated_this_month');
      $new_value = $current_value + 1;
      update_option('blink_alt_text_generated_this_month', $new_value);
    }

    return [
      'body' => $response_data,
      'code' => $response_code,
    ];
  }

  public function send_chat_completions_generator($aiModel, $websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $outputLanguage, $base64SandBox, $apiKey, $fieldName, $bulk_generate)
  {
    $request_body = [
      'model' => $aiModel,
      'max_tokens' => 300,
      'messages' => [
        [
          'role' => 'system',
          'content' => "",
        ],
        [
          'role' => 'user',
          'content' => [
            [
              'type' => 'text',
              'text' => $this->generate_prompt($websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $fieldName, $outputLanguage),
            ],
            [
              'type' => 'image_url',
              'image_url' => [
                'url' => $base64SandBox,
                'detail' => 'low',
              ],
            ],
          ],
        ],
      ],
    ];
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
      'method' => 'POST',
      'headers' => [
        'Authorization' => 'Bearer ' . $apiKey,
        'Content-Type' => 'application/json',
      ],
      'body' => json_encode($request_body),
      'timeout' => 60,
    ]);
    if (is_wp_error($response)) {
      return 'Error: ' . $response->get_error_message();
    }
    $response_body = wp_remote_retrieve_body($response);
    $response_data = json_decode($response_body, true);
    $response_code = wp_remote_retrieve_response_code($response);
    if (($response_code == 200 || $response_code == 201) && !$bulk_generate) {
      $current_value = (int) get_option('blink_alt_text_generated_today');
      $new_value = $current_value + 1;
      update_option('blink_alt_text_generated_today', $new_value);
      $current_value = (int) get_option('blink_alt_text_generated_this_month');
      $new_value = $current_value + 1;
      update_option('blink_alt_text_generated_this_month', $new_value);
    }

    return [
      'body' => $response_data,
      'code' => $response_code,
    ];
  }

  public function prepare_seo_keywords()
  {
    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_keyword_list'; // Add prefix if necessary
    $results = $wpdb->get_col("SELECT keyword FROM $table_name");
    return implode(', ', $results);
  }

  // prompts

  public function generate_prompt($websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $fieldName, $outputLanguage)
  {
    switch ($fieldName) {
      case "altText":
        $prompt = "You are tasked with generating an alt text for an image that is both descriptive and optimized for accessibility and SEO. The alt text should be concise yet informative, capturing the essence of the image while aligning with the specific requirements provided. Consider the following variables to tailor the alt text appropriately:

              1. Website Topic: The alt text should reflect the theme or subject matter of the website, which is {$websiteTopic}.
              2. Tone of Voice: Use a tone that matches the desired style, which is {$toneVoice}.
              3. SEO Topic: Integrate the following SEO Topic where relevant and natural: {$seoKeywordsConcat}. Ensure that the topics enhance the alt text without compromising readability or clarity. Include them exclusively if relevant to avoid keyword stuffing.
              4. Audience Description: Consider the target audience, described as {$audienceDesc}, to ensure the alt text resonates with their interests and level of understanding.
              5. Language: The alt text should be written in {$outputLanguage} to ensure it is accessible to the intended audience.

              Instructions:

              - Analyze the provided context, which could be either the original image or a detailed outline of the image.
              - Craft an alt text that succinctly describes the image, ensuring it is informative and relevant to the website's topic.
              - Maintain a balance between detail and brevity, aiming for a length that is typically between 50-125 characters.
              - Ensure the alt text is accessible, avoiding overly technical language unless appropriate for the audience.
              - Incorporate the SEO Topic naturally, without forcing them into the text, and only if appropriate to avoid keyword stuffing.
              - Reflect the specified tone of voice to maintain consistency with the website's overall style.
              - Do not use use any special characters.
              - Do not use emojis for any reason.
              - Do not use any introduction, do not use any quotation mark, write exclusively the Alt Text with no extra additions.

              The goal is to create an alt text in {$outputLanguage} that enhances user experience, improves accessibility, and supports SEO objectives, all while being tailored to the specific context and variables provided. You must use less than 125 characters.
              ";
        break;
      case "title":
        $prompt = "Create a concise and descriptive title for the image in {$outputLanguage}, that aids in internal organization and sorting within the media library. The title should reflect the image's content and relevance to the website's theme, {$websiteTopic}. Ensure the title is clear, specific, and suitable for internal use, not exceeding 5-7 words. Avoid using special characters, emojis and quotation marks at all costs.";
        break;
      case "slug":
        $prompt = "Create a unique and descriptive slug for the image that will be used in the URL. The slug must be in {$outputLanguage}. The slug should reflect the image's content and relevance to the website's theme, {$websiteTopic}, and {$seoKeywordsConcat}. Use exclusively hyphens as separators and ensure it is specific enough to avoid overlap with other images. For e-commerce websites, include relevant variations such as the point of view (e.g., 'left-view'), and use similar strategies for other websites. Follow best practices for SEO and accessibility, keeping it short yet precise and unique. Avoid using special characters, emojis and quotation marks at all costs.";
        break;
      case "fileName":
        $prompt = "Generate a descriptive and SEO-friendly filename without extension for the image that aligns with the website's theme, {$websiteTopic}, and {$seoKeywordsConcat}. The filename must be in {$outputLanguage}. The filename should accurately represent the image's content and avoid using characters with accents or unusual glyphs. Use alternatives like 'e' instead of 'è'. Ensure the filename is short, precise, and unique, following best practices for SEO and accessibility. Avoid using special characters, emojis and quotation marks at all costs.";
        break;
      case "caption":
        $prompt = "Write a concise and informative caption in {$outputLanguage} for the image that complements its visual content. The caption should be relevant to the website's theme, {$websiteTopic}, and resonate with the target audience, {$audienceDesc}, using a {$toneVoice} tone. While primarily descriptive, the caption can include brief commentary or highlight unique aspects of the image when appropriate. Keep it brief and engaging, as it will be visible to users. The caption must be in {$outputLanguage}. . Avoid using special characters, emojis and quotation marks at all costs.";
        break;
      case "description":
        $prompt = "Craft a detailed and engaging description in {$outputLanguage} for the image that will appear on its attachment page. The description should provide valuable context and insights relevant to the website's theme, {$websiteTopic}, and be tailored to the interests and understanding of the target audience, {$audienceDesc}. Use a {$toneVoice} tone to ensure the description is consistent with the website's communication style. The description should be informative and engaging, in {$outputLanguage}, enhancing the viewer's understanding and appreciation of the image. The description can be extremely long and compelling or extremely short, according to the image and its role on the website.  Avoid using special characters, emojis and quotation marks at all costs.";
        break;
      default:
        $prompt =  "";
    }
    return $prompt;
  }

  public function generate_prompt_sandbox($websiteTopic, $toneVoice, $audienceDesc, $seoKeywordsConcat, $fieldName, $outputLanguage, $altText)
  {
    switch ($fieldName) {
      case "altText":
        $prompt = "You are tasked with generating an alt text for an image that is both descriptive and optimized for accessibility and SEO. The alt text should be concise yet informative, capturing the essence of the image while aligning with the specific requirements provided. Consider the following variables to tailor the alt text appropriately:

          1. Website Topic: The alt text should reflect the theme or subject matter of the website, which is {$websiteTopic}.
          2. Tone of Voice: Use a tone that matches the desired style, which is {$toneVoice}.
          3. SEO Topic: Integrate the following SEO Topic where relevant and natural: {$seoKeywordsConcat}. Ensure that the topics enhance the alt text without compromising readability or clarity. Include them exclusively if relevant to avoid keyword stuffing.
          4. Audience Description: Consider the target audience, described as {$audienceDesc}, to ensure the alt text resonates with their interests and level of understanding.
          5. Language: The alt text should be written in {$outputLanguage} to ensure it is accessible to the intended audience.

          Instructions:

          - Analyze the provided context, which could be either the original image or a detailed outline of the image.
          - Craft an alt text that succinctly describes the image, ensuring it is informative and relevant to the website's topic.
          - Maintain a balance between detail and brevity, aiming for a length that is typically between 50-125 characters.
          - Ensure the alt text is accessible, avoiding overly technical language unless appropriate for the audience.
          - Incorporate the SEO Topic naturally, without forcing them into the text, and only if appropriate to avoid keyword stuffing.
          - Reflect the specified tone of voice to maintain consistency with the website's overall style.
          - Do not use use any special characters.
          - Do not use emojis for any reason.
          - Do not use any introduction, do not use any quotation mark, write exclusively the Alt Text with no extra additions.

          The goal is to create an alt text in {$outputLanguage} that enhances user experience, improves accessibility, and supports SEO objectives, all while being tailored to the specific context and variables provided. You must use less than 125 characters.
          ";
        break;
      case 'assesment':
        $prompt = "You are an expert of website accessibility and SEO best practices. you are assessing the quality of an alternative text. The prompt is written in {$outputLanguage} language, for a website about {$websiteTopic} and {$seoKeywordsConcat}, and their target audience is {$audienceDesc}.
        
        The Alt Text is written below, and the reference image is uploaded as an attachement:
        ---
        {$altText}
        ---
        You must return a single number to assess the quality of the Alt Text in a scale from 1 to 3, where '1' means that the alt text is written poorly and is not optimized, and '3' means that the Alt Text is appropriate, contextual, descriptive and effective according to the context of the website. '2' means that the alt text is usable, but that is not effective and optimized.
        Remember the following best practices associated to alt text:
        - An Alt Text should be informative and relevant to the website's topic.
        - Balance between detail and brevity, aiming for a length that is typically between 50-125 characters.
        - An Alt text must be accessible, avoiding overly technical language unless appropriate for the audience.
        - It may incorporate the SEO keywords naturally, without forcing them into the text, and only if appropriate to avoid keyword stuffing.
        - Do not have any special characters, and do not contain emojis for any reason
        - Do not have any introduction, do not use any quotation marks
        You must return exclusively a single number, and the only acceptable responses are 1, 2 or 3.
        ";
        break;
      default:
        $prompt =  "";
    }
    return $prompt;
  }

  public function getAiModel($fieldName)
  {
    $globalConfig = get_option('blink_alt_text_global_config');
    $aiModelGlobal = get_option('blink_alt_text_ai_model');
    if ($globalConfig == 'automatic') {
      $aiModel = $aiModelGlobal;
    } else {
      if ($fieldName == 'altText') {
        $aiModel = get_option('blink_alt_text_ai_model_alt_text', $aiModelGlobal);
      } else if ($fieldName == 'caption') {
        $aiModel = get_option('blink_alt_text_ai_model_caption', $aiModelGlobal);
      } else if ($fieldName == 'description') {
        $aiModel = get_option('blink_alt_text_ai_model_description', $aiModelGlobal);
      } else if ($fieldName == 'fileName') {
        $aiModel = get_option('blink_alt_text_ai_model_filename', $aiModelGlobal);
      } else if ($fieldName == 'slug') {
        $aiModel = get_option('blink_alt_text_ai_model_slug', $aiModelGlobal);
      } else if ($fieldName == 'title') {
        $aiModel = get_option('blink_alt_text_ai_model_title', $aiModelGlobal);
      } else {
        $aiModel = get_option('blink_alt_text_ai_model', $aiModelGlobal);
      }
    }
    return $aiModel;
  }
}
