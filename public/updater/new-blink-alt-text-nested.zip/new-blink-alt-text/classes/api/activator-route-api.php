<?php

namespace BLINK_ALT_TEXT;

class ActivatorRoute
{

  public function __construct() 
  {
    add_action( 'rest_api_init', [ $this, 'create_rest_routes' ] );
  }

  public function create_rest_routes() 
  {
    register_rest_route( 'blink-alt-text/v1', '/licenses', [
        'methods' => 'GET',
        'callback' => [ $this, 'get_licenses' ],
        'permission_callback' => [ $this, 'get_licenses_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/activated-license', [
      'methods' => 'post',
      'callback' => [ $this, 'save_license' ],
      'permission_callback' => [ $this, 'save_license_permission' ]
    ] );
    register_rest_route( 'blink-alt-text/v1', '/deactivated-license', [
      'methods' => 'post',
      'callback' => [ $this, 'remove_license' ],
      'permission_callback' => [ $this, 'remove_license_permission' ]
    ] );
  }

  public function get_licenses() 
  {
    $data = [
      'license' => get_option('blink_alt_text_license_activated') === false ? null : get_option('blink_alt_text_license_activated'),
      'key' => get_option('blink_alt_text_license_key') === false ? null : get_option('blink_alt_text_license_key'),
      'id' => get_option('blink_alt_text_instance_id') === false ? null : get_option('blink_alt_text_instance_id'),
    ];
    
    $response = new \WP_REST_Response( $data );
    $response->set_status( 200 );
      
    return $response;
  }

  public function get_licenses_permission() 
  {
      return true;
  }

  public function save_license( $req ) 
  {
      update_option( 'blink_alt_text_license_activated', true );
      update_option( 'blink_alt_text_license_key', sanitize_text_field( $req['license_key'] ) );
      update_option( 'blink_alt_text_instance_id', sanitize_text_field( $req['instance_id'] ) );
      $response = new \WP_REST_Response ( 'save to db success' );
      $response->set_status( 200 );
      return $response;
  }

  public function save_license_permission() 
  {
      return true;
  }

  public function remove_license( $req ) 
  {
      update_option( 'blink_alt_text_license_activated', false );
      update_option( 'blink_alt_text_license_key', '' );
      update_option( 'blink_alt_text_instance_id', '' );
      $response = new \WP_REST_Response ( 'remove from db success' );
      $response->set_status( 200 );
      return $response;
  }

  public function remove_license_permission() 
  {
      return true;
  }
}
