<?php

namespace BLINK_ALT_TEXT;

class SettingRoute
{

  public function __construct()
  {
    add_action('rest_api_init', [$this, 'create_rest_routes']);
  }

  public function create_rest_routes()
  {
    register_rest_route('blink-alt-text/v1', '/settings', [
      'methods' => 'GET',
      'callback' => [$this, 'get_settings'],
      'permission_callback' => [$this, 'get_settings_permission']
    ]);
    register_rest_route('blink-alt-text/v1', '/settings', [
      'methods' => 'POST',
      'callback' => [$this, 'save_settings'],
      'permission_callback' => [$this, 'save_settings_permission']
    ]);

    register_rest_route('blink-alt-text/v1', '/deactivated-settings', [
      'methods' => 'post',
      'callback' => [$this, 'remove_setttings'],
      'permission_callback' => [$this, 'remove_setttings_permission']
    ]);
  }

  public function get_settings()
  {
    $current_blink_alt_text_openai_key = esc_attr(get_option('blink_alt_text_openai_key'));
    $current_ai_model = esc_attr(get_option('blink_alt_text_ai_model'));
    $current_output_language = esc_attr(get_option('blink_alt_text_output_language'));
    $current_blink_alt_text_global_config = esc_attr(get_option('blink_alt_text_global_config'));
    $current_blink_alt_text_automation = esc_attr(get_option('blink_alt_text_automation'));
    $current_blink_alt_text_generate_type = esc_attr(get_option('blink_alt_text_automation_generate_type'));
    $current_blink_alt_text_individual_title = esc_attr(get_option('blink_alt_text_automation_individual_title'));
    $current_blink_alt_text_individual_caption = esc_attr(get_option('blink_alt_text_automation_individual_caption'));
    $current_blink_alt_text_individual_slug = esc_attr(get_option('blink_alt_text_automation_individual_slug'));
    $current_blink_alt_text_individual_alt_text = esc_attr(get_option('blink_alt_text_automation_individual_alt_text'));
    $current_blink_alt_text_individual_file_name = esc_attr(get_option('blink_alt_text_automation_individual_file_name'));
    $current_blink_alt_text_individual_description = esc_attr(get_option('blink_alt_text_automation_individual_description'));
    $current_blink_alt_text_individual_decorative = esc_attr(get_option('blink_alt_text_automation_individual_decorative'));
    $current_ai_model_alt_text = esc_attr(get_option('blink_alt_text_ai_model_alt_text'));
    $current_ai_model_caption = esc_attr(get_option('blink_alt_text_ai_model_caption'));
    $current_ai_model_description = esc_attr(get_option('blink_alt_text_ai_model_description'));
    $current_ai_model_filename = esc_attr(get_option('blink_alt_text_ai_model_filename'));
    $current_ai_model_slug = esc_attr(get_option('blink_alt_text_ai_model_slug'));
    $current_ai_model_title = esc_attr(get_option('blink_alt_text_ai_model_title'));

    $data = [
      'apiKey' => $current_blink_alt_text_openai_key,
      'aiModel' => $current_ai_model,
      'outputLanguage' => $current_output_language,
      'globalConfig' => $current_blink_alt_text_global_config,
      'automation' => $current_blink_alt_text_automation,
      'generateType' => $current_blink_alt_text_generate_type,
      'individualTitle' => $current_blink_alt_text_individual_title,
      'individualCaption' => $current_blink_alt_text_individual_caption,
      'individualSlug' => $current_blink_alt_text_individual_slug,
      'individualAltText' => $current_blink_alt_text_individual_alt_text,
      'individualFileName' => $current_blink_alt_text_individual_file_name,
      'individualDescription' => $current_blink_alt_text_individual_description,
      'individualDecorative' => $current_blink_alt_text_individual_decorative,
      'aiModelaltText' => $current_ai_model_alt_text,
      'aiModelcaption' => $current_ai_model_caption,
      'aiModeldescription' => $current_ai_model_description,
      'aiModelfilename' => $current_ai_model_filename,
      'aiModelslug' => $current_ai_model_slug,
      'aiModeltitle' => $current_ai_model_title,
    ];

    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function get_settings_permission()
  {
    return true;
  }

  public function save_settings($req)
  {
    $api_key = sanitize_text_field($req['apiKey']);
    $ai_model  = sanitize_text_field($req['aiModel']);
    $output_language = sanitize_text_field($req['outputLanguage']);
    $global_config = sanitize_text_field($req['globalConfig']);
    $automation = sanitize_text_field($req['automation']);
    $generateType = sanitize_text_field($req['generateType']);
    $individualTitle = sanitize_text_field($req['individualTitle']);
    $individualCaption = sanitize_text_field($req['individualCaption']);
    $individualSlug = sanitize_text_field($req['individualSlug']);
    $individualAltText = sanitize_text_field($req['individualAltText']);
    $individualFileName = sanitize_text_field($req['individualFileName']);
    $individualDescription = sanitize_text_field($req['individualDescription']);
    $individualDecorative = sanitize_text_field($req['individualDecorative']);
    $aiModelaltText = sanitize_text_field($req['aiModelaltText']);
    $aiModelcaption = sanitize_text_field($req['aiModelcaption']);
    $aiModeldescription = sanitize_text_field($req['aiModeldescription']);
    $aiModelfilename = sanitize_text_field($req['aiModelfilename']);
    $aiModelslug = sanitize_text_field($req['aiModelslug']);
    $aiModeltitle = sanitize_text_field($req['aiModeltitle']);
    update_option('blink_alt_text_openai_key', $api_key);
    // update_option('blink_alt_text_ai_model', $ai_model);
    update_option('blink_alt_text_output_language', $output_language);
    update_option('blink_alt_text_global_config', $global_config);
    update_option('blink_alt_text_automation', $automation);
    if ($automation == 'true') {
      update_option('blink_alt_text_automation_generate_type', $generateType);
      if ($generateType == 'individual') {
        update_option('blink_alt_text_automation_individual_title', $individualTitle);
        update_option('blink_alt_text_automation_individual_caption', $individualCaption);
        update_option('blink_alt_text_automation_individual_slug', $individualSlug);
        update_option('blink_alt_text_automation_individual_alt_text', $individualAltText);
        update_option('blink_alt_text_automation_individual_file_name', $individualFileName);
        update_option('blink_alt_text_automation_individual_description', $individualDescription);
        update_option('blink_alt_text_automation_individual_decorative', $individualDecorative);
      }
    }
    if ($global_config == 'automatic'){
      update_option('blink_alt_text_ai_model', $ai_model);
    } else {
      update_option('blink_alt_text_ai_model_alt_text', $aiModelaltText);
      update_option('blink_alt_text_ai_model_caption', $aiModelcaption);
      update_option('blink_alt_text_ai_model_description', $aiModeldescription);
      update_option('blink_alt_text_ai_model_filename', $aiModelfilename);
      update_option('blink_alt_text_ai_model_slug', $aiModelslug);
      update_option('blink_alt_text_ai_model_title', $aiModeltitle);
    }
    $data = [
      'apiKey' => $api_key,
      'aiModel' => $ai_model,
      'outputLanguage' => $output_language,
      'globalConfig' => $global_config,
      'automation' => $automation,
      'generateType' => $generateType,
      'individualTitle' => $automation,
      'individualCaption' => $individualCaption,
      'individualSlug' => $individualSlug,
      'individualAltText' => $individualAltText,
      'individualFileName' => $individualFileName,
      'individualDescription' => $individualDescription,
      'individualDecorative' => $individualDecorative,
      'aiModelaltText' => $aiModelaltText,
      'aiModelcaption' => $aiModelcaption,
      'aiModeldescription' => $aiModeldescription,
      'aiModelfilename' => $aiModelfilename,
      'aiModelslug' => $aiModelslug,
      'aiModeltitle' => $aiModeltitle,
    ];
    $response = new \WP_REST_Response($data);
    $response->set_status(200);
    return $response;
  }

  public function save_settings_permission()
  {
    // return current_user_can( 'publish_posts' );
    return true;
  }

  public function remove_setttings($req)
  {
    update_option('blink_alt_text_openai_key', '');
    $response = new \WP_REST_Response('remove from db success');
    $response->set_status(200);
    return $response;
  }

  public function remove_setttings_permission()
  {
    return true;
  }
}
