<?php

namespace BLINK_ALT_TEXT;

class Activator
{
  public static function activate()
  {
    // injecting bat options to wordpress
    $options = [
      'blink_alt_text_ai_model' => 'gpt-4o',
      'blink_alt_text_output_language' => 'English',
      'blink_alt_text_tone' => 'Professional Tone',
      'blink_alt_text_timer' => '3600',
      'blink_alt_text_include_feature_image' => 'Y',
      'blink_alt_text_generator' => 'image_alt',
      'blink_alt_text_on_upload' => 'N',
      'blink_alt_text_crop_image' => 'N',
      'blink_alt_text_resize_image' => 'N',
      'blink_alt_text_include_credits' => 'Y',
      'blink_alt_text_include_image_credits' => 'Y',
      'blink_alt_text_include_tldr' => 'Y',
      'blink_alt_text_enable_comment' => 'N',
      'blink_alt_text_generated_today' => 0,
      'blink_alt_text_last_generation_day' => 0,
      'blink_alt_text_auto_update_contents' => 'true',
      'blink_alt_text_sanitize_file_name' => 'true',
      'blink_alt_text_automation_generate_type' => 'all',
      'blink_alt_text_automation_individual_title' => 'false',
      'blink_alt_text_automation_individual_caption' => 'false',
      'blink_alt_text_automation_individual_slug' => 'false',
      'blink_alt_text_automation_individual_alt_text' => 'false',
      'blink_alt_text_automation_individual_file_name' => 'false',
      'blink_alt_text_automation_individual_description' => 'false',
      'blink_alt_text_automation_individual_decorative' => 'false',
      'blink_alt_text_permissions_first_time' => 'true',
    ];

    foreach ($options as $key => $value) {
      if (!get_option($key)) {
        update_option($key, $value);
      }
    }

    //create db if not exist
    // post creation history db
    global $wpdb;
    $table_name = $wpdb->prefix . 'blink_alt_text_post_history';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      post_id mediumint(9) NOT NULL,
      post_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,

      post_title text NOT NULL,
      post_url text NOT NULL,
      post_tldr text NOT NULL,
      post_image_url text NOT NULL,
      post_language text NOT NULL,

      post_original_title text NOT NULL,
      post_original_url text NOT NULL,
      post_original_source text NOT NULL,
      post_original_source_rss_url text NOT NULL,
      post_original_trigger_word text NOT NULL,
      post_original_trigger_category text NOT NULL,
      post_original_content text NOT NULL,
      post_original_image_source_url text NOT NULL,
      post_original_author text NOT NULL,
      post_original_publishing_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,

      UNIQUE KEY id (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    //create db blink_alt_text_rss_list if not exist
    $table_name_rss = $wpdb->prefix . 'blink_alt_text_rss_list';
    $sql_rss = "CREATE TABLE IF NOT EXISTS $table_name_rss (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      rss_url text NOT NULL,
      rss_label text NOT NULL,
      UNIQUE KEY id (id)
    ) $charset_collate;";
    dbDelta($sql_rss);
    //create db blink_alt_text_keyword_list if not exist
    $table_name_keyword = $wpdb->prefix . 'blink_alt_text_keyword_list';
    $sql_keyword = "CREATE TABLE IF NOT EXISTS $table_name_keyword (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      category text NOT NULL,
      keyword text NOT NULL,
      UNIQUE KEY id (id)
    ) $charset_collate;";
    dbDelta($sql_keyword);
    //create db blink_alt_text_queue if not exist
    $table_name_queue = $wpdb->prefix . 'blink_alt_text_queue';
    $sql_queue = "CREATE TABLE IF NOT EXISTS $table_name_queue (
      id mediumint(9) NOT NULL AUTO_INCREMENT,

      batch mediumint(9) NOT NULL,
      post_id text NOT NULL,
      done BOOL DEFAULT 0 NOT NULL,
      generateAltText BOOL DEFAULT 0 NOT NULL,
      generateTitle BOOL DEFAULT 0 NOT NULL,
      generateCaption BOOL DEFAULT 0 NOT NULL,
      generateSlug BOOL DEFAULT 0 NOT NULL,
      generateDescription BOOL DEFAULT 0 NOT NULL,
      generateFileName BOOL DEFAULT 0 NOT NULL,

      UNIQUE KEY id (id)
    ) $charset_collate;";
    dbDelta($sql_queue);
    //create db blink_alt_text_media_detail if not exist
    $table_name_queue = $wpdb->prefix . 'blink_alt_text_media_detail';
    $sql_queue = "CREATE TABLE IF NOT EXISTS $table_name_queue (
      post_id text NOT NULL,
      outlineAi BOOL DEFAULT 0 NOT NULL,
      slugAi BOOL DEFAULT 0 NOT NULL,
      captionAi BOOL DEFAULT 0 NOT NULL,
      altTextAi BOOL DEFAULT 0 NOT NULL,
      titleAi BOOL DEFAULT 0 NOT NULL,
      fileNameAi BOOL DEFAULT 0 NOT NULL,
      descriptionAi BOOL DEFAULT 0 NOT NULL,
      decorative BOOL DEFAULT 0 NOT NULL,
      altTextBlink text,
      altTextStatus TINYINT, 
      fileNameStatus TINYINT,

      UNIQUE KEY post_id (post_id)
    ) $charset_collate;";
    dbDelta($sql_queue);
    //create db blink_alt_text_keyword_list if not exist
    $table_name_keyword = $wpdb->prefix . 'blink_alt_text_schedule_days';
    $sql_keyword = "CREATE TABLE IF NOT EXISTS $table_name_keyword (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
          day text NOT NULL,
          UNIQUE KEY id (id)
        ) $charset_collate;";
    dbDelta($sql_keyword);
    // run analyzer

    self::analyzeFields();
    self::permissionFirstTime();
  }
  // analyze first run
  public static function analyzeFields()
  {
    global $wpdb;
    update_option('blink_alt_text_analyze_fields ', true);
    try {
      do {
        $table_name_media_detail = $wpdb->prefix . 'blink_alt_text_media_detail';
        $table_name_post_meta = $wpdb->prefix . 'postmeta';
        $table_name_post = $wpdb->prefix . 'posts';
        $result_queue = $wpdb->get_results(
          "SELECT p.ID, p.post_title, md.altTextAi, md.fileNameAi,
            (select meta_value from $table_name_post_meta where post_id = p.ID and meta_key = '_wp_attachment_image_alt') as altText,
            (select meta_value from $table_name_post_meta where post_id = p.ID and meta_key = '_wp_attached_file') as fileName
            FROM $table_name_post p
            LEFT JOIN $table_name_media_detail md ON p.ID = md.post_id
            WHERE p.post_type = 'attachment'
            AND p.post_status = 'inherit'
            AND (md.altTextStatus is null OR md.fileNameStatus is null)
            LIMIT 1;"
        );
        if (empty($result_queue)) {
          update_option('blink_alt_text_analyze_fields ', false);
          break;
        }
        if ($result_queue[0]) {
          // prepare variables
          $data = $result_queue[0];
          error_log('Updating: ' . $data->ID);
          $nonStandardSymbols = self::containsNonStandardPunctuation($data->altText ?? '');
          $fileName = self::getFileName($data->fileName);
          // conditions
          // altText
          // $altTextRedCondition1 = $data->altText == '';
          $altTextRedCondition2 = isset($data->altText) && strlen($data->altText) > 125;
          $altTextRedCondition3 = $data->altText == $fileName || $data->altText == $data->post_title;
          $altTextRedCondition4 = $nonStandardSymbols;
          $altTextYellowCondition1 = isset($data->altText) && strlen($data->altText) < 60;
          $altTextGreenCondition1 = $data->altTextAi;
          if ($altTextRedCondition2 || $altTextRedCondition3 || $altTextRedCondition4) {
            $altTextStatus = 0;
          } elseif ($altTextYellowCondition1) {
            $altTextStatus = 1;
          } elseif ($altTextGreenCondition1) {
            $altTextStatus = 2;
          } else {
            // Since all red checks passed, remaining possibility is field has its value
            $altTextStatus = 1;
          }
          // fileName
          $count = self::countWords($fileName);
          $nonStandardSymbolsFileName = self::containsNonStandardPunctuation($fileName ?? '', '/[^a-z0-9-]/');
          $fileNameRedCondition1 = $nonStandardSymbolsFileName;
          $fileNameRedCondition2 = $count > 8;
          $fileNameYellowCondition1 = $count < 3;
          $fileNameGreenCondition1 = $data->fileNameAi;
          if ($fileNameRedCondition1 || $fileNameRedCondition2) {
            $fileNameStatus = 0;
          } elseif ($fileNameYellowCondition1) {
            $fileNameStatus = 1;
          } elseif ($fileNameGreenCondition1) {
            $fileNameStatus = 2;
          } else {
            $fileNameStatus = 1;
          }

          $decorative = 0;
          // set decorative to 1 if there's no alt text
          // if (!isset($data->altText)) {
          //   $decorative = 1;
          // }
        }
        $tmp = array(
          'post_id' => $data->ID,
          'decorative' => $decorative,
          'altTextStatus' => $altTextStatus,
          'fileNameStatus' => $fileNameStatus,
        );
        $queryMediaAiStatus = $wpdb->query(
          $wpdb->prepare(
            "
          INSERT INTO $table_name_media_detail (post_id, decorative, altTextStatus, fileNameStatus)
          VALUES (%d, %d, %d, %d)
          ON DUPLICATE KEY UPDATE
              decorative = VALUES(decorative),
              altTextStatus = VALUES(altTextStatus),
              fileNameStatus = VALUES(fileNameStatus)
          ",
            $tmp['post_id'],
            $tmp['decorative'],
            $tmp['altTextStatus'],
            $tmp['fileNameStatus']
          )
        );

        if ($queryMediaAiStatus === false) {
          throw new \Exception("Database error: " . $wpdb->last_error);
        }

        error_log('Success Updating: ' . $data->ID);
      } while (($data && !empty($data)));
      error_log('done analyzing');
    } catch (\Throwable $th) {
      error_log($th);
      sleep(30); // Delay in seconds (e.g., 30 second)
      self::analyzeFields(); // Retry the function
    }
  }

  public static function containsNonStandardPunctuation($str, $pattern = '/[^\w\s.,!?\'"`’:]/')
  {
    error_log($str);
    return preg_match($pattern, $str);
  }

  public static function getFileName($filePath)
  {
    return pathinfo($filePath, PATHINFO_FILENAME);
  }

  public static function countWords($text, $separator = '-')
  {
    if ($text) {
      return count(array_filter(explode($separator, trim($text)), function ($word) {
        return strlen($word) > 0;
      }));
    }
    return 0;
  }
  // permmission first run

  public static function permissionFirstTime()
  {
    if(get_option('blink_alt_text_permissions_first_time') == 'true'){
      $roleAndCapabilities = new \BLINK_ALT_TEXT\RoleAndCapabilities;
      $roleAndCapabilities->add('bat_individual_attribute', [], true);
      $roleAndCapabilities->add('bat_bulk_generate', [], true);
      $roleAndCapabilities->add('bat_setting', [], true);
      $roleAndCapabilities->add('bat_restricted', [], false);
      update_option('blink_alt_text_permissions_first_time', 'false');
    }
  }
}
