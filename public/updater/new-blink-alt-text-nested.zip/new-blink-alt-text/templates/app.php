<div id="bat-admin-app">
    
</div>