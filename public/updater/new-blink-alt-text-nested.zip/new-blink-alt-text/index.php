<?php

/**
 * The plugin bootstrap file
 *
 * Tools plugin
 * Plugin Name: BLINK ALT TEXT
 * Author: Blink Bytes AI
 * Author URI: #
 * Version: 2.0
 * Description: AI-Powered SEO tools for Wordpress.
 * License:           GPL-3.0+
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
 * Text-Domain: blink-alt-text
 */

use BLINK_ALT_TEXT\Uninstall;

if (! defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Define plugin constants.
 */
define('BLINK_ALT_TEXT_VERSION', '2.0');
define('BLINK_ALT_TEXT_SLUG', 'blink-alt-text');
define('BLINK_ALT_TEXT_PLUGIN_FILE', __FILE__);
define('BLINK_ALT_TEXT_PLUGIN_BASENAME', trailingslashit(plugin_basename(__FILE__)));
define('BLINK_ALT_TEXT_PATH', trailingslashit(plugin_dir_path(__FILE__)));
define('BLINK_ALT_TEXT_URL', trailingslashit(plugins_url('/', __FILE__)));

if (!defined('BLINK_ALT_TEXT_OPENAI_KEY')) {
  define('BLINK_ALT_TEXT_OPENAI_KEY', get_option('blink_alt_text_openai_key', false));
}

/**
 * Comparing version
 */
function my_plugin_update_db_check()
{
  $current_version = get_option('blink_alt_text_version');

  if ($current_version !== BLINK_ALT_TEXT_VERSION) {
    my_plugin_update_db($current_version);
    update_option('blink_alt_text_version', BLINK_ALT_TEXT_VERSION);
  }
}

function my_plugin_update_db($current_version)
{
  global $wpdb;

  // if (version_compare($current_version, '1.1', '<')) {
  //   $table_name = $wpdb->prefix . 'blink_alt_text_media_detail';
  //   // $wpdb->query("ALTER TABLE $table_name MODIFY COLUMN existing_column INT(11) NOT NULL");
  //   $wpdb->query("ALTER TABLE $table_name 
  //   ADD COLUMN altTextStatus TINYINT, 
  //   ADD COLUMN fileNameStatus TINYINT");
  // }
}

register_activation_hook(__FILE__, 'my_plugin_update_db_check');
add_action('plugins_loaded', 'my_plugin_update_db_check');

/**
 * The code that runs during plugin initialization.
 */
require_once BLINK_ALT_TEXT_PATH . 'classes/loader.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/setting-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/prompt-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/role-restriction-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/limit-api-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/utilities-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/activator-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/utility-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/generator-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/chat-completion-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/schedule-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/api/bulk-generate-route-api.php';
require_once BLINK_ALT_TEXT_PATH . 'classes/role-and-capabilities.php';
require_once BLINK_ALT_TEXT_PATH . 'update-checker.php';
function initalize_blink_alt_text()
{
  // delete_site_transient('update_plugins');

  // // Force WordPress to check for updates
  // wp_update_plugins();
  // // Optionally log or debug your custom update process
  // error_log('Triggered plugin update check');
  if (current_user_can('bat_restricted')) {
    return; // Exit early if the user has the restricted capability
  }
  new BLINK_ALT_TEXT\Loader();
  new BLINK_ALT_TEXT\SettingRoute();
  new BLINK_ALT_TEXT\PromptRoute();
  new BLINK_ALT_TEXT\ScheduleRoute();
  new BLINK_ALT_TEXT\BulkGenerateRoute();
  new BLINK_ALT_TEXT\RoleRestrictionRoute();
  new BLINK_ALT_TEXT\LimitApiRoute();
  new BLINK_ALT_TEXT\UtilitiesApiRoute();
  new BLINK_ALT_TEXT\ActivatorRoute();
  new BLINK_ALT_TEXT\UtilityRoute();
  new BLINK_ALT_TEXT\GeneratorRoute();
  new BLINK_ALT_TEXT\ChatCompletionRoute();
  new BLINK_ALT_TEXT\RoleAndCapabilities();
}

add_action('plugins_loaded', 'initalize_blink_alt_text');

function bat_update_check()
{
  error_log('init:bat_update_check run');
  // Ensure this only runs in the admin area.
  if (is_admin()) {
    error_log($GLOBALS['pagenow']);
    if ($GLOBALS['pagenow'] === 'plugins.php' || $GLOBALS['pagenow'] === 'plugin-install.php') {
      error_log('UpdateChecker triggered on plugins page');
      new BLINK_ALT_TEXT\UpdateChecker();
    } else {
      error_log('Not on plugins page');
    }
  } else {
    error_log('Not in admin area');
  }
}

add_action('init', 'bat_update_check');


/**
 * The code that runs during plugin activation.
 */
function activate_blink_alt_text()
{
  require_once BLINK_ALT_TEXT_PATH . 'classes/activator-plugin.php';
  BLINK_ALT_TEXT\Activator::activate();
}

register_activation_hook(BLINK_ALT_TEXT_PLUGIN_FILE, 'activate_blink_alt_text');

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_blink_alt_text()
{
  require_once BLINK_ALT_TEXT_PATH . 'classes/deactivator-plugin.php';
  BLINK_ALT_TEXT\Deactivator::deactivate();
}

register_deactivation_hook(BLINK_ALT_TEXT_PLUGIN_FILE, 'deactivate_blink_alt_text');

/**
 * The code that runs during plugin uninstall.
 */
function uninstall_blink_alt_text()
{
  require_once BLINK_ALT_TEXT_PATH . 'classes/uninstall-plugin.php';
  BLINK_ALT_TEXT\Uninstall::uninstall();
}

register_uninstall_hook(BLINK_ALT_TEXT_PLUGIN_FILE, 'uninstall_blink_alt_text');

// Schedule cron job
function custom_every_minute_schedule($schedules)
{

  // add a 'everyminute' schedule to the existing set
  $schedules['everyminute'] = array(
    'interval' => 60,
    'display'  => __('Custom Every Minute', 'gca-core'),
  );
  return $schedules;
}

add_filter('cron_schedules', 'custom_every_minute_schedule');

/**
 * Scedule cron job.
 *
 * @return void
 */
// function custom_core_activate()
// {
//   if (! wp_next_scheduled('custom_every_minute_event')) {
//     wp_schedule_event(strtotime('today 08:20 +0700'), 'daily', 'custom_every_minute_event');
//     // wp_schedule_event(strtotime('today 08:20 +0700'), 'everyminute', 'custom_every_minute_event');
//   }
// }

// register_activation_hook(__FILE__, 'custom_core_activate');

// add_action('custom_every_minute_event', 'custom_every_minute_cronjob');

// /**
//  * Do whatever you want to do in the cron job.
//  */
// function custom_every_minute_cronjob()
// {
//   global $wpdb;
//   error_log(date('Y-m-d H:i:s', strtotime('+7 hours')));
//   // Get today's day
//   $gmt = get_option('blink_alt_text_timezone', 0);
//   error_log('GMT: ' . $gmt);
//   $today = date('l', strtotime("$gmt hours"));
//   // Select schedule days from database

//   $table_name = $wpdb->prefix . 'blink_alt_text_schedule_days';
//   $result = $wpdb->get_var($wpdb->prepare(
//     "SELECT day FROM $table_name WHERE day = %s",
//     $today
//   ));

//   if ($result) {
//     $table_name_queue = $wpdb->prefix . 'blink_alt_text_queue';
//     $result_queue = $wpdb->get_results(
//       "SELECT * FROM $table_name_queue WHERE batch = (SELECT MAX(batch) FROM $table_name_queue) AND done = 0 LIMIT 1"
//     );
//     $data = $result_queue[0];
//     if ($data) {
//       $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
//       $dataToUpdate = array();
//       if ($data->generateAltText == 1) {
//         error_log("Generate Alt Text");
//         // Execute chat_completions_generator
//         $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
//         $request = new \WP_REST_Request('POST', '/blink-alt-text/v1/chat-completions-generate');
//         $request->set_param('fieldName', 'altText');
//         $request->set_param('post_image', wp_get_attachment_url($data->post_id));
//         $response = $chat_completion_route->chat_completions_generator($request);

//         if ($response->get_status() === 200) {
//           $generated_alt_text = $response->get_data()['choices'][0]['message']['content'];
//           error_log("Generated Alt Text: " . $generated_alt_text);
//         } else {
//           error_log("Failed to generate Alt Text. Status: " . $response->get_status());
//         }
//       }
//       if ($data->generateTitle == 1) {
//         error_log("Generate Title");
//         // Execute chat_completions_generator
//         $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
//         $request = new \WP_REST_Request('POST', '/blink-alt-text/v1/chat-completions-generate');
//         $request->set_param('fieldName', 'title');
//         $request->set_param('post_image', wp_get_attachment_url($data->post_id));
//         $response = $chat_completion_route->chat_completions_generator($request);

//         if ($response->get_status() === 200) {
//           $generated_alt_text = $response->get_data()['choices'][0]['message']['content'];
//           error_log("Generated Alt Text: " . $generated_alt_text);
//         } else {
//           error_log("Failed to generate Alt Text. Status: " . $response->get_status());
//         }
//       }
//       if ($data->generateCaption == 1) {
//         error_log("Generate Caption for post id: " . $data->post_id);
//         $payloadChatCompletion = array(
//           'fieldName' => 'caption',
//           'post_image' => wp_get_attachment_url($data->post_id),
//         );
//         $generated_alt_text = $chat_completion_route->chat_completions_generator($payloadChatCompletion);
//         error_log("Generated Caption: " . $generated_alt_text->get_data()['choices'][0]['message']['content']);
//         $dataToUpdate['caption'] = $generated_alt_text->get_data()['choices'][0]['message']['content'];
//       }
//       if ($data->generateSlug == 1) {
//         error_log("Generate Caption for post id: " . $data->post_id);
//         $payloadChatCompletion = array(
//           'fieldName' => 'slug',
//           'post_image' => wp_get_attachment_url($data->post_id),
//         );
//         $generated_alt_text = $chat_completion_route->chat_completions_generator($payloadChatCompletion);
//         error_log("Generated Slug: " . $generated_alt_text->get_data()['choices'][0]['message']['content']);
//         $dataToUpdate['slug'] = $generated_alt_text->get_data()['choices'][0]['message']['content'];
//       }
//       if ($data->generateDescription == 1) {
//         error_log("Generate Description");
//         $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
//         $request = new \WP_REST_Request('POST', '/blink-alt-text/v1/chat-completions-generate');
//         $request->set_param('fieldName', 'description');
//         $request->set_param('post_image', wp_get_attachment_url($data->post_id));
//         $response = $chat_completion_route->chat_completions_generator($request);

//         if ($response->get_status() === 200) {
//           $generated_alt_text = $response->get_data()['choices'][0]['message']['content'];
//           error_log("Generated Alt Text: " . $generated_alt_text);
//         } else {
//           error_log("Failed to generate Alt Text. Status: " . $response->get_status());
//         }
//       }
//       if ($data->generateFileName == 1) {
//         error_log("Generate File Name");
//         $chat_completion_route = new \BLINK_ALT_TEXT\ChatCompletionRoute();
//         $request = new \WP_REST_Request('POST', '/blink-alt-text/v1/chat-completions-generate');
//         $request->set_param('fieldName', 'fileName');
//         $request->set_param('post_image', wp_get_attachment_url($data->post_id));
//         $response = $chat_completion_route->chat_completions_generator($request);

//         if ($response->get_status() === 200) {
//           $generated_alt_text = $response->get_data()['choices'][0]['message']['content'];
//           error_log("Generated Alt Text: " . $generated_alt_text);
//         } else {
//           error_log("Failed to generate Alt Text. Status: " . $response->get_status());
//         }
//       }
//       error_log("Data to update: " . json_encode($dataToUpdate));
//     }
//   }
// }
// End Schedule cron job

/**
 * Upload image auto generate
 */
add_action('add_attachment', 'upload_new_image');

function upload_new_image($attachment_id)
{
  $generator_route = new \BLINK_ALT_TEXT\GeneratorRoute();
  $generator_route->upload_new_image($attachment_id);
}

/**
 * Add a custom menu item to the admin menu
 */

// function update_checker()
// {
//   if (!class_exists('\BLINK_ALT_TEXT\UpdateChecker')) {
//     require_once dirname(__FILE__) . '/classes/update-checker.php';
//   }
//   new \BLINK_ALT_TEXT\UpdateChecker();
// }

// add_action('init', 'update_checker');
/**
 * The code that runs during execution of the plugin.
 */
function load_scripts()
{
  if (current_user_can('bat_restricted')) {
    return; // Exit early if the user has the restricted capability
  }
  wp_enqueue_style('bat-style', plugin_dir_url(__FILE__) . 'build/style.css');
  wp_enqueue_script('pagedone-js', plugin_dir_url(__FILE__) . 'node_modules/pagedone/src/js/pagedone.js', array(), null, true);
  wp_enqueue_script('bat-script', plugin_dir_url(__FILE__) . 'build/index.js', array('pagedone-js', 'wp-element'),  BLINK_ALT_TEXT_VERSION, true);
  wp_localize_script('bat-script', 'appLocalizer', [
    'apiUrl' => home_url('/wp-json'),
    'adminUrl' => admin_url('admin.php'),
    'nonce' => wp_create_nonce('wp_rest'),
  ]);
  // wp_enqueue_style( 'pagedone-css', plugin_dir_url(__FILE__) . 'node_modules/pagedone/src/css/pagedone.css' );
  // if ( isset($screen->id) && $screen->id === 'blink-alt-text' ) {
  // }
}

add_action('admin_enqueue_scripts', 'load_scripts');
add_action('wp_enqueue_scripts', 'load_scripts');
